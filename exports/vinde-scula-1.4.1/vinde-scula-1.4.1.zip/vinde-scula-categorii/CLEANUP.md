# Curățarea surselor și baza istorică

Versiunea 1.4.1 păstrează formularul pentru o singură sculă și statisticile
administrative. Componentele active pentru trimiterea mai multor scule și
ridicarea comună sunt eliminate din surse. Fiecare ofertă, ridicare și plată
aparține solicitării individuale.

Această curățare nu șterge înregistrările sau metadatele istorice din baza
de date. Înainte de actualizare, salvează baza de date, fotografiile private
și configurația WordPress cu cheile și salturile necesare decriptării.
Cerințele de director privat, AES-256-GCM și InnoDB sunt descrise în
[README.txt](README.txt).

## Pregătirea bazei 1.3.89

- Indentare consecventă a corpului `try` din `process_background`.
- README al bazei actualizat pentru versiunea și shortcode-ul de atunci.
- Istoricul original păstrat integral în `docs/HISTORY.txt`.
- În acea etapă nu s-au schimbat versiunea, logica, activele sau structura datelor.

Aceste patru puncte descriu exclusiv pregătirea istorică a bazei 1.3.89.
Schimbările funcționale ale versiunii curente sunt în
[CHANGELOG.md](CHANGELOG.md).
