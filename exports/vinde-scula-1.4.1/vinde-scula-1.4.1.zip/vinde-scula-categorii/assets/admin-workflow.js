(function(){
  'use strict';
  var root = document.querySelector('.vsc-admin-workflow');
  if (!root) return;
  var buttons = Array.from(root.querySelectorAll('[data-workflow-operation]'));
  var feedback = root.querySelector('.vsc-admin-feedback');
  function show(message, error) {
    feedback.hidden = false;
    feedback.textContent = message;
    feedback.classList.toggle('is-error', !!error);
  }
  buttons.forEach(function(button){
    button.addEventListener('click', async function(){
      var operation = button.dataset.workflowOperation;
      var amount = root.querySelector('#vsc-offer-amount');
      var message = root.querySelector('#vsc-offer-message');
      var select = root.querySelector('#vsc-next-state');
      var note = root.querySelector('#vsc-admin-note');
      var courier = root.querySelector('#vsc-shipping-courier');
      var awb = root.querySelector('#vsc-shipping-awb');
      var returnAwb = root.querySelector('#vsc-return-awb');
      var revisionAmount = root.querySelector('#vsc-revision-amount');
      var revisionReason = root.querySelector('#vsc-revision-reason');
      var paymentConfirmed = root.querySelector('#vsc-payment-confirmed');
      if (operation === 'offer' && (!amount || !/^\d{1,7}(?:[.,]\d{1,2})?$/.test(amount.value.trim()))) {
        show('Introdu o sumă validă, de exemplu 450 sau 450,50.', true); return;
      }
      if (operation === 'note' && (!note || !note.value.trim() || Array.from(note.value.trim()).length > 1000)) {
        show('Nota trebuie să conțină între 1 și 1.000 de caractere.', true); return;
      }
      if (operation === 'revision' && (!revisionAmount || !/^\d{1,7}(?:[.,]\d{1,2})?$/.test(revisionAmount.value.trim()) ||
          !revisionReason || Array.from(revisionReason.value.trim()).length < 10)) {
        show('Introdu o sumă nouă și un motiv de minimum 10 caractere.', true); return;
      }
      if (operation === 'revision' && !window.confirm('Trimiți clientului oferta revizuită? Acesta va decide din cont.')) return;
      var nextState = button.dataset.nextState || (select ? select.value : '');
      if (operation === 'status' && nextState === 'platita' && (!paymentConfirmed || !paymentConfirmed.checked)) {
        show('Confirmă mai întâi că ai efectuat transferul bancar în afara pluginului.', true); return;
      }
      if (operation === 'offer' && !window.confirm('Trimiți această ofertă clientului prin e-mail?')) return;
      if (operation === 'status' && !window.confirm('Confirmi: ' + button.textContent.trim() + '?')) return;
      var body = new URLSearchParams({
        action:'vsc_admin_workflow', security:root.dataset.nonce, request_id:root.dataset.requestId,
        expected:root.dataset.state, operation:operation,
        next_status:nextState, amount:amount ? amount.value.trim() : '',
        message:message ? message.value : '', note:note ? note.value.trim() : '',
        courier:courier ? courier.value.trim() : '', awb:awb ? awb.value.trim() : '',
        return_awb:returnAwb ? returnAwb.value.trim() : '',
        revision_amount:revisionAmount ? revisionAmount.value.trim() : '',
        revision_reason:revisionReason ? revisionReason.value.trim() : '',
        payment_confirmed:paymentConfirmed && paymentConfirmed.checked ? 'yes' : 'no'
      });
      buttons.forEach(function(b){b.disabled = true;});
      show(operation === 'offer' || operation === 'revision' ? 'Se trimite oferta…'
        : (operation === 'note' ? 'Se salvează nota…' : 'Se actualizează solicitarea…'), false);
      try {
        var response = await fetch(root.dataset.url,{method:'POST',body:body,credentials:'same-origin',headers:{'Accept':'application/json'}});
        var result = await response.json();
        if (!result || !result.success) throw new Error((result && result.data && result.data.message) || 'Operația nu a reușit.');
        show(result.data.message || 'Actualizare reușită.', false);
        window.setTimeout(function(){ window.location.reload(); }, 900);
      } catch(err) {
        show(err.message || 'Conexiunea a eșuat. Verifică starea solicitării înainte de a reîncerca.', true);
        buttons.forEach(function(b){b.disabled = false;});
      }
    });
  });
})();

/* Date bancare: vizualizare la cerere, doar in etapa de plata; dispare automat. */
(function () {
  'use strict';
  var root = document.querySelector('.vsc-admin-workflow[data-request-id][data-nonce]');
  var reveal = root && root.querySelector('[data-vsc-reveal-bank]');
  var display = root && root.querySelector('.vsc-admin-bank-secret');
  if (!reveal || !display) return;
  var timer = null;
  var pending = false;
  function hide() {
    if (timer) window.clearTimeout(timer);
    timer = null;
    display.textContent = '';
    display.hidden = true;
    reveal.textContent = 'Vezi IBAN și titularul pentru plată';
  }
  reveal.addEventListener('click', function () {
    if (pending) return;
    if (!display.hidden) { hide(); return; }
    pending = true;
    reveal.disabled = true;
    var payload = new URLSearchParams({
      action: 'vsc_admin_reveal_payment', security: root.dataset.nonce,
      request_id: root.dataset.requestId
    });
    fetch(root.dataset.url, {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json' },
      body: payload.toString()
    }).then(function (response) {
      return response.json().then(function (data) {
        if (!response.ok || !data || !data.success) {
          throw new Error((data && data.data && data.data.message) || 'Nu am putut prelua datele bancare.');
        }
        display.textContent = '';
        var name = document.createElement('p');
        var iban = document.createElement('p');
        name.textContent = 'Titular: ' + data.data.holder;
        iban.textContent = 'IBAN: ' + data.data.iban;
        display.appendChild(name);
        display.appendChild(iban);
        display.hidden = false;
        reveal.textContent = 'Ascunde datele bancare';
        timer = window.setTimeout(hide, 60000);
      });
    }).catch(function (error) {
      display.textContent = error.message || 'Datele nu sunt disponibile.';
      display.hidden = false;
      timer = window.setTimeout(hide, 12000);
    }).finally(function () {
      pending = false;
      reveal.disabled = false;
    });
  });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) hide();
  });
}());
