/* Vinde Scula 1.3.43 — date bancare dupa acceptarea ofertei. */
(function () {
  'use strict';
  var account = document.querySelector('.vsc-account-requests[data-vsc-url][data-vsc-nonce]');
  if (!account) return;
  var sections = account.querySelectorAll('[data-vsc-payment-form]');
  sections.forEach(function (section) {
    var form = section.querySelector('form');
    if (!form) return;
    var saleId = section.getAttribute('data-sale-id');
    var holder = form.querySelector('#vsc-bank-holder');
    var iban = form.querySelector('#vsc-bank-iban');
    var feedback = form.querySelector('.vsc-bank-form__feedback');
    var buttons = form.querySelectorAll('button');
    var remove = form.querySelector('[data-vsc-bank-delete]');
    var busy = false;
    function message(value, error) {
      feedback.hidden = false;
      feedback.textContent = value;
      feedback.classList.toggle('is-error', !!error);
    }
    function request(operation) {
      if (busy || !/^\d+$/.test(saleId || '')) return;
      if (operation === 'save') {
        var name = holder.value.trim();
        var code = iban.value.replace(/\s/g, '').toUpperCase();
        if (name.length < 3 || name.length > 120 || !/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(code)) {
          message('Introdu titularul contului și un IBAN complet (de exemplu, RO...); verificăm și pe server.', true);
          return;
        }
      }
      busy = true;
      buttons.forEach(function (button) { button.disabled = true; });
      message(operation === 'delete' ? 'Se șterg datele bancare…' : 'Se salvează datele bancare…', false);
      var payload = new URLSearchParams({
        action: 'vsc_payment_details', security: account.dataset.vscNonce,
        sale_id: saleId, payment_operation: operation,
        holder: operation === 'save' ? holder.value.trim() : '',
        iban: operation === 'save' ? iban.value.replace(/\s/g, '').toUpperCase() : ''
      });
      fetch(account.dataset.vscUrl, {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json' },
        body: payload.toString()
      }).then(function (response) {
        return response.json().then(function (data) {
          if (!response.ok || !data || !data.success) {
            throw new Error((data && data.data && data.data.message) || 'Salvarea a eșuat. Încearcă din nou.');
          }
          holder.value = ''; iban.value = '';
          message(data.data.message || 'Datele au fost actualizate.', false);
          window.setTimeout(function () { window.location.reload(); }, 750);
        });
      }).catch(function (error) {
        message(error.message || 'Nu s-a putut contacta serverul.', true);
        buttons.forEach(function (button) { button.disabled = false; });
      }).finally(function () { busy = false; });
    }
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      request('save');
    });
    if (remove) remove.addEventListener('click', function (event) {
      event.preventDefault();
      if (window.confirm('Sigur ștergi datele bancare? Nu se poate efectua plata până când le completezi din nou.')) request('delete');
    });
  });
}());
