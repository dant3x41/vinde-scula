/* Vinde Scula 1.3.39: acceptarea/refuzul ofertei doar din contul proprietarului. */
(function () {
  'use strict';
  var root = document.querySelector('.vsc-account-requests[data-vsc-url]');
  if (!root || !root.querySelector('[data-vsc-offer-choice]')) return;
  var dialog = document.createElement('div');
  dialog.className = 'vsc-offer-dialog';
  dialog.hidden = true;
  dialog.innerHTML = '<div class="vsc-offer-dialog__shade" data-vsc-offer-cancel></div>' +
    '<div class="vsc-offer-dialog__box" role="dialog" aria-modal="true" aria-labelledby="vsc-offer-dialog-heading">' +
    '<h3 id="vsc-offer-dialog-heading"></h3><p data-vsc-offer-description></p>' +
    '<p class="vsc-offer-dialog__error" data-vsc-offer-error role="alert" hidden></p>' +
    '<div class="vsc-offer-dialog__buttons"><button type="button" class="vsc-offer-dialog__cancel" data-vsc-offer-cancel>Anulează</button>' +
    '<button type="button" class="vsc-offer-dialog__confirm" data-vsc-offer-confirm>Confirmă</button></div></div>';
  root.appendChild(dialog);
  var heading = dialog.querySelector('#vsc-offer-dialog-heading');
  var description = dialog.querySelector('[data-vsc-offer-description]');
  var error = dialog.querySelector('[data-vsc-offer-error]');
  var confirm = dialog.querySelector('[data-vsc-offer-confirm]');
  var cancel = dialog.querySelector('.vsc-offer-dialog__cancel');
  var activeButton = null;
  var busy = false;
  function close() {
    if (busy) return;
    dialog.hidden = true;
    document.body.classList.remove('vsc-offer-dialog-open');
    if (activeButton && activeButton.isConnected) activeButton.focus();
    activeButton = null;
  }
  root.addEventListener('click', function (event) {
    var button = event.target.closest('[data-vsc-offer-choice]');
    if (button && root.contains(button) && !busy) {
      event.preventDefault();
      var choice = button.dataset.vscOfferChoice;
      if (choice !== 'accept' && choice !== 'refuse') return;
      activeButton = button;
      var accept = choice === 'accept';
      var revised = button.dataset.vscOfferRevision === '1';
      heading.textContent = revised ? (accept ? 'Accepți oferta revizuită?' : 'Refuzi oferta revizuită?')
        : (accept ? 'Accepți oferta?' : 'Refuzi oferta?');
      description.textContent = revised
        ? (accept ? 'Confirmi noua sumă după verificare. Scule Bune va pregăti plata.'
            : 'Refuzi suma revizuită. Scule Bune va pregăti returnarea produsului conform condițiilor comunicate.')
        : (accept ? 'Confirmi oferta Scule Bune. Organizăm ridicarea produsului și îți comunicăm pașii următori.'
            : 'Confirmi refuzul ofertei. Solicitarea va fi marcată „Respinsă”.');
      confirm.textContent = revised ? (accept ? 'Accept noua sumă' : 'Solicit retur')
        : (accept ? 'Da, accept oferta' : 'Da, refuz oferta');
      confirm.classList.toggle('vsc-offer-dialog__confirm--refuse', !accept);
      error.hidden = true;
      error.textContent = '';
      dialog.hidden = false;
      document.body.classList.add('vsc-offer-dialog-open');
      cancel.focus();
      return;
    }
    if (event.target.closest('[data-vsc-offer-cancel]')) { event.preventDefault(); close(); }
  });
  document.addEventListener('keydown', function (event) {
    if (dialog.hidden) return;
    if (event.key === 'Escape') { event.preventDefault(); close(); }
    if (event.key === 'Tab') {
      var current = document.activeElement;
      if (event.shiftKey && current === cancel) { event.preventDefault(); confirm.focus(); }
      else if (!event.shiftKey && current === confirm) { event.preventDefault(); cancel.focus(); }
    }
  });
  confirm.addEventListener('click', async function () {
    if (busy || !activeButton) return;
    var saleId = activeButton.dataset.vscSaleId;
    var choice = activeButton.dataset.vscOfferChoice;
    if (!/^\d+$/.test(saleId || '') || !['accept', 'refuse'].includes(choice)) return;
    busy = true;
    confirm.disabled = true;
    cancel.disabled = true;
    try {
      var params = new URLSearchParams({
        action: 'vsc_offer_reply',
        security: root.dataset.vscNonce || '',
        sale_id: saleId,
        offer_choice: choice
      });
      var response = await fetch(root.dataset.vscUrl, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        cache: 'no-store', body: params.toString()
      });
      var json = await response.json();
      if (!response.ok || !json.success) throw new Error(json?.data?.message || 'Nu am putut înregistra răspunsul.');
      // După o singură alegere reafișăm starea actualizată de server.
      window.location.reload();
    } catch (ex) {
      error.textContent = ex.message || 'A apărut o eroare. Încearcă din nou.';
      error.hidden = false;
    } finally {
      busy = false;
      confirm.disabled = false;
      cancel.disabled = false;
    }
  });
}());
