/* Vinde Scula 1.3.44 — finalizarea vânzării după acceptarea ofertei. */
(function () {
  'use strict';
  var account = document.querySelector('.vsc-account-requests[data-vsc-url][data-vsc-nonce]');
  var section = account && account.querySelector('[data-vsc-finalization][data-sale-id]');
  var form = section && section.querySelector('form.vsc-finalization__form');
  if (!form) return;
  var id = section.getAttribute('data-sale-id');
  var feedback = form.querySelector('.vsc-finalization__feedback');
  var button = form.querySelector('[type="submit"]');
  var busy = false;
  function message(text, error) {
    feedback.textContent = text;
    feedback.hidden = false;
    feedback.classList.toggle('is-error', !!error);
    feedback.scrollIntoView({block: 'nearest', behavior: 'smooth'});
  }
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    if (busy || !/^\d+$/.test(id || '')) return;
    var fields = new FormData(form);
    var iban = (fields.get('iban') || '').toString().replace(/\s/g, '').toUpperCase();
    if (!form.checkValidity()) {
      form.reportValidity();
      message('Completează toate câmpurile obligatorii și confirmările.', true);
      return;
    }
    var code = iban;
    if (code && !/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(code)) {
      message('IBAN-ul pare incomplet. Verifică-l înainte de trimitere.', true);
      return;
    }
    busy = true;
    button.disabled = true;
    message('Se salvează securizat datele pentru ridicare și plată…', false);
    var payload = new URLSearchParams({
      action: 'vsc_finalize_sale', security: account.dataset.vscNonce, sale_id: id
    });
    fields.forEach(function (value, key) {
      payload.set(key, key === 'iban' ? code : String(value));
    });
    fetch(account.dataset.vscUrl, {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json'},
      body: payload.toString()
    }).then(function (response) {
      return response.json().then(function (data) {
        if (!response.ok || !data || !data.success) {
          throw new Error((data && data.data && data.data.message) || 'Nu am putut salva datele.');
        }
        // Nu păstrăm IBAN-ul introdus în DOM după salvare.
        form.querySelector('[name="iban"]').value = '';
        form.querySelector('[name="holder"]').value = '';
        message(data.data.message || 'Vânzarea a fost finalizată.', false);
        window.setTimeout(function () {
          var target = new URL(window.location.href);
          target.searchParams.delete('vsc_finalizare');
          window.location.assign(target.toString());
        }, 900);
      });
    }).catch(function (error) {
      message(error.message || 'Conexiunea a eșuat. Încearcă din nou.', true);
      button.disabled = false;
    }).finally(function () { busy = false; });
  });
}());
