(function () {
  'use strict';
  var cfg = window.VSC_GUEST_GATE || {};
  var root = document.getElementById('formular-vinde-scula');
  if (!root || !root.classList.contains('vsc-guest-widget')) { return; }

  // Elementor poate include shortcode-ul într-o coloană mai îngustă.
  // Bigxon afișează formularul Contul meu direct în #et-content.container.
  // Mutăm NUMAI panoul de autentificare în același container; cardurile
  // Elementor, selectorul de categorie și toate formularele rămân neatinse.
  var main = document.getElementById('et-content');
  if (main && main.contains(root) && root.parentElement !== main) {
    var topLevel = root;
    while (topLevel.parentElement && topLevel.parentElement !== main) {
      topLevel = topLevel.parentElement;
    }
    if (topLevel !== root && topLevel.parentElement === main) {
      main.insertBefore(root, topLevel);
    }
  }

  var categories = cfg.categories || {};
  var keys = Object.keys(categories);
  var selector = keys.map(function (key) { return '.vsc-cat-' + key; }).join(',');
  var cards = Array.from(document.querySelectorAll(selector)).filter(function (el) {
    return !root.contains(el);
  });
  var wrapper = document.querySelector('.vsc-categorii-elementor');
  var regions = [];
  if (wrapper && !wrapper.contains(root) && cards.some(function (el) { return wrapper.contains(el); })) {
    regions = [wrapper];
  } else {
    cards.forEach(function (card) {
      var region = card;
      if (wrapper) {
        while (region.parentElement && region.parentElement !== wrapper &&
               !region.parentElement.contains(root)) { region = region.parentElement; }
      }
      if (!region.contains(root) && regions.indexOf(region) === -1) { regions.push(region); }
    });
  }
  var storageKey = 'vsc:selected-category:' + window.location.pathname;
  function valid(key) { return keys.indexOf(key) !== -1; }
  function currentUrl(category) {
    var url = new URL(cfg.returnUrl || window.location.href);
    if (category) { url.searchParams.set('categoria', category); }
    return url.href;
  }
  function setCategoryInUrl(category) {
    try {
      var url = new URL(window.location.href);
      if (category) { url.searchParams.set('categoria', category); }
      else { url.searchParams.delete('categoria'); }
      window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
    } catch (ignored) {}
  }
  function setVisible(selected) {
    regions.forEach(function (region) {
      region.hidden = selected;
      region.classList.toggle('vsc-elementor-cards-hidden', selected);
    });
    root.hidden = !selected;
  }
  function show(category, scroll) {
    if (!valid(category)) { return; }
    // Formularul WooCommerce e nativ: trimitem categoria aleasă prin vsc_return
    // atât la login, cât și la înregistrare (procesate de WooCommerce).
    Array.from(root.querySelectorAll('input[name="vsc_return"]')).forEach(function (input) {
      input.value = currentUrl(category);
    });
    try { window.localStorage.setItem(storageKey, category); } catch (ignored) {}
    setCategoryInUrl(category);
    setVisible(true);
    if (scroll) { root.scrollIntoView({behavior:'smooth',block:'start'}); }
  }
  document.addEventListener('click', function (event) {
    var target = event.target instanceof Element ? event.target.closest(selector) : null;
    if (!target || cards.indexOf(target) === -1) { return; }
    var category = keys.find(function (key) { return target.classList.contains('vsc-cat-' + key); });
    if (!category) { return; }
    event.preventDefault();
    show(category, true);
  }, true);
  cards.forEach(function (card) {
    if (!card.matches('a,button,input,[role="button"]')) {
      card.setAttribute('role', 'button');
      if (!card.hasAttribute('tabindex')) { card.setAttribute('tabindex', '0'); }
    }
    card.addEventListener('keydown', function (event) {
      if (event.target !== card || (event.key !== 'Enter' && event.key !== ' ')) { return; }
      var category = keys.find(function (key) { return card.classList.contains('vsc-cat-' + key); });
      if (category) { event.preventDefault(); show(category, true); }
    });
  });
  var queryCategory = new URLSearchParams(window.location.search).get('categoria') || '';
  if (valid(queryCategory)) { show(queryCategory, false); }
  else {
    // Fără categorie în URL, revenirea la pagina Vinde arată din nou cardurile.
    // Selecția rămasă în localStorage nu trebuie să blocheze navigarea.
    try { window.localStorage.removeItem(storageKey); } catch (ignored) {}
    document.documentElement.classList.remove('vsc-category-prefill','vsc-category-restored');
    // Shortcode-ul funcționează și fără carduri Elementor sau categorie în URL.
    setVisible(regions.length === 0);
  }
})();
