/* 1.3.80: indicator roșu în toate meniurile + iconiță nouă pentru Vânzări pe mobil. */
(function () {
  'use strict';

  function cleanLabel(value) {
    return (value || '').replace(/\s+/g, ' ').trim().toLocaleUpperCase('ro-RO');
  }

  function isSalesLink(link) {
    if (!link) return false;
    var href = link.getAttribute('href') || '';
    var label = cleanLabel(link.textContent);
    return (
      href.indexOf('/vanzari') !== -1 ||
      href.indexOf('vanzari') !== -1 ||
      label === 'VÂNZĂRI' ||
      label === 'VANZARI'
    );
  }

  function ensureMobileSalesIcon(link) {
    // Iconita este acum afisata exclusiv din CSS, fara injectie tardiva in DOM.
    // Eliminam elementele injectate de versiunile anterioare, daca mai exista.
    link.querySelectorAll('.vsc-mobile-sales-icon').forEach(function (icon) { icon.remove(); });
  }

  function collectSalesLinks(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var links = scope.querySelectorAll('.my-account-buttons li a, .woocommerce-MyAccount-navigation li a, .woocommerce-MyAccount-navigation a');
    var found = [];
    for (var i = 0; i < links.length; i++) {
      var link = links[i];
      if (!isSalesLink(link)) continue;
      if (found.indexOf(link) === -1) found.push(link);
    }
    return found;
  }

  function renderUnreadBadges(root) {
    var config = window.VSC_UNREAD_OFFERS || {};
    var count = Number(config.count) || 0;
    var links = collectSalesLinks(root);

    links.forEach(function (nav) {
      var badge = nav.querySelector('.vsc-unread-offer-count');
      nav.classList.add('vsc-mobile-sales-link');
      ensureMobileSalesIcon(nav);
      if (count < 1) {
        if (badge) badge.remove();
        return;
      }
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'vsc-unread-offer-count';
        nav.appendChild(badge);
      }
      badge.textContent = String(count);
      badge.setAttribute('aria-label', count === 1 ? '1 ofertă nouă' : count + ' oferte noi');
    });
  }

  function boot() {
    renderUnreadBadges(document);
    if ('MutationObserver' in window) {
      var observer = new MutationObserver(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
          for (var j = 0; j < mutations[i].addedNodes.length; j++) {
            var node = mutations[i].addedNodes[j];
            if (node && node.nodeType === 1) renderUnreadBadges(node);
          }
        }
      });
      observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    }
    window.setTimeout(function () { renderUnreadBadges(document); }, 250);
    window.setTimeout(function () { renderUnreadBadges(document); }, 1000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
}());

/* Vinde Scula 1.3.12: acțiuni protejate în Contul meu > Vânzări. */
(function () {
  'use strict';
  const root = document.querySelector('.vsc-account-requests[data-vsc-url]');
  if (!root) return;
  const modal = root.querySelector('[data-vsc-modal]');
  if (!modal) return;

  const form = modal.querySelector('[data-vsc-modal-form]');
  const title = modal.querySelector('[data-vsc-modal-title]');
  const description = modal.querySelector('[data-vsc-modal-description]');
  const priceField = modal.querySelector('[data-vsc-price-field]');
  const priceInput = form.querySelector('input[name="price"]');
  const confirm = modal.querySelector('[data-vsc-confirm]');
  const message = modal.querySelector('[data-vsc-modal-message]');
  let activeId = null;
  let activeAction = null;
  let opener = null;
  let submitting = false;

  function closeMenus() {
    root.querySelectorAll('.vsc-sale-more[open]').forEach(function (details) { details.open = false; });
  }
  function closeModal() {
    if (submitting) return;
    modal.hidden = true;
    activeId = null;
    activeAction = null;
    document.body.classList.remove('vsc-sale-modal-open');
    if (opener && opener.isConnected) opener.focus();
    opener = null;
  }
  function openModal(button) {
    if (submitting) return;
    activeId = button.dataset.vscId;
    activeAction = button.dataset.vscAction;
    if (!activeId || !['price', 'withdraw'].includes(activeAction)) return;
    opener = button.closest('details')?.querySelector('summary') || button;
    closeMenus();
    message.hidden = true;
    message.textContent = '';
    const isWithdraw = activeAction === 'withdraw';
    title.textContent = isWithdraw ? 'Retrage solicitarea?' : 'Modifică prețul dorit';
    description.textContent = isWithdraw
      ? 'Solicitarea va rămâne în istoricul Vânzări cu starea „Retrasă”. Nu o vei mai putea modifica.'
      : 'Introdu noul preț dorit. Solicitarea își va păstra numărul și fotografiile.';
    priceField.hidden = isWithdraw;
    priceInput.required = !isWithdraw;
    priceInput.value = isWithdraw ? '' : (button.dataset.vscPrice || '').replace('.', ',');
    confirm.textContent = isWithdraw ? 'Da, retrage solicitarea' : 'Salvează prețul';
    confirm.classList.toggle('vsc-sale-modal__confirm--danger', isWithdraw);
    modal.hidden = false;
    document.body.classList.add('vsc-sale-modal-open');
    (isWithdraw ? confirm : priceInput).focus();
  }
  root.addEventListener('click', function (event) {
    const action = event.target.closest('[data-vsc-action]');
    if (action && root.contains(action)) {
      event.preventDefault();
      openModal(action);
      return;
    }
    if (event.target.closest('[data-vsc-cancel]')) {
      event.preventDefault();
      closeModal();
      return;
    }
    if (!event.target.closest('.vsc-sale-more')) closeMenus();
  });
  root.querySelectorAll('.vsc-sale-more').forEach(function (details) {
    details.addEventListener('toggle', function () {
      if (details.open) root.querySelectorAll('.vsc-sale-more[open]').forEach(function (other) {
        if (other !== details) other.open = false;
      });
    });
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      if (!modal.hidden) { event.preventDefault(); closeModal(); }
      else closeMenus();
    }
    if (event.key === 'Tab' && !modal.hidden) {
      const focusable = Array.from(modal.querySelectorAll('button:not(:disabled), input:not(:disabled)'))
        .filter(function (item) { return item.getClientRects().length > 0; });
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (submitting || !activeId || !activeAction) return;
    const newPrice = priceInput.value.trim();
    if (activeAction === 'price' && !/^\d{1,7}(?:[.,]\d{1,2})?$/.test(newPrice)) {
      message.textContent = 'Introdu un preț valid, fără separatori de mii.';
      message.hidden = false;
      priceInput.focus();
      return;
    }
    const params = new URLSearchParams({
      action: 'vsc_sale_action',
      security: root.dataset.vscNonce || '',
      sale_id: activeId,
      sale_action: activeAction
    });
    if (activeAction === 'price') params.set('price', newPrice);
    submitting = true;
    confirm.disabled = true;
    try {
      const response = await fetch(root.dataset.vscUrl, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: params.toString(), cache: 'no-store'
      });
      const payload = await response.json();
      if (!response.ok || !payload.success) throw new Error(payload?.data?.message || 'Nu am putut salva modificarea.');
      // Reîncărcarea garantează date actualizate în listă și interzice acțiunile după retragere.
      window.location.reload();
    } catch (error) {
      message.textContent = error.message || 'A apărut o eroare. Încearcă din nou.';
      message.hidden = false;
    } finally {
      submitting = false;
      confirm.disabled = false;
    }
  });
}());
