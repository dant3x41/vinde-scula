<?php
/** Statistics for cohorts of tool requests, without exposing customer data. */
if (!defined('ABSPATH')) { exit; }

final class VSC_Statistics {
    const PAGE = 'vsc-statistici';
    private static $page_hook = '';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
    }

    public static function menu() {
        self::$page_hook = add_submenu_page(
            'edit.php?post_type=vsc_solicitare', 'Statistici Vinde Scula', 'Statistici',
            'manage_options', self::PAGE, array(__CLASS__, 'render_page')
        );
    }

    public static function assets($hook) {
        if (!self::$page_hook || $hook !== self::$page_hook || !current_user_can('manage_options')) { return; }
        wp_enqueue_style('vsc-statistics', plugins_url('../assets/statistics.css', __FILE__), array(), VSC_Categorii_Plugin::VERSION);
    }

    private static function parse_date($value) {
        if (!is_string($value) || !preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}$/D', $value)) { return false; }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, wp_timezone());
        $errors = DateTimeImmutable::getLastErrors();
        if (!$date || ($errors && ($errors['warning_count'] || $errors['error_count'])) || $date->format('Y-m-d') !== $value) { return false; }
        return $date;
    }

    private static function ratio($numerator, $denominator) {
        return $denominator > 0 ? 100.0 * $numerator / $denominator : null;
    }

    private static function empty_totals() {
        return array('received' => 0, 'offered' => 0, 'accepted' => 0, 'accepted_offered' => 0,
            'paid' => 0,
            'latency_count' => 0, 'latency_seconds' => 0);
    }

    /**
     * An inclusive creation-date cohort, in the site's timezone.
     * Last metadata row wins for single-valued fields; first valid recorded offer
     * date supplies latency. A grouped SQL result avoids loading individual sales.
     *
     * @return array|WP_Error
     */
    public static function report($from, $to) {
        if (!current_user_can('manage_options')) {
            return new WP_Error('vsc_statistics_forbidden', 'Nu ai permisiunea de a consulta statisticile.', array('status' => 403));
        }
        $start = self::parse_date($from);
        $last = self::parse_date($to);
        if (!$start || !$last || $start > $last) {
            return new WP_Error('vsc_statistics_dates', 'Alege un interval valid, în format AAAA-LL-ZZ, cu data de început înaintea datei de sfârșit.', array('status' => 400));
        }
        global $wpdb;
        // Validate the calendar as well as the datetime shape: MySQL can accept
        // impossible days in STR_TO_DATE, so do not rely on that function alone.
        $valid_offer = "pm.meta_value REGEXP '^[1-9][0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01]) ([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$'
            AND CAST(SUBSTRING(pm.meta_value,9,2) AS UNSIGNED) <= DAY(LAST_DAY(CONCAT(SUBSTRING(pm.meta_value,1,7),'-01')))";
        $sql = "SELECT
            CASE WHEN category.meta_value IN ('scule-acumulator','scule-electrice','scule-pneumatice','acumulatori','incarcatoare')
                THEN category.meta_value ELSE 'other' END AS category_key,
            COUNT(*) AS received,
            SUM(r.offered) AS offered,
            SUM(CASE WHEN reply.meta_value='accept' THEN 1 ELSE 0 END) AS accepted,
            SUM(CASE WHEN r.offered=1 AND reply.meta_value='accept' THEN 1 ELSE 0 END) AS accepted_offered,
            SUM(CASE WHEN state.meta_value='platita' THEN 1 ELSE 0 END) AS paid,
            SUM(CASE WHEN r.first_offer_at >= r.post_date THEN 1 ELSE 0 END) AS latency_count,
            SUM(CASE WHEN r.first_offer_at >= r.post_date THEN TIMESTAMPDIFF(SECOND,r.post_date,r.first_offer_at) ELSE 0 END) AS latency_seconds
        FROM (
            SELECT p.ID,p.post_date,
                MAX(CASE WHEN pm.meta_key='_vsc_categoria' THEN pm.meta_id ELSE 0 END) AS category_id,
                MAX(CASE WHEN pm.meta_key='_vsc_offer_reply' THEN pm.meta_id ELSE 0 END) AS reply_id,
                MAX(CASE WHEN pm.meta_key='_vsc_status' THEN pm.meta_id ELSE 0 END) AS state_id,
                MAX(CASE WHEN pm.meta_key='_vsc_offer_sent_at' AND TRIM(pm.meta_value)<>'' THEN 1 ELSE 0 END) AS offered,
                MIN(CASE WHEN pm.meta_key='_vsc_offer_sent_at' AND {$valid_offer} THEN pm.meta_value ELSE NULL END) AS first_offer_at
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key IN
                ('_vsc_categoria','_vsc_offer_reply','_vsc_status','_vsc_offer_sent_at')
            WHERE p.post_type=%s AND p.post_status=%s AND p.post_date >= %s AND p.post_date <= %s
            GROUP BY p.ID,p.post_date
        ) r
        LEFT JOIN {$wpdb->postmeta} category ON category.meta_id=r.category_id
        LEFT JOIN {$wpdb->postmeta} reply ON reply.meta_id=r.reply_id
        LEFT JOIN {$wpdb->postmeta} state ON state.meta_id=r.state_id
        GROUP BY category_key WITH ROLLUP";
        $rows = $wpdb->get_results($wpdb->prepare($sql, 'vsc_solicitare', 'private',
            $from . ' 00:00:00', $to . ' 23:59:59'), ARRAY_A);
        if ($rows === null || $wpdb->last_error) {
            return new WP_Error('vsc_statistics_database', 'Statisticile nu pot fi calculate acum. Încearcă din nou.', array('status' => 500));
        }
        $report = array('from' => $from, 'to' => $to, 'timezone' => wp_timezone_string(),
            'totals' => self::empty_totals(), 'categories' => array());
        foreach ($rows as $row) {
            $values = self::empty_totals();
            foreach ($values as $key => $unused) { $values[$key] = (int)$row[$key]; }
            $values['offer_acceptance_rate'] = self::ratio($values['accepted_offered'], $values['offered']);
            $values['acquisition_rate'] = self::ratio($values['paid'], $values['received']);
            $values['average_offer_seconds'] = $values['latency_count'] > 0 ? $values['latency_seconds'] / $values['latency_count'] : null;
            if ($row['category_key'] === null) {
                $report['totals'] = $values;
            } else {
                $values['category'] = $row['category_key'];
                $report['categories'][] = $values;
            }
        }
        // GROUP BY has no row on an empty cohort, including no rollup row.
        $report['totals'] += array('offer_acceptance_rate' => null, 'acquisition_rate' => null, 'average_offer_seconds' => null);
        usort($report['categories'], static function($a, $b) {
            return $a['received'] === $b['received'] ? strcmp($a['category'], $b['category']) : $b['received'] <=> $a['received'];
        });
        return $report;
    }

    private static function percentage($value) {
        return $value === null ? '—' : number_format_i18n($value, 1) . '%';
    }

    private static function duration($seconds) {
        if ($seconds === null) { return '—'; }
        $minutes = (int)round($seconds / 60);
        $days = (int)floor($minutes / 1440);
        $hours = (int)floor(($minutes % 1440) / 60);
        $parts = array();
        if ($days) { $parts[] = $days . ' zile'; }
        if ($hours) { $parts[] = $hours . ' h'; }
        if ($minutes % 60 || !$parts) { $parts[] = ($minutes % 60) . ' min'; }
        return implode(' ', $parts);
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu ai permisiunea de a consulta statisticile.', '', array('response' => 403));
        }
        $today = current_datetime();
        $from = isset($_GET['from']) ? (is_string($_GET['from']) ? wp_unslash($_GET['from']) : '') : $today->modify('-29 days')->format('Y-m-d');
        $to = isset($_GET['to']) ? (is_string($_GET['to']) ? wp_unslash($_GET['to']) : '') : $today->format('Y-m-d');
        $report = self::report($from, $to);
        ?>
        <div class="wrap vsc-statistics">
            <h1>Statistici Vinde Scula</h1>
            <p class="vsc-statistics-intro">Urmărește cererile primite în perioada aleasă și rezultatul lor până în prezent. Fiecare solicitare este numărată individual.</p>
            <form method="get" action="<?php echo esc_url(admin_url('edit.php')); ?>" class="vsc-statistics-filter">
                <input type="hidden" name="post_type" value="vsc_solicitare">
                <input type="hidden" name="page" value="<?php echo esc_attr(self::PAGE); ?>">
                <div><label for="vsc-statistics-from">De la</label><input type="date" id="vsc-statistics-from" name="from" value="<?php echo esc_attr($from); ?>" required></div>
                <div><label for="vsc-statistics-to">Până la</label><input type="date" id="vsc-statistics-to" name="to" value="<?php echo esc_attr($to); ?>" required></div>
                <button type="submit" class="button button-primary">Aplică perioada</button>
                <span class="vsc-statistics-timezone">Fus orar: <?php echo esc_html(wp_timezone_string()); ?></span>
            </form>
            <?php if (is_wp_error($report)) : ?>
                <div class="notice notice-error inline" role="alert"><p><?php echo esc_html($report->get_error_message()); ?></p></div>
            <?php else : $totals = $report['totals']; ?>
                <div class="vsc-statistics-cards" aria-label="Rezultatele perioadei">
                    <?php
                    $cards = array(
                        array('Scule primite', number_format_i18n($totals['received']), 'Fiecare solicitare este numărată individual.'),
                        array('Oferte trimise', number_format_i18n($totals['offered']), 'Solicitări cu o dată de ofertare înregistrată.'),
                        array('Acceptate de client', number_format_i18n($totals['accepted']), 'Doar răspunsuri explicite de acceptare ale clientului.'),
                        array('Scule achiziționate', number_format_i18n($totals['paid']), 'Solicitări marcate cu plata efectuată.'),
                        array('Ofertă → acceptare', self::percentage($totals['offer_acceptance_rate']), 'Acceptări ale clientului din solicitările cu ofertă.'),
                        array('Cerere → achiziție', self::percentage($totals['acquisition_rate']), 'Scule plătite din totalul solicitărilor primite.'),
                        array('Până la prima ofertă', self::duration($totals['average_offer_seconds']), sprintf('Media pentru %s solicitări cu date valide.', number_format_i18n($totals['latency_count']))),
                    );
                    foreach ($cards as $card) : ?>
                        <section class="vsc-statistics-card"><h2><?php echo esc_html($card[0]); ?></h2><p class="vsc-statistics-value"><?php echo esc_html($card[1]); ?></p><p><?php echo esc_html($card[2]); ?></p></section>
                    <?php endforeach; ?>
                </div>
                <h2>Categorii</h2>
                <div class="vsc-statistics-table-wrap" role="region" aria-label="Rezultate pe categorii" tabindex="0">
                    <table class="widefat striped vsc-statistics-table">
                        <caption class="screen-reader-text">Solicitări primite în perioada aleasă, grupate după categoria sculei</caption>
                        <thead><tr><th scope="col">Categorie</th><th scope="col">Primite</th><th scope="col">Cu ofertă</th><th scope="col">Acceptate</th><th scope="col">Achiziționate</th><th scope="col">Ofertă → acceptare</th><th scope="col">Cerere → achiziție</th></tr></thead>
                        <tbody>
                        <?php
                        $labels = array('scule-acumulator' => 'Scule cu acumulator', 'scule-electrice' => 'Scule electrice', 'scule-pneumatice' => 'Scule pneumatice', 'acumulatori' => 'Acumulatori', 'incarcatoare' => 'Încărcătoare', 'other' => 'Alte categorii / nespecificat');
                        if (!$report['categories']) : ?>
                            <tr><td colspan="7">Nu există solicitări în perioada aleasă.</td></tr>
                        <?php else : foreach ($report['categories'] as $category) : ?>
                            <tr><th scope="row"><?php echo esc_html($labels[$category['category']]); ?></th>
                                <td><?php echo esc_html(number_format_i18n($category['received'])); ?></td><td><?php echo esc_html(number_format_i18n($category['offered'])); ?></td><td><?php echo esc_html(number_format_i18n($category['accepted'])); ?></td><td><?php echo esc_html(number_format_i18n($category['paid'])); ?></td>
                                <td><?php echo esc_html(self::percentage($category['offer_acceptance_rate'])); ?></td><td><?php echo esc_html(self::percentage($category['acquisition_rate'])); ?></td></tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
                <p class="vsc-statistics-note">Sunt incluse doar solicitările private create în perioada aleasă, indiferent când a venit răspunsul sau plata. Solicitările netrimise și cele șterse sunt excluse. Media de ofertare folosește prima dată validă înregistrată, fără date lipsă sau anterioare cererii. „—” înseamnă că nu există o bază de calcul.</p>
            <?php endif; ?>
        </div>
        <?php
    }
}
