<?php
/**
 * Plugin Name: 00. Vinde Scula – Formular cu Categorii
 * Description: Formular de vânzare pentru o singură sculă per solicitare, fotografii private, oferte și statistici.
 * Version: 1.4.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Vinde Scula
 * Text Domain: vinde-scula-categorii
 */

if (!defined('ABSPATH')) { exit; }

final class VSC_Categorii_Plugin {
    const VERSION = '1.4.1';
    const TYPE = 'vsc_solicitare';
    const OPT_DAILY_LIMIT = 'vsc_max_cereri_pe_zi';
    const OPT_HOURLY_IP_LIMIT = 'vsc_max_cereri_ip_ora';
    const OPT_EMAIL_TRANSPORT = 'vsc_email_transport';
    const EMAIL_MAX_ATTEMPTS = 3;
    const EMAIL_BATCH_SIZE = 20;

    public static function init() {
        add_action('init', array(__CLASS__, 'post_type'));
        add_action('init', array(__CLASS__, 'retire_shipment_scheduler'), 35);
        add_action('init', array(__CLASS__, 'register_account_endpoint'));
        add_filter('woocommerce_get_query_vars', array(__CLASS__, 'account_query_vars'));
        add_filter('woocommerce_account_menu_items', array(__CLASS__, 'account_menu'), 30);
        add_action('template_redirect', array(__CLASS__, 'mark_offer_viewed_on_detail'), 5);
        add_action('woocommerce_account_vanzari_endpoint', array(__CLASS__, 'account_requests'));
        // Compatibilitate cu linkurile vechi, fără element de meniu duplicat.
        add_action('woocommerce_account_solicitarile-mele_endpoint', array(__CLASS__, 'account_requests'));
        add_action('admin_init', array(__CLASS__, 'maybe_flush_account_routes'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_account_style'));
        add_shortcode('vinde_scula', array(__CLASS__, 'shortcode'));
        // Păstrează categoria după autentificare / creare cont în WooCommerce.
        add_action('woocommerce_login_form_end', array(__CLASS__, 'auth_return_field'));
        add_action('woocommerce_register_form_end', array(__CLASS__, 'auth_return_field'));
        add_filter('woocommerce_login_redirect', array(__CLASS__, 'auth_return_redirect'), 20, 1);
        add_filter('woocommerce_registration_redirect', array(__CLASS__, 'auth_return_redirect'), 20, 1);
        // Rulează înainte de randarea cardurilor Elementor pentru a evita flash-ul la refresh.
        add_action('wp_head', array(__CLASS__, 'early_category_visibility'), 1);
        add_action('wp_ajax_vsc_trimite', array(__CLASS__, 'send'));
        add_action('wp_ajax_nopriv_vsc_trimite', array(__CLASS__, 'send'));
        add_action('wp_ajax_vsc_contact_profile', array(__CLASS__, 'contact_profile'));
        add_action('wp_ajax_vsc_sale_action', array(__CLASS__, 'handle_sale_action'));
        add_action('wp_ajax_vsc_offer_reply', array(__CLASS__, 'handle_offer_reply'));
        add_action('wp_ajax_vsc_payment_details', array(__CLASS__, 'save_payment_details'));
        add_action('wp_ajax_vsc_finalize_sale', array(__CLASS__, 'finalize_sale'));
        add_action('wp_ajax_vsc_admin_reveal_payment', array(__CLASS__, 'admin_reveal_payment'));
        // Coada de notificări folosește WP-Cron, în loturi, fără să schimbe transportul e-mailurilor.
        add_action('vsc_process_request_background', array(__CLASS__, 'process_background'), 10, 1); // evenimente existente
        add_filter('cron_schedules', array(__CLASS__, 'email_queue_intervals'));
        add_action('init', array(__CLASS__, 'ensure_email_queue_schedule'), 30);
        add_action('vsc_email_queue_tick', array(__CLASS__, 'run_email_queue'));
        add_action('vsc_email_queue_kick', array(__CLASS__, 'run_email_queue'));
        add_action('admin_post_vsc_retry_failed_emails', array(__CLASS__, 'retry_failed_emails'));
        add_action('add_meta_boxes_' . self::TYPE, array(__CLASS__, 'meta_box'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'admin_workflow_assets'));
        add_action('wp_ajax_vsc_admin_workflow', array(__CLASS__, 'admin_workflow'));
        add_filter('manage_' . self::TYPE . '_posts_columns', array(__CLASS__, 'columns'));
        add_action('manage_' . self::TYPE . '_posts_custom_column', array(__CLASS__, 'column'), 10, 2);
        add_action('restrict_manage_posts', array(__CLASS__, 'admin_status_filter'), 10, 2);
        add_action('pre_get_posts', array(__CLASS__, 'admin_filter_requests'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
        // Imagini private: autentificare/autorizație înainte de livrare.
        add_action('admin_post_vsc_private_photo', array(__CLASS__, 'serve_private_photo'));
        add_action('before_delete_post', array(__CLASS__, 'delete_private_photos'));
    }

    /**
     * Fotografii noi: stocare în afara rădăcinii publice, nu în Media Library.
     * Folosim o cale determinată de DOCUMENT_ROOT, memorată pentru WP-Cron.
     * Dacă hostingul nu permite un folder realmente privat, blocăm trimiterea
     * în loc să revenim automat la /uploads/ public.
     */
    private static function private_storage_root($create = false) {
        $webroot = !empty($_SERVER['DOCUMENT_ROOT']) && is_string($_SERVER['DOCUMENT_ROOT'])
            ? realpath(wp_unslash($_SERVER['DOCUMENT_ROOT'])) : false;
        $stored = (string)get_option('vsc_private_storage_path', '');
        $explicit = defined('VSC_PRIVATE_UPLOAD_DIR') && is_string(VSC_PRIVATE_UPLOAD_DIR)
            ? trim(VSC_PRIVATE_UPLOAD_DIR) : '';
        if ($explicit !== '') {
            $dir = $explicit;
        } elseif ($stored !== '') {
            $dir = $stored;
        } elseif ($webroot) {
            $dir = dirname($webroot) . '/.vsc-private-' . substr(hash_hmac('sha256', home_url('/'), wp_salt('auth')), 0, 16);
        } else {
            return '';
        }
        $dir = untrailingslashit(wp_normalize_path($dir));
        if (!preg_match('~^(?:/|[A-Za-z]:/)~', $dir) || $dir === '/') { return ''; }
        // Dacă folderul există, verificăm realpath pentru a respinge symlinkuri.
        $resolved = realpath($dir);
        if ($resolved !== false && is_link($dir)) { return ''; }
        $parent = realpath(dirname($dir));
        if ($parent === false) { return ''; }
        $target = wp_normalize_path($resolved !== false ? $resolved : $parent . '/' . basename($dir));
        $target = untrailingslashit($target);
        $uploads = wp_upload_dir(null, false);
        $upload_base = !empty($uploads['basedir']) ? realpath($uploads['basedir']) : false;
        $public_roots = array($webroot, realpath(ABSPATH), realpath(WP_CONTENT_DIR));
        if ($upload_base) {
            $public_roots[] = $upload_base;
            // Instalațiile WordPress normale țin uploads în wp-content/uploads.
            $public_roots[] = realpath(dirname($upload_base, 2));
        }
        foreach ($public_roots as $root) {
            if (!$root) { continue; }
            $root = untrailingslashit(wp_normalize_path($root));
            if ($target === $root || strpos($target . '/', $root . '/') === 0) { return ''; }
        }
        if ($resolved !== false && !is_dir($dir)) { return ''; }
        if ($create) {
            if (!is_dir($dir) && !wp_mkdir_p($dir)) { return ''; }
            if (!is_dir($dir) || !is_writable($dir)) { return ''; }
            @chmod($dir, 0750);
            if ($explicit === '' && $stored === '') {
                update_option('vsc_private_storage_path', $dir, false);
            }
        } elseif (!is_dir($dir)) {
            return '';
        }
        return $dir;
    }

    private static function private_request_dir($post_id, $create = false) {
        $post_id = absint($post_id);
        if (!$post_id) { return ''; }
        $root = self::private_storage_root($create);
        if (!$root) { return ''; }
        $dir = $root . '/cerere-' . $post_id;
        if ($create) {
            if (is_link($dir) || (!is_dir($dir) && !wp_mkdir_p($dir)) || !is_writable($dir)) { return ''; }
            @chmod($dir, 0750);
        } elseif (!is_dir($dir) || is_link($dir)) { return ''; }
        return $dir;
    }

    private static function private_photos($post_id) {
        $names = get_post_meta($post_id, '_vsc_private_fotografii', true);
        if (!is_array($names)) { return array(); }
        return array_values(array_filter($names, static function($n) {
            return is_string($n) && preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/D', $n);
        }));
    }

    /**
     * Convertim fotografiile NOI în WebP, pe server, în folderul privat.
     * Nu păstrăm fișierul JPEG/PNG original; fișierele vechi rămân nemodificate.
     * Returnează doar numele fișierului final valid sau șir gol la eșec.
     */
    private static function save_private_webp($source, $dir) {
        if (!is_string($source) || !is_uploaded_file($source) ||
            !is_string($dir) || !is_dir($dir) || is_link($dir) || !is_writable($dir)) { return ''; }
        $size = @getimagesize($source);
        if (!is_array($size) || empty($size[0]) || empty($size[1]) ||
            (float)$size[0] * (float)$size[1] > 24000000) { return ''; }
        if (!function_exists('wp_get_image_editor')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $editor = wp_get_image_editor($source);
        if (is_wp_error($editor) || !method_exists($editor, 'supports_mime_type') ||
            !$editor->supports_mime_type('image/webp')) { return ''; }
        // Respectăm și orientarea EXIF a fotografiilor JPEG încărcate direct.
        if (method_exists($editor, 'maybe_exif_rotate') &&
            is_wp_error($editor->maybe_exif_rotate())) { return ''; }

        // Evităm imaginile supradimensionate: max. 1800 px pe latura lungă.
        if (max((int)$size[0], (int)$size[1]) > 1800 &&
            is_wp_error($editor->resize(1800, 1800, false))) { return ''; }
        if (is_wp_error($editor->set_quality(76))) { return ''; }
        try {
            $token = bin2hex(random_bytes(16));
            $unique = bin2hex(random_bytes(5));
        } catch (Exception $e) { return ''; }
        $filename = $token . '.webp';
        $destination = $dir . '/' . $filename;
        $temporary = $dir . '/.webp-' . $token . '-' . $unique . '.webp';
        $saved = $editor->save($temporary, 'image/webp');
        unset($editor);
        if (is_wp_error($saved) || !is_array($saved) || empty($saved['path']) ||
            $saved['path'] !== $temporary || !is_file($temporary) || is_link($temporary) ||
            !is_readable($temporary) || filesize($temporary) <= 0 || filesize($temporary) > 5 * 1024 * 1024) {
            if (is_file($temporary) && !is_link($temporary)) { @unlink($temporary); }
            return '';
        }
        $encoded = @getimagesize($temporary);
        if (!is_array($encoded) || ($encoded['mime'] ?? '') !== 'image/webp' ||
            empty($encoded[0]) || empty($encoded[1]) || max((int)$encoded[0], (int)$encoded[1]) > 1800) {
            @unlink($temporary);
            return '';
        }
        @chmod($temporary, 0640);
        if (file_exists($destination) || !@rename($temporary, $destination)) {
            @unlink($temporary);
            return '';
        }
        @chmod($destination, 0640);
        return $filename;
    }

    private static function private_photo_url($post_id, $filename, $preview = false) {
        if (!in_array($filename, self::private_photos($post_id), true)) { return ''; }
        $args = array('action' => 'vsc_private_photo', 'request_id' => absint($post_id), 'photo' => $filename);
        if ($preview) { $args['size'] = 'preview'; }
        return add_query_arg($args, admin_url('admin-post.php'));
    }

    /** Derivat privat, fără URL direct și fără înregistrare în Biblioteca Media. */
    private static function private_preview_path($dir, $filename) {
        if (!$dir || !is_string($filename) || !preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/D', $filename)) { return ''; }
        return $dir . '/preview-' . substr($filename, 0, 32) . '.jpg';
    }

    /** Miniatura se generează o singură dată; eșecul nu compromite originalul. */
    private static function ensure_private_preview($dir, $filename) {
        $target = self::private_preview_path($dir, $filename);
        if (!$target || is_link($target)) { return ''; }
        if (is_file($target) && is_readable($target) && filesize($target) > 0) { return $target; }
        $source = $dir . '/' . $filename;
        if (!is_file($source) || is_link($source) || !is_readable($source)) { return ''; }
        // Evităm consumul excesiv de memorie pentru imagini anormal de mari.
        $dimensions = @getimagesize($source);
        if (!is_array($dimensions) || empty($dimensions[0]) || empty($dimensions[1]) ||
            (float)$dimensions[0] * (float)$dimensions[1] > 24000000) { return ''; }
        if (!function_exists('wp_get_image_editor')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $editor = wp_get_image_editor($source);
        if (is_wp_error($editor)) { return ''; }
        if (is_wp_error($editor->resize(640, 640, false))) { return ''; }
        $editor->set_quality(76);
        try { $suffix = bin2hex(random_bytes(5)); } catch (Exception $e) { return ''; }
        $temporary = $dir . '/.preview-' . substr($filename, 0, 32) . '-' . $suffix . '.jpg';
        $saved = $editor->save($temporary, 'image/jpeg');
        if (is_wp_error($saved) || !is_array($saved) || empty($saved['path']) ||
            $saved['path'] !== $temporary || !is_file($temporary) || is_link($temporary) || filesize($temporary) <= 0) {
            if (is_file($temporary) && !is_link($temporary)) { @unlink($temporary); }
            return '';
        }
        @chmod($temporary, 0640);
        // Două cereri simultane pot genera miniatura: păstrăm primul fișier valid.
        if (is_file($target) && !is_link($target) && filesize($target) > 0) {
            @unlink($temporary);
            return $target;
        }
        if (!@rename($temporary, $target)) {
            @unlink($temporary);
            return '';
        }
        @chmod($target, 0640);
        return $target;
    }

    /** Miniatură separată pentru lista Vânzări (max. 160 px, doar în folderul privat). */
    private static function private_list_thumbnail_path($dir, $filename) {
        if (!$dir || !is_string($filename) || !preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/D', $filename)) { return ''; }
        return $dir . '/list-' . substr($filename, 0, 32) . '.jpg';
    }

    private static function ensure_private_list_thumbnail($dir, $filename) {
        $target = self::private_list_thumbnail_path($dir, $filename);
        if (!$target || is_link($target)) { return ''; }
        if (is_file($target) && is_readable($target) && filesize($target) > 0) { return $target; }
        // Derivăm miniatura mică din preview-ul deja privat, nu recitim originalul mare.
        $source = self::ensure_private_preview($dir, $filename);
        if (!$source) { return ''; }
        if (!function_exists('wp_get_image_editor')) { require_once ABSPATH . 'wp-admin/includes/image.php'; }
        $editor = wp_get_image_editor($source);
        if (is_wp_error($editor) || is_wp_error($editor->resize(160, 160, false))) { return ''; }
        $editor->set_quality(64);
        try { $suffix = bin2hex(random_bytes(5)); } catch (Exception $e) { return ''; }
        $temporary = $dir . '/.list-' . substr($filename, 0, 32) . '-' . $suffix . '.jpg';
        $saved = $editor->save($temporary, 'image/jpeg');
        if (is_wp_error($saved) || !is_array($saved) || empty($saved['path']) ||
            $saved['path'] !== $temporary || !is_file($temporary) || is_link($temporary) || filesize($temporary) <= 0) {
            if (is_file($temporary) && !is_link($temporary)) { @unlink($temporary); }
            return '';
        }
        @chmod($temporary, 0640);
        if (is_file($target) && !is_link($target) && filesize($target) > 0) {
            @unlink($temporary);
            return $target;
        }
        if (!@rename($temporary, $target)) {
            @unlink($temporary);
            return '';
        }
        @chmod($target, 0640);
        return $target;
    }

    /** Miniatură de detalii (max. 320 px) păstrată exclusiv în folderul privat. */
    private static function private_gallery_thumbnail_path($dir, $filename) {
        if (!$dir || !is_string($filename) || !preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/D', $filename)) { return ''; }
        return $dir . '/gallery-' . substr($filename, 0, 32) . '.jpg';
    }

    private static function ensure_private_gallery_thumbnail($dir, $filename) {
        $target = self::private_gallery_thumbnail_path($dir, $filename);
        if (!$target || is_link($target)) { return ''; }
        if (is_file($target) && is_readable($target) && filesize($target) > 0) { return $target; }
        // Folosim preview-ul de 640 px, fără să decodăm încă o dată originalul mare.
        $source = self::ensure_private_preview($dir, $filename);
        if (!$source) { return ''; }
        if (!function_exists('wp_get_image_editor')) { require_once ABSPATH . 'wp-admin/includes/image.php'; }
        $editor = wp_get_image_editor($source);
        if (is_wp_error($editor) || is_wp_error($editor->resize(320, 320, false))) { return ''; }
        $editor->set_quality(70);
        try { $suffix = bin2hex(random_bytes(5)); } catch (Exception $e) { return ''; }
        $temporary = $dir . '/.gallery-' . substr($filename, 0, 32) . '-' . $suffix . '.jpg';
        $saved = $editor->save($temporary, 'image/jpeg');
        if (is_wp_error($saved) || !is_array($saved) || empty($saved['path']) ||
            $saved['path'] !== $temporary || !is_file($temporary) || is_link($temporary) || filesize($temporary) <= 0) {
            if (is_file($temporary) && !is_link($temporary)) { @unlink($temporary); }
            return '';
        }
        @chmod($temporary, 0640);
        if (is_file($target) && !is_link($target) && filesize($target) > 0) {
            @unlink($temporary);
            return $target;
        }
        if (!@rename($temporary, $target)) {
            @unlink($temporary);
            return '';
        }
        @chmod($target, 0640);
        return $target;
    }

    /** Date JPEG în pagina de detalii, numai pentru proprietarul autentificat sau admin. */
    private static function private_gallery_thumbnail_data_url($post_id, $filename) {
        $post_id = absint($post_id);
        $post = $post_id ? get_post($post_id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            !is_user_logged_in() || !(current_user_can('edit_post', $post_id) ||
                ((int)$post->post_author > 0 && (int)$post->post_author === get_current_user_id())) ||
            !in_array($filename, self::private_photos($post_id), true)) { return ''; }
        $dir = self::private_request_dir($post_id);
        $path = $dir ? self::ensure_private_gallery_thumbnail($dir, $filename) : '';
        if (!$path || is_link($path) || !is_readable($path) || !is_file($path)) { return ''; }
        // Cel mult 100 KiB / miniatură; la eșec folosim preview-ul privat existent.
        $length = filesize($path);
        if (!$length || $length > 102400) { return ''; }
        $data = @file_get_contents($path);
        if ($data === false || strlen($data) !== $length || substr($data, 0, 2) !== "\xff\xd8") { return ''; }
        return 'data:image/jpeg;base64,' . base64_encode($data);
    }

    /** În lista privată evităm o cerere admin-post.php pentru fiecare rând.
     * HTML-ul contului este deja destinat exclusiv utilizatorului autentificat.
     */
    private static function private_list_thumbnail_data_url($post_id, $filename) {
        $post_id = absint($post_id);
        $post = $post_id ? get_post($post_id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            !is_user_logged_in() || !(current_user_can('edit_post', $post_id) ||
                ((int)$post->post_author > 0 && (int)$post->post_author === get_current_user_id())) ||
            !in_array($filename, self::private_photos($post_id), true)) { return ''; }
        $dir = self::private_request_dir($post_id);
        $path = $dir ? self::ensure_private_list_thumbnail($dir, $filename) : '';
        if (!$path || is_link($path) || !is_readable($path) || !is_file($path)) { return ''; }
        // Plafon împotriva încorporării accidentale a unor fișiere prea mari în pagină.
        $length = filesize($path);
        if (!$length || $length > 49152) { return ''; }
        $data = @file_get_contents($path);
        if ($data === false || strlen($data) !== $length || substr($data, 0, 2) !== "\xff\xd8") { return ''; }
        return 'data:image/jpeg;base64,' . base64_encode($data);
    }

    /** Doar autorul autentificat al solicitării sau un administrator autorizat. */
    public static function serve_private_photo() {
        $id = isset($_GET['request_id']) && is_scalar($_GET['request_id']) ? absint(wp_unslash($_GET['request_id'])) : 0;
        $filename = isset($_GET['photo']) && is_string($_GET['photo']) ? wp_unslash($_GET['photo']) : '';
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            !is_user_logged_in() || !(current_user_can('edit_post', $id) ||
                ((int)$post->post_author > 0 && (int)$post->post_author === get_current_user_id())) ||
            !in_array($filename, self::private_photos($id), true)) {
            status_header(403);
            nocache_headers();
            exit;
        }
        $dir = self::private_request_dir($id);
        $path = $dir ? $dir . '/' . $filename : '';
        if (!$path || !is_file($path) || is_link($path) || !is_readable($path)) {
            status_header(404);
            nocache_headers();
            exit;
        }
        // Miniatura se servește numai după aceeași autorizare ca originalul.
        // Pentru fotografiile deja stocate, generarea este automată la prima vizualizare.
        $preview = isset($_GET['size']) && is_string($_GET['size']) && wp_unslash($_GET['size']) === 'preview';
        if ($preview) {
            $small = self::ensure_private_preview($dir, $filename);
            if ($small) { $path = $small; }
        }
        $mime = array('jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp');
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!isset($mime[$ext])) { status_header(404); exit; }
        status_header(200);
        nocache_headers();
        // Doar cache privat în browser, niciodată cache partajat/CDN.
        header('Cache-Control: private, max-age=300, must-revalidate', true);
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 300) . ' GMT', true);
        header('Pragma:', true);
        header('Vary: Cookie', false);
        header('Content-Type: ' . $mime[$ext]);
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Content-Disposition: inline; filename="fotografie.' . $ext . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    /** Curățăm exclusiv fotografiile private ale solicitării șterse definitiv. */
    public static function delete_private_photos($post_id) {
        if (get_post_type($post_id) !== self::TYPE) { return; }
        self::remove_private_photos($post_id, self::private_photos($post_id));
    }

    private static function remove_private_photos($post_id, $names) {
        $dir = self::private_request_dir($post_id);
        if (!$dir) { return; }
        foreach ($names as $name) {
            if (is_string($name) && preg_match('/^[a-f0-9]{32}\.(?:jpg|png|webp)$/D', $name)) {
                $path = $dir . '/' . $name;
                if (is_file($path) && !is_link($path)) { @unlink($path); }
                $preview = self::private_preview_path($dir, $name);
                if ($preview && is_file($preview) && !is_link($preview)) { @unlink($preview); }
                $list_thumb = self::private_list_thumbnail_path($dir, $name);
                if ($list_thumb && is_file($list_thumb) && !is_link($list_thumb)) { @unlink($list_thumb); }
                $gallery_thumb = self::private_gallery_thumbnail_path($dir, $name);
                if ($gallery_thumb && is_file($gallery_thumb) && !is_link($gallery_thumb)) { @unlink($gallery_thumb); }
            }
        }
        // Nu ștergem fișiere necunoscute și nu folosim ștergere recursivă.
        @rmdir($dir);
    }

    /** Numărul afișat: format scurt (#26220), fără a modifica ID-ul WordPress. */
    private static function reference($post_id) {
        return '#' . (string)absint($post_id);
    }

    /** Endpoint WooCommerce pentru Vânzări; ruta veche rămâne validă. */
    public static function register_account_endpoint() {
        add_rewrite_endpoint('vanzari', EP_ROOT | EP_PAGES);
        add_rewrite_endpoint('solicitarile-mele', EP_ROOT | EP_PAGES);
    }

    public static function account_query_vars($vars) {
        $vars['vanzari'] = 'vanzari';
        $vars['solicitarile-mele'] = 'solicitarile-mele';
        return $vars;
    }

    /** Identificatorul evenimentului de ofertă, separat pentru fiecare revizuire. */
    private static function unread_offer_token($post_id) {
        $state = self::workflow_state($post_id);
        if ($state === 'oferta_revizuita') {
            $sent = (string)get_post_meta($post_id, '_vsc_revision_sent_at', true);
            return $sent !== '' ? 'revision:' . $sent : '';
        }
        if ($state === 'oferta_trimisa') {
            $sent = (string)get_post_meta($post_id, '_vsc_offer_sent_at', true);
            return $sent !== '' ? 'offer:' . $sent : '';
        }
        return '';
    }

    /** Returnează numărul de oferte încă nevizualizate ale clientului. */
    private static function unread_offer_count($user_id) {
        if (!$user_id) { return 0; }
        $ids = get_posts(array('post_type' => self::TYPE, 'post_status' => 'private',
            'author' => $user_id, 'fields' => 'ids', 'numberposts' => -1,
            'no_found_rows' => true, 'meta_query' => array(array('key' => '_vsc_status',
                'value' => array('oferta_trimisa', 'oferta_revizuita'), 'compare' => 'IN'))));
        $unread = 0;
        foreach ($ids as $id) {
            $token = self::unread_offer_token($id);
            if ($token !== '' && get_user_meta($user_id, '_vsc_offer_seen_' . $id, true) !== $token) {
                ++$unread;
            }
        }
        return $unread;
    }

    /** Markare doar după accesarea detaliilor de către proprietarul autentificat. */
    private static function mark_offer_seen($post_id, $user_id) {
        $token = self::unread_offer_token($post_id);
        if ($token !== '') {
            update_user_meta($user_id, '_vsc_offer_seen_' . $post_id, $token);
        }
    }

    /** Înregistrează vizualizarea înaintea randării meniului, astfel încât indicatorul dispare imediat. */
    public static function mark_offer_viewed_on_detail() {
        if (!is_user_logged_in() || !function_exists('is_account_page') || !is_account_page() ||
            !function_exists('is_wc_endpoint_url') ||
            (!is_wc_endpoint_url('vanzari') && !is_wc_endpoint_url('solicitarile-mele'))) { return; }
        $id = isset($_GET['vsc_detalii']) && is_scalar($_GET['vsc_detalii'])
            ? absint(wp_unslash($_GET['vsc_detalii'])) : 0;
        if (!$id) { return; }
        $post = get_post($id);
        $user_id = get_current_user_id();
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)$user_id) { return; }
        self::mark_offer_seen($id, $user_id);
    }

    /** Inserează Vânzări imediat după meniul WooCommerce Comenzi. */
    public static function account_menu($items) {
        $updated = array();
        $inserted = false;
        foreach ($items as $key => $label) {
            // Nu păstrăm intrări duplicate din configurații vechi.
            if ($key === 'vanzari' || $key === 'solicitarile-mele') { continue; }
            // Fallback dacă meniul Comenzi lipsește (ex.: extensie care îl ascunde).
            if ($key === 'customer-logout' && !$inserted) {
                $updated['vanzari'] = 'Vânzări';
                $inserted = true;
            }
            $updated[$key] = $label;
            if ($key === 'orders') {
                $updated['vanzari'] = 'Vânzări';
                $inserted = true;
            }
        }
        if (!$inserted) { $updated['vanzari'] = 'Vânzări'; }
        return $updated;
    }

    /** La actualizarea unui plugin activ nu rulează hook-ul de activare. */
    public static function maybe_flush_account_routes() {
        if (!class_exists('WooCommerce') || get_option('vsc_account_routes_ready') === 'vanzari-v1') { return; }
        flush_rewrite_rules(false);
        update_option('vsc_account_routes_ready', 'vanzari-v1', false);
    }

    public static function activate() {
        self::register_account_endpoint();
        flush_rewrite_rules(false);
        update_option('vsc_account_routes_ready', 'vanzari-v1', false);
        self::ensure_email_queue_schedule();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook('vsc_shipments_cleanup');
        wp_clear_scheduled_hook('vsc_email_queue_tick');
        wp_clear_scheduled_hook('vsc_email_queue_kick');
        flush_rewrite_rules(false);
    }

    /** Pictograme locale; nu încărcăm fonturi sau biblioteci noi. */
    private static function account_icon($name) {
        $paths = array(
            'eye' => '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
            'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
            'image' => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
            'back' => '<path d="m14 18-6-6 6-6"/><path d="M8 12h13"/>',
            'edit' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L9 17l-4 1 1-4L16.5 3.5z"/>',
            'withdraw' => '<path d="M6 6l12 12M18 6 6 18"/><circle cx="12" cy="12" r="9"/>',
        );
        if (!isset($paths[$name])) { return ''; }
        return '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
    }

    /** Etichete din perspectiva vânzătorului, fără a modifica starea internă. */
    private static function account_status($post_id) {
        $status = self::workflow_state($post_id);
        $available = array(
            'primita' => array('Cerere trimisă', 'received'),
            'in_evaluare' => array('În evaluare', 'evaluation'),
            'oferta_trimisa' => array('Ofertă primită', 'offer'),
            'finalizata' => array('Finalizată', 'complete'),
            'acceptata' => array('Ai acceptat', 'accepted'),
            'ridicare_programata' => array('Ridicare programată', 'shipping'),
            'in_transport' => array('În transport', 'shipping'),
            'la_verificare' => array('În verificare', 'evaluation'),
            'oferta_revizuita' => array('Ofertă revizuită', 'offer'),
            'verificare_confirmata' => array('Verificare finalizată', 'accepted'),
            'retur_pregatit' => array('Retur în pregătire', 'shipping'),
            'returnata' => array('Produs returnat', 'withdrawn'),
            'platita' => array('Plată efectuată', 'complete'),
            'respinsa' => array('Cerere respinsă', 'rejected'),
            'retrasa' => array('Retrasă', 'withdrawn'),
        );
        // O ofertă refuzată de vânzător nu este o cerere respinsă de magazin.
        if ($status === 'respinsa' && (string)get_post_meta($post_id, '_vsc_offer_reply', true) === 'refuse') {
            return array('Ai refuzat', 'rejected');
        }
        return isset($available[$status]) ? $available[$status] : array('Cerere trimisă', 'received');
    }

    /** Etichete din perspectiva magazinului; vezi și workflow_labels(). */
    private static function admin_status_label($post_id) {
        $status = self::workflow_state($post_id);
        if ($status === 'respinsa' && (string)get_post_meta($post_id, '_vsc_offer_reply', true) === 'refuse') {
            return 'Refuzată de client';
        }
        $labels = self::workflow_labels();
        return isset($labels[$status]) ? $labels[$status] : 'Cerere primită';
    }

    /** Etichetă vizibilă în listele de administrare; stările interne rămân nemodificate. */
    private static function admin_status_badge($post_id) {
        $state = self::workflow_state($post_id);
        $tones = array(
            'primita' => 'received',
            'in_evaluare' => 'evaluation',
            'oferta_trimisa' => 'offer',
            'oferta_revizuita' => 'offer',
            'acceptata' => 'accepted',
            'ridicare_programata' => 'shipping',
            'in_transport' => 'shipping',
            'la_verificare' => 'checking',
            'verificare_confirmata' => 'checking',
            'retur_pregatit' => 'shipping',
            'returnata' => 'closed',
            'platita' => 'complete',
            'finalizata' => 'closed',
            'respinsa' => 'rejected',
            'retrasa' => 'muted',
        );
        $tone = isset($tones[$state]) ? $tones[$state] : 'received';
        return '<span class="vsc-admin-status-badge vsc-admin-status-badge--' . esc_attr($tone) . '">'
            . esc_html(self::admin_status_label($post_id)) . '</span>';
    }

    /** Doar solicitările încă primite pot fi editate sau retrase. */
    private static function sale_is_editable($post_id) {
        $state = (string)get_post_meta($post_id, '_vsc_status', true);
        return $state === '' || $state === 'primita' || $state === 'primită';
    }

    /** Acțiuni AJAX: validare nonce, cont proprietar și stare pe server. */
    public static function handle_sale_action() {
        if (!is_user_logged_in() || !check_ajax_referer('vsc_sale_action', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat. Reîncarcă pagina și încearcă din nou.'), 403);
        }
        $id = isset($_POST['sale_id']) && is_scalar($_POST['sale_id']) ? absint(wp_unslash($_POST['sale_id'])) : 0;
        $action = isset($_POST['sale_action']) && is_scalar($_POST['sale_action'])
            ? sanitize_key(wp_unslash($_POST['sale_action'])) : '';
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)get_current_user_id()) {
            wp_send_json_error(array('message' => 'Solicitarea nu a fost găsită în contul tău.'), 403);
        }
        if (!self::sale_is_editable($id)) {
            wp_send_json_error(array('message' => 'Solicitarea nu mai poate fi modificată, deoarece nu mai este în starea Cerere trimisă.'), 409);
        }
        if ($action === 'price') {
            $raw = isset($_POST['price']) && is_scalar($_POST['price'])
                ? trim(sanitize_text_field(wp_unslash($_POST['price']))) : '';
            // Acceptăm 450, 450.50 sau 450,50, fără separatori ambigui de mii.
            if (!preg_match('/^\d{1,7}(?:[\.,]\d{1,2})?$/D', $raw)) {
                wp_send_json_error(array('message' => 'Introdu un preț valid, cu maximum două zecimale.'), 400);
            }
            $price = round((float)str_replace(',', '.', $raw), 2);
            if ($price < 1 || $price > 1000000) {
                wp_send_json_error(array('message' => 'Prețul trebuie să fie între 1 și 1.000.000 lei.'), 400);
            }
            update_post_meta($id, '_vsc_pret', $price);
            wp_send_json_success(array('message' => 'Prețul dorit a fost actualizat.', 'price' => number_format_i18n($price, 2) . ' lei'));
        }
        if ($action === 'withdraw') {
            update_post_meta($id, '_vsc_status', 'retrasa');
            update_post_meta($id, '_vsc_retrasa_la', current_time('mysql'));
            wp_send_json_success(array('message' => 'Solicitarea a fost retrasă și rămâne în istoricul Vânzări.', 'status' => 'Retrasă'));
        }
        wp_send_json_error(array('message' => 'Acțiune necunoscută.'), 400);
    }

    /**
     * Clientul poate răspunde DOAR unei oferte efectiv trimise.
     * Update-ul condițional împiedică două acceptări/refuzuri concurente.
     */
    public static function handle_offer_reply() {
        if (!is_user_logged_in() || !check_ajax_referer('vsc_sale_action', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat. Reîncarcă pagina și încearcă din nou.'), 403);
        }
        $id = isset($_POST['sale_id']) && is_scalar($_POST['sale_id']) ? absint(wp_unslash($_POST['sale_id'])) : 0;
        $choice = isset($_POST['offer_choice']) && is_scalar($_POST['offer_choice'])
            ? sanitize_key(wp_unslash($_POST['offer_choice'])) : '';
        if (!in_array($choice, array('accept', 'refuse'), true)) {
            wp_send_json_error(array('message' => 'Răspuns invalid.'), 400);
        }
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)get_current_user_id()) {
            wp_send_json_error(array('message' => 'Solicitarea nu aparține contului tău.'), 403);
        }
        // O contraofertă după inspecție are propria decizie și propriul istoric.
        if (self::workflow_state($id) === 'oferta_revizuita') {
            $revision = (float)get_post_meta($id, '_vsc_revision_amount', true);
            if ($revision <= 0 || !get_post_meta($id, '_vsc_revision_sent_at', true) ||
                get_post_meta($id, '_vsc_revision_reply', true)) {
                wp_send_json_error(array('message' => 'Oferta revizuită nu este disponibilă pentru răspuns.'), 409);
            }
            $next = $choice === 'accept' ? 'verificare_confirmata' : 'retur_pregatit';
            if (!self::change_workflow_state($id, 'oferta_revizuita', $next)) {
                wp_send_json_error(array('message' => 'Solicitarea a fost actualizată. Reîncarcă pagina.'), 409);
            }
            update_post_meta($id, '_vsc_revision_reply', $choice);
            update_post_meta($id, '_vsc_revision_reply_at', current_time('mysql'));
            if ($choice === 'accept') {
                // Păstrăm suma inițială în istoric, fără a o confunda cu cea nou acceptată.
                update_post_meta($id, '_vsc_offer_amount', $revision);
            }
            self::workflow_log($id, 'revision_reply', $choice === 'accept'
                ? 'Clientul a acceptat suma revizuită de ' . number_format_i18n($revision, 2) . ' lei.'
                : 'Clientul a refuzat oferta revizuită și se pregătește returul.');
            $admin_mail = self::send_email('info@sculebune.ro',
                'Răspuns ofertă revizuită – ' . self::reference($id),
                self::email_layout('Răspuns la oferta revizuită',
                    $choice === 'accept' ? 'Clientul a acceptat noua evaluare.' : 'Clientul a refuzat noua evaluare. Pregătește returul.',
                    self::email_details(array('Solicitare' => self::reference($id),
                        'Suma revizuită' => number_format_i18n($revision, 2) . ' lei',
                        'Răspuns' => $choice === 'accept' ? 'Acceptată' : 'Refuzată'))), self::email_headers());
            update_post_meta($id, '_vsc_revision_notice', $admin_mail ? 'accepted_by_mail_server' : 'failed');
            wp_send_json_success(array('message' => $choice === 'accept'
                ? 'Ai acceptat oferta revizuită. Pregătim plata.'
                : 'Ai refuzat oferta revizuită. Pregătim returnarea produsului.'));
        }
        if (self::workflow_state($id) !== 'oferta_trimisa' ||
            !get_post_meta($id, '_vsc_offer_sent_at', true) ||
            (float)get_post_meta($id, '_vsc_offer_amount', true) <= 0) {
            wp_send_json_error(array('message' => 'Oferta nu mai poate fi acceptată sau refuzată. Reîncarcă pagina.'), 409);
        }
        $target = $choice === 'accept' ? 'acceptata' : 'respinsa';
        global $wpdb;
        // Compare-and-swap: funcționează doar dacă starea este încă „oferta_trimisa”.
        $changed = $wpdb->update(
            $wpdb->postmeta,
            array('meta_value' => $target),
            array('post_id' => $id, 'meta_key' => '_vsc_status', 'meta_value' => 'oferta_trimisa'),
            array('%s'), array('%d', '%s', '%s')
        );
        if ($changed === false || $changed < 1) {
            wp_send_json_error(array('message' => 'Solicitarea a fost actualizată între timp. Reîncarcă pagina.'), 409);
        }
        wp_cache_delete($id, 'post_meta');
        update_post_meta($id, '_vsc_offer_reply', $choice);
        update_post_meta($id, '_vsc_offer_reply_at', current_time('mysql'));
        update_post_meta($id, '_vsc_offer_reply_user', get_current_user_id());
        update_post_meta($id, '_vsc_offer_reply_notice', 'pending');
        update_post_meta($id, '_vsc_offer_reply_notice_attempts', 0);
        self::workflow_log($id, 'client_offer_reply', $choice === 'accept'
            ? 'Clientul a acceptat oferta din contul Vânzări.'
            : 'Clientul a refuzat oferta din contul Vânzări.');
        // Folosim coada deja existentă: un singur cron pentru toate răspunsurile,
        // inclusiv atunci când mai mulți clienți decid în același timp.
        update_post_meta($id, '_vsc_offer_reply_notice_next_run', time());
        self::ensure_email_queue_schedule();
        if (!self::kick_email_queue() && !wp_next_scheduled('vsc_email_queue_tick')) {
            update_post_meta($id, '_vsc_offer_reply_notice', 'schedule_failed');
        }
        wp_send_json_success(array('message' => $choice === 'accept'
            ? 'Ai acceptat oferta. Scule Bune va organiza ridicarea produsului și îți va comunica pașii următori.'
            : 'Ai refuzat oferta. Răspunsul a fost înregistrat.'));
    }

    /** Notificarea proprietarului magazinului: reîncercare automată, fără dubluri intenționate. */
    public static function notify_offer_response($post_id) {
        $id = absint($post_id);
        if (!$id || get_post_type($id) !== self::TYPE || get_post_status($id) !== 'private') { return; }
        $choice = (string)get_post_meta($id, '_vsc_offer_reply', true);
        if (!in_array($choice, array('accept', 'refuse'), true)) { return; }
        if ((string)get_post_meta($id, '_vsc_offer_reply_notice', true) === 'sent') { return; }
        $lock_key = 'vsc_offer_reply_lock_' . $id;
        if (!add_option($lock_key, time(), '', 'no')) {
            $lock_at = (int)get_option($lock_key, 0);
            if (!$lock_at || $lock_at >= time() - 15 * MINUTE_IN_SECONDS) { return; }
            delete_option($lock_key);
            if (!add_option($lock_key, time(), '', 'no')) { return; }
        }
        try {
            if ((string)get_post_meta($id, '_vsc_offer_reply_notice', true) === 'sent') { return; }
            $attempts = (int)get_post_meta($id, '_vsc_offer_reply_notice_attempts', true) + 1;
            update_post_meta($id, '_vsc_offer_reply_notice_attempts', $attempts);
            $recipient = 'info@sculebune.ro';
            $accepted = $choice === 'accept';
            $name = (string)get_post_meta($id, '_vsc_nume', true);
            $brand = (string)get_post_meta($id, '_vsc_marca', true);
            $model = (string)get_post_meta($id, '_vsc_model', true);
            $amount = (float)get_post_meta($id, '_vsc_offer_amount', true);
            $subject = ($accepted ? 'Ofertă acceptată – ' : 'Ofertă refuzată – ') . self::reference($id) . ' – Vinde Scula';
            $body = self::email_layout(
                $accepted ? 'Clientul a acceptat oferta' : 'Clientul a refuzat oferta',
                'Un client a răspuns la oferta transmisă prin Vinde Scula.',
                self::email_details(array(
                    'Solicitare' => self::reference($id),
                    'Client' => $name,
                    'Produs' => trim($brand . ' ' . $model),
                    'Oferta transmisă' => number_format_i18n($amount, 2) . ' lei',
                    'Răspuns' => $accepted ? 'Acceptată' : 'Refuzată',
                    'Data răspunsului' => (string)get_post_meta($id, '_vsc_offer_reply_at', true),
                )) . '<p><a href="' . esc_url(admin_url('post.php?post=' . $id . '&action=edit')) . '">Deschide solicitarea în administrare</a></p>'
            );
            if (self::send_email($recipient, $subject, $body, self::email_headers())) {
                update_post_meta($id, '_vsc_offer_reply_notice', 'sent');
                delete_post_meta($id, '_vsc_offer_reply_notice_next_run');
                self::workflow_log($id, 'reply_notice', 'Notificarea despre răspunsul clientului a fost predată serverului de e-mail.');
                return;
            }
            if ($attempts >= 3) {
                update_post_meta($id, '_vsc_offer_reply_notice', 'failed');
                delete_post_meta($id, '_vsc_offer_reply_notice_next_run');
                self::workflow_log($id, 'reply_notice_failed', 'Trimiterea notificării de răspuns a eșuat după 3 încercări.');
            } else {
                update_post_meta($id, '_vsc_offer_reply_notice', 'retry');
                $delay = $attempts === 1 ? 5 * MINUTE_IN_SECONDS : 15 * MINUTE_IN_SECONDS;
                update_post_meta($id, '_vsc_offer_reply_notice_next_run', time() + $delay);
            }
        } finally {
            delete_option($lock_key);
        }
    }

    /** Detalii protejate pe server după autor; identificatorul nu acordă acces. */
    private static function account_request_details($post_id, $user_id) {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)$user_id) {
            echo '<p class="woocommerce-error" role="alert">Nu am găsit această solicitare în contul tău.</p>';
            return;
        }
        $base = wc_get_account_endpoint_url('vanzari');
        $categories = self::categories();
        $category = (string)get_post_meta($post_id, '_vsc_categoria', true);
        $category_label = isset($categories[$category]) ? $categories[$category]['title'] : 'Produs';
        $brand = (string)get_post_meta($post_id, '_vsc_marca', true);
        $model = (string)get_post_meta($post_id, '_vsc_model', true);
        $name = trim($brand . ' ' . $model);
        $status = self::account_status($post_id);
        $photos = get_post_meta($post_id, '_vsc_fotografii', true);
        if (!is_array($photos)) { $photos = array(); }
        $private_photos = self::private_photos($post_id);
        $fields = array(
            'Nr. comenzii' => self::reference($post_id),
            'Categorie' => $category_label,
            'Marcă' => $brand,
            'Model' => $model,
            'Starea produsului' => get_post_meta($post_id, '_vsc_stare', true),
            'Data' => get_the_date('j M Y', $post_id),
        );
        $package = (string)get_post_meta($post_id, '_vsc_pachet', true);
        if ($category === 'scule-acumulator') {
            $options = self::package_options();
            if (isset($options[$package])) { $fields['Configurație'] = $options[$package]; }
        }
        $manufacture_year_display = (string)get_post_meta($post_id, '_vsc_an_fabricatie', true);
        if ($manufacture_year_display !== '') { $fields['An fabricație'] = $manufacture_year_display; }
        $platform_display = (string)get_post_meta($post_id, '_vsc_platforma', true);
        if ($platform_display !== '') { $fields['Platformă acumulator'] = $platform_display; }
        foreach (self::kit_details_for_display($post_id) as $label => $value) { $fields[$label] = $value; }
        $description = (string)get_post_meta($post_id, '_vsc_descriere', true);
        $city = (string)get_post_meta($post_id, '_vsc_localitate', true);
        $county = (string)get_post_meta($post_id, '_vsc_judet', true);
        if ($city !== '' || $county !== '') { $fields['Localitate'] = trim($city . ($city && $county ? ', ' : '') . $county); }
        if (get_post_meta($post_id, '_vsc_metoda_incasare', true) === 'transfer_bancar') { $fields['Metoda de încasare'] = 'Transfer bancar'; }
        if (in_array(self::workflow_state($post_id), array('oferta_trimisa','acceptata','finalizata','ridicare_programata','in_transport','la_verificare','oferta_revizuita','verificare_confirmata','retur_pregatit','returnata','platita'), true) ||
            (self::workflow_state($post_id) === 'respinsa' && get_post_meta($post_id, '_vsc_offer_reply', true) === 'refuse')) {
            $fields['Oferta Scule Bune'] = number_format_i18n((float)get_post_meta($post_id, '_vsc_offer_amount', true), 2) . ' lei';
            $offer_message = (string)get_post_meta($post_id, '_vsc_offer_message', true);
            if ($offer_message !== '') { $fields['Mesajul ofertei'] = $offer_message; }
        }
        echo '<div class="vsc-sale-detail">';
        echo '<div class="vsc-sale-detail__heading"><div><span class="vsc-sale-detail__eyebrow">' . esc_html(self::reference($post_id)) . '</span>';
        echo '<h2>' . esc_html($name !== '' ? $name : 'Produs') . '</h2></div>';
        echo '<a class="vsc-sale-back" href="' . esc_url($base) . '">' . self::account_icon('back') . ' Înapoi la Vânzări</a></div>';
        // Mesaj contextual imediat sub titlu, din perspectiva clientului.
        // Un singur mesaj per stare; nu schimbăm starea internă și nici acțiunile.
        $workflow_state = self::workflow_state($post_id);
        $offer_reply = (string)get_post_meta($post_id, '_vsc_offer_reply', true);
        $revision_reply = (string)get_post_meta($post_id, '_vsc_revision_reply', true);
        $notice_tone = 'info';
        $notice_text = '';
        switch ($workflow_state) {
            case 'primita':
                $notice_text = 'Cererea ta a fost trimisă. Te vom informa după analizarea ei.';
                break;
            case 'in_evaluare':
                $notice_text = 'Cererea ta este în evaluare. Te vom anunța când avem un răspuns.';
                break;
            case 'oferta_trimisa':
                if (get_post_meta($post_id, '_vsc_offer_sent_at', true) &&
                    (float)get_post_meta($post_id, '_vsc_offer_amount', true) > 0) {
                    $notice_text = 'Ai primit o ofertă de la Scule Bune. O poți accepta sau refuza mai jos.';
                    $notice_tone = 'warning';
                }
                break;
            case 'acceptata':
                $notice_text = get_post_meta($post_id, '_vsc_checkout_completed_at', true)
                    ? 'Ai finalizat vânzarea. Organizăm ridicarea prin curier și îți vom comunica instrucțiunile.'
                    : 'Ai acceptat oferta. Finalizează vânzarea mai jos, pentru a putea organiza ridicarea.';
                $notice_tone = 'success';
                break;
            case 'respinsa':
                $notice_text = $offer_reply === 'refuse'
                    ? 'Ai refuzat oferta. Răspunsul tău a fost înregistrat.'
                    : 'Cererea ta a fost respinsă de Scule Bune.';
                $notice_tone = 'danger';
                break;
            case 'ridicare_programata':
                $notice_text = 'Ridicarea produsului a fost programată. Urmează instrucțiunile de la Scule Bune.';
                break;
            case 'in_transport':
                $notice_text = 'Produsul este în transport către Scule Bune.';
                break;
            case 'la_verificare':
                $notice_text = 'Produsul a ajuns la verificare. Te vom informa despre rezultat.';
                break;
            case 'oferta_revizuita':
                $notice_text = 'Ai primit o ofertă revizuită. Verifică suma și răspunde mai jos.';
                $notice_tone = 'warning';
                break;
            case 'verificare_confirmata':
                $notice_text = 'Verificarea produsului s-a încheiat. Urmează plata prin transfer bancar.';
                $notice_tone = 'success';
                break;
            case 'retur_pregatit':
                $notice_text = $revision_reply === 'refuse'
                    ? 'Ai refuzat oferta revizuită. Pregătim returnarea produsului.'
                    : 'Pregătim returnarea produsului. Vei primi detaliile de expediere.';
                $notice_tone = $revision_reply === 'refuse' ? 'danger' : 'warning';
                break;
            case 'returnata':
                $notice_text = 'Produsul a fost returnat.';
                $notice_tone = 'neutral';
                break;
            case 'platita':
                $notice_text = 'Plata a fost marcată ca efectuată. Încasarea poate depinde de banca ta.';
                $notice_tone = 'success';
                break;
            case 'finalizata':
                $notice_text = 'Vânzarea a fost finalizată.';
                $notice_tone = 'success';
                break;
            case 'retrasa':
                $notice_text = 'Ai retras cererea. Aceasta nu mai este activă.';
                $notice_tone = 'neutral';
                break;
        }
        if ($notice_text !== '') {
            // Clasa originală păstrează tipografia; culorile urmează tipul mesajului.
            $notice_class = 'vsc-offer-response__completed vsc-detail-status-notice vsc-detail-status-notice--' . $notice_tone;
            if ($notice_tone === 'danger') { $notice_class .= ' vsc-offer-response__completed--refused'; }
            echo '<p class="' . esc_attr($notice_class) . '" role="status">' . esc_html($notice_text) . '</p>';
        }
        echo '<dl class="vsc-sale-detail__data">';
        foreach ($fields as $label => $value) {
            if ((string)$value === '') { continue; }
            echo '<div><dt>' . esc_html($label) . '</dt><dd>' . esc_html((string)$value) . '</dd></div>';
        }
        echo '</dl>';
        $workflow_state = self::workflow_state($post_id);
        if ($workflow_state === 'oferta_trimisa' &&
            get_post_meta($post_id, '_vsc_offer_sent_at', true) &&
            (float)get_post_meta($post_id, '_vsc_offer_amount', true) > 0) {
            echo '<section class="vsc-offer-response" aria-label="Răspunde la ofertă">';
            echo '<h3>Răspunde la oferta Scule Bune</h3>';
            echo '<p>Oferta noastră: <strong>' . esc_html(number_format_i18n((float)get_post_meta($post_id, '_vsc_offer_amount', true), 2)) . ' lei</strong>. Alege o singură variantă. Răspunsul este definitiv.</p>';
            echo '<div class="vsc-offer-response__actions">';
            echo '<button type="button" class="vsc-offer-response__accept" data-vsc-offer-choice="accept" data-vsc-sale-id="' . esc_attr($post_id) . '">Accept oferta</button>';
            echo '<button type="button" class="vsc-offer-response__refuse" data-vsc-offer-choice="refuse" data-vsc-sale-id="' . esc_attr($post_id) . '">Refuz oferta</button>';
            echo '</div><p class="vsc-offer-response__notice" role="status" aria-live="polite" hidden></p></section>';
        } elseif ($workflow_state === 'oferta_revizuita' && (float)get_post_meta($post_id, '_vsc_revision_amount', true) > 0) {
            $revision = (float)get_post_meta($post_id, '_vsc_revision_amount', true);
            $old = (float)get_post_meta($post_id, '_vsc_offer_amount', true);
            $reason = (string)get_post_meta($post_id, '_vsc_revision_reason', true);
            echo '<section class="vsc-offer-response" aria-label="Ofertă revizuită">';
            echo '<h3>Ofertă revizuită după verificare</h3>';
            echo '<p>Oferta acceptată anterior: <strong>' . esc_html(number_format_i18n($old, 2)) . ' lei</strong>. Oferta nouă: <strong>' . esc_html(number_format_i18n($revision, 2)) . ' lei</strong>.</p>';
            echo '<p><strong>Motiv:</strong> ' . nl2br(esc_html($reason)) . '</p>';
            echo '<p>Poți accepta noua sumă sau o poți refuza. Dacă refuzi, echipa va organiza returul conform condițiilor comunicate.</p>';
            echo '<div class="vsc-offer-response__actions">';
            echo '<button type="button" class="vsc-offer-response__accept" data-vsc-offer-choice="accept" data-vsc-offer-revision="1" data-vsc-sale-id="' . esc_attr($post_id) . '">Accept noua ofertă</button>';
            echo '<button type="button" class="vsc-offer-response__refuse" data-vsc-offer-choice="refuse" data-vsc-offer-revision="1" data-vsc-sale-id="' . esc_attr($post_id) . '">Refuz și solicit retur</button>';
            echo '</div></section>';
        }
        $tracking_states = array('acceptata','ridicare_programata','in_transport','la_verificare',
            'oferta_revizuita','verificare_confirmata','retur_pregatit','returnata','platita');
        if (in_array($workflow_state, $tracking_states, true)) {
            echo '<section class="vsc-buyback-progress"><h3>Pașii vânzării</h3>';
            echo '<p><strong>Stadiu:</strong> ' . esc_html(self::account_status($post_id)[0]) . '</p>';
            $courier = (string)get_post_meta($post_id, '_vsc_transport_curier', true);
            $awb = (string)get_post_meta($post_id, '_vsc_transport_awb', true);
            if ($courier !== '') { echo '<p><strong>Curier:</strong> ' . esc_html($courier) . '</p>'; }
            if ($awb !== '') { echo '<p><strong>AWB:</strong> ' . esc_html($awb) . '</p>'; }
            $return_awb = (string)get_post_meta($post_id, '_vsc_retur_awb', true);
            if ($return_awb !== '' && in_array($workflow_state, array('retur_pregatit','returnata'), true)) {
                echo '<p><strong>AWB retur:</strong> ' . esc_html($return_awb) . '</p>';
            }
            if ($workflow_state === 'acceptata') { echo '<p>Nu trimite coletul înainte de a primi instrucțiuni de la Scule Bune.</p>'; }
            if ($workflow_state === 'verificare_confirmata') { echo '<p>Verificarea s-a încheiat. Asigură-te că ai salvat IBAN-ul de mai jos. Scule Bune va efectua plata prin transfer bancar.</p>'; }
            if ($workflow_state === 'platita') { echo '<p>Transferul a fost marcat ca efectuat; încasarea poate depinde de banca ta.</p>'; }
            $revision_reply = (string)get_post_meta($post_id, '_vsc_revision_reply', true);
            if (in_array($revision_reply, array('accept','refuse'), true)) {
                echo '<p><strong>Ofertă revizuită:</strong> ' . esc_html(number_format_i18n((float)get_post_meta($post_id, '_vsc_revision_amount', true), 2)) . ' lei – '
                    . esc_html($revision_reply === 'accept' ? 'acceptată de tine' : 'refuzată de tine') . '.</p>';
                echo '<p><strong>Motiv revizuire:</strong> ' . nl2br(esc_html((string)get_post_meta($post_id, '_vsc_revision_reason', true))) . '</p>';
            }
            echo '</section>';
        }
        if ($workflow_state === 'acceptata' && (string)get_post_meta($post_id, '_vsc_offer_reply', true) === 'accept') {
            self::account_finalization($post_id);
        } else {
            // Compatibilitate cu solicitările deja în transport din versiunile anterioare.
            self::account_payment_form($post_id, $workflow_state);
        }
        if ($description !== '') {
            echo '<section class="vsc-sale-detail__description"><h3>Descrierea produsului</h3><p>' . nl2br(esc_html($description)) . '</p></section>';
        }
        if ($photos || $private_photos) {
            echo '<section class="vsc-sale-detail__photos" id="vsc-fotografii"><h3>Fotografiile produsului</h3><div class="vsc-sale-gallery">';
            foreach ($photos as $photo_id) {
                $photo_id = absint($photo_id);
                if (!$photo_id || (int)wp_get_post_parent_id($photo_id) !== (int)$post_id || !wp_attachment_is_image($photo_id)) { continue; }
                echo '<div class="vsc-sale-gallery__photo">' . wp_get_attachment_image($photo_id, 'medium', false, array('loading' => 'lazy', 'decoding' => 'async', 'alt' => $name)) . '</div>';
            }
            foreach ($private_photos as $filename) {
                $url = self::private_photo_url($post_id, $filename);
                $thumbnail_data = self::private_gallery_thumbnail_data_url($post_id, $filename);
                // Dacă editorul imagine nu funcționează, păstrăm endpointul privat existent.
                $preview_url = !$thumbnail_data ? self::private_photo_url($post_id, $filename, true) : '';
                if ($url && ($thumbnail_data || $preview_url)) {
                    $src = $thumbnail_data ? esc_attr($thumbnail_data) : esc_url($preview_url);
                    echo '<div class="vsc-sale-gallery__photo"><a style="display:block;width:100%;height:100%" target="_blank" rel="noopener noreferrer" href="' . esc_url($url) . '"><img src="' . $src . '" width="320" height="320" decoding="async" alt="' . esc_attr($name) . '"></a></div>';
                }
            }
            echo '</div></section>';
        }
        echo '</div>';
    }

    /** Vânzări — desktop tabel, mobil carduri, păstrând identitatea Bigxon. */
    public static function account_requests() {
        if (!is_user_logged_in()) {
            echo '<p>Autentifică-te pentru a vedea vânzările.</p>';
            return;
        }
        $user_id = get_current_user_id();
        $detail_id = isset($_GET['vsc_detalii']) && is_scalar($_GET['vsc_detalii'])
            ? absint(wp_unslash($_GET['vsc_detalii'])) : 0;
        echo '<section class="vsc-account-requests" aria-label="Vânzări" data-vsc-url="' . esc_url(admin_url('admin-ajax.php')) . '" data-vsc-nonce="' . esc_attr(wp_create_nonce('vsc_sale_action')) . '">';
        echo '<style id="vsc-account-layout-182">.vsc-account-requests .vsc-sale-detail{border-top:1px solid #e0e0e0!important;box-shadow:none!important;background-image:none!important}.vsc-account-requests .vsc-sale-detail::before{content:none!important;display:none!important}.vsc-account-requests form.vsc-finalization__form,.vsc-account-requests .vsc-finalization__main,.vsc-account-requests .vsc-finalization__summary{display:block!important;float:none!important;width:100%!important;max-width:none!important;grid-column:1/-1!important}.vsc-account-requests .vsc-finalization__summary{margin-top:24px!important}@media(min-width:1024px){.vsc-account-requests table.vsc-account-table{width:100%!important;table-layout:fixed!important}}</style>';
        if ($detail_id) {
            self::account_request_details($detail_id, $user_id);
            echo '</section>';
            return;
        }
        $page = isset($_GET['vsc_page']) && is_scalar($_GET['vsc_page'])
            ? max(1, absint(wp_unslash($_GET['vsc_page']))) : 1;
        $requests = new WP_Query(array(
            'post_type' => self::TYPE,
            'post_status' => 'private',
            'author' => $user_id,
            'posts_per_page' => 10,
            'paged' => $page,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => false,
        ));
        echo '<div class="vsc-account-heading"><h2>Vânzări</h2></div>';
        if (!$requests->have_posts()) {
            echo '<p class="woocommerce-info">Nu ai încă solicitări înregistrate din acest cont.</p>';
        } else {
            $categories = self::categories();
            $base = wc_get_account_endpoint_url('vanzari');
            echo '<div class="vsc-account-table-wrap"><table class="woocommerce-table shop_table vsc-account-table">';
            echo '<thead><tr><th scope="col">Produs</th><th scope="col">Nr. comenzii</th><th scope="col">Data</th><th scope="col">Ofertă</th><th scope="col">Stare</th></tr></thead><tbody>';
            while ($requests->have_posts()) {
                $requests->the_post();
                $post_id = get_the_ID();
                $cat = (string)get_post_meta($post_id, '_vsc_categoria', true);
                $category = isset($categories[$cat]) ? $categories[$cat]['title'] : 'Produs';
                $brand = (string)get_post_meta($post_id, '_vsc_marca', true);
                $model = (string)get_post_meta($post_id, '_vsc_model', true);
                $product = trim($brand . ' ' . $model);
                // Coloana prezintă numai oferta reală transmisă de Scule Bune,
                // niciodată prețul dorit istoric de vânzător sau o plată presupusă.
                $offer_amount = (float)get_post_meta($post_id, '_vsc_offer_amount', true);
                $sale_state = self::workflow_state($post_id);
                $show_offer = $offer_amount > 0 && in_array($sale_state, array(
                    'oferta_trimisa', 'oferta_revizuita', 'acceptata', 'ridicare_programata',
                    'in_transport', 'la_verificare', 'verificare_confirmata', 'platita', 'finalizata',
                ), true);
                $pictures = get_post_meta($post_id, '_vsc_fotografii', true);
                if (!is_array($pictures)) { $pictures = array(); }
                $photo_id = $pictures ? absint(reset($pictures)) : 0;
                $private_pictures = self::private_photos($post_id);
                $first_private_file = $private_pictures ? reset($private_pictures) : '';
                $first_private_data = $first_private_file ? self::private_list_thumbnail_data_url($post_id, $first_private_file) : '';
                $first_private = $first_private_file && !$first_private_data ? self::private_photo_url($post_id, $first_private_file, true) : '';
                $reference = self::reference($post_id);
                $status = self::account_status($post_id);
                $detail_url = add_query_arg('vsc_detalii', $post_id, $base);
                echo '<tr class="vsc-sale-row">';
                echo '<td data-title="Produs" class="vsc-sale-product-col"><div class="vsc-sale-product">';
                echo '<a class="vsc-sale-thumb" href="' . esc_url($detail_url) . '" aria-label="Vezi detaliile produsului ' . esc_attr($product ?: 'Produs') . '">';
                if ($photo_id && (int)wp_get_post_parent_id($photo_id) === (int)$post_id && wp_attachment_is_image($photo_id)) {
                    echo wp_get_attachment_image($photo_id, 'thumbnail', false, array('class' => 'vsc-sale-thumb__image', 'alt' => $product, 'loading' => 'lazy', 'decoding' => 'async'));
                } elseif ($first_private_data) {
                    // Fără request suplimentar către WordPress pentru fiecare miniatură din listă.
                    echo '<img class="vsc-sale-thumb__image" src="' . esc_attr($first_private_data) . '" alt="' . esc_attr($product) . '" width="160" height="160" decoding="async">';
                } elseif ($first_private) {
                    // Rezervă: preview-ul privat existent, dacă serverul nu poate crea miniatura mică.
                    echo '<img class="vsc-sale-thumb__image" src="' . esc_url($first_private) . '" alt="' . esc_attr($product) . '" loading="lazy" decoding="async">';
                } else { echo self::account_icon('image'); }
                echo '</a><div class="vsc-sale-product__text"><a href="' . esc_url($detail_url) . '" class="vsc-sale-product__name">' . esc_html($product ?: 'Produs') . '</a>';
                echo '<span class="vsc-sale-product__category">' . esc_html($category) . '</span></div>';
                echo '</div></td>';
                echo '<td data-title="Nr. comenzii"><strong class="vsc-sale-ref">' . esc_html($reference) . '</strong></td>';
                echo '<td data-title="Data"><div class="vsc-sale-date">' . self::account_icon('calendar') . '<span>' . esc_html(get_the_date('j M Y', $post_id)) . '</span></div></td>';
                echo '<td data-title="Ofertă"><strong class="vsc-sale-price">' . ($show_offer ? esc_html(number_format_i18n($offer_amount, 2)) . ' lei' : '—') . '</strong></td>';
                echo '<td data-title="Stare"><span class="vsc-sale-status vsc-sale-status--' . esc_attr($status[1]) . '">' . esc_html($status[0]) . '</span></td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
            wp_reset_postdata();
            $total_pages = max(1, (int)$requests->max_num_pages);
            if ($total_pages > 1 && function_exists('wc_get_account_endpoint_url')) {
                echo '<nav class="vsc-account-pagination" aria-label="Pagini vânzări">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    $link = $i === 1 ? $base : add_query_arg('vsc_page', $i, $base);
                    if ($i === $page) {
                        echo '<span aria-current="page">' . esc_html((string)$i) . '</span>';
                    } else {
                        echo '<a href="' . esc_url($link) . '">' . esc_html((string)$i) . '</a>';
                    }
                }
                echo '</nav>';
            }
            // Un singur dialog reutilizabil, fără markup duplicat pe fiecare rând.
            echo '<div class="vsc-sale-modal" data-vsc-modal hidden>';
            echo '<div class="vsc-sale-modal__backdrop" data-vsc-cancel></div>';
            echo '<div class="vsc-sale-modal__content" role="dialog" aria-modal="true" aria-labelledby="vsc-sale-modal-title">';
            echo '<h3 id="vsc-sale-modal-title" data-vsc-modal-title></h3>';
            echo '<p data-vsc-modal-description></p>';
            echo '<form data-vsc-modal-form><label data-vsc-price-field>Preț dorit (lei) <input type="text" inputmode="decimal" autocomplete="off" name="price" maxlength="12" required></label>';
            echo '<div class="vsc-sale-modal__message" data-vsc-modal-message role="alert" hidden></div>';
            echo '<div class="vsc-sale-modal__buttons"><button type="button" class="vsc-sale-modal__cancel" data-vsc-cancel>Anulează</button>';
            echo '<button type="submit" class="vsc-sale-modal__confirm" data-vsc-confirm>Confirmă</button></div></form></div></div>';
        }
        echo '</section>';
    }

    private static function categories() {
        return array(
            'scule-acumulator'   => array('title' => 'Scule cu acumulator'),
            'scule-electrice'    => array('title' => 'Scule electrice'),
            'scule-pneumatice'   => array('title' => 'Scule pneumatice'),
            'acumulatori'        => array('title' => 'Acumulatori'),
            'incarcatoare'       => array('title' => 'Încărcătoare'),
        );
    }

    private static function conditions() {
        return array(
            'Nouă' => 'Nouă — nefolosită, în stare impecabilă.',
            'Ca nouă' => 'Ca nouă — utilizare minimă, aproape fără urme.',
            'Foarte bună' => 'Foarte bună — funcționează perfect, urme ușoare de utilizare.',
            'Bună' => 'Bună — funcțională, cu urme normale de utilizare.',
        );
    }

    private static function brands() {
        return array('Bosch', 'Devilbiss', 'DeWalt', 'Einhell', 'Festool', 'HiKOKI', 'Hilti', 'Makita', 'Metabo', 'Milwaukee', 'Skil', 'Stanley');
    }

    /** Platforme utile din pluginul vechi, fără selecție obligatorie. */
    private static function battery_platforms() {
        return array(
            'Bosch' => array('Bosch Professional 18V (AMPShare)', 'Bosch Professional 12V', 'Bosch Professional 36V'),
            'DeWalt' => array('DeWalt XR 18V / 20V MAX', 'DeWalt FlexVolt 54V / 60V MAX', 'DeWalt 12V XR / 12V MAX'),
            'Einhell' => array('Einhell Power X-Change 18V'),
            'Festool' => array('Festool 18V'),
            'HiKOKI' => array('HiKOKI 18V', 'HiKOKI Multi Volt 36V'),
            'Hilti' => array('Hilti Nuron 22V'),
            'Makita' => array('Makita LXT 18V', 'Makita XGT 40Vmax', 'Makita CXT 12Vmax', 'Makita LXT 36V / 2x18V'),
            'Metabo' => array('Metabo CAS 18V'),
            'Milwaukee' => array('Milwaukee M18', 'Milwaukee M12', 'Milwaukee MX FUEL'),
            'Skil' => array('Skil PWRCORE 20V', 'Skil PWRCORE 12V'),
            'Stanley' => array('Stanley FATMAX V20'),
        );
    }

    /**
     * Reutilizează logo-urile existente ale pluginului SculeBune Marketing Lite,
     * fără copii suplimentare. Dacă imaginile nu mai există, încearcă logo-urile
     * atributelor WooCommerce; dacă nici acestea nu există, afișează numele.
     * Nu solicită activarea pluginului de marketing și nu încarcă cod din el.
     */
    private static function brand_logos() {
        $result = array();
        $featured = array('Bosch', 'Devilbiss', 'DeWalt', 'Einhell', 'Festool', 'HiKOKI',
            'Hilti', 'Makita', 'Metabo', 'Milwaukee', 'Skil', 'Stanley');
        $marketing_brand_dir = WP_PLUGIN_DIR . '/sculebune-marketing-lite/assets/brands/';
        foreach ($featured as $brand) {
            $key = strtolower(preg_replace('/[^a-z0-9]+/i', '', $brand));
            $filename = 'brand_' . $key . '.webp';
            if (is_file($marketing_brand_dir . $filename)) {
                $result[sanitize_title($brand)] = plugins_url('sculebune-marketing-lite/assets/brands/' . $filename);
            }
        }
        // Nu interogăm WooCommerce dacă toate cele 12 logo-uri există deja.
        if (count($result) === count($featured)) { return $result; }
        $allowed_slugs = array_fill_keys(array_map('sanitize_title', self::brands()), true);
        // Rezervă: siglele de pe taxonomiile WooCommerce/Bigxon.
        $taxonomies = array('pa_brand', 'product_brand', 'pwb-brand', 'yith_product_brand');
        if (function_exists('et__get_theme_mods')) {
            $mods = et__get_theme_mods();
            if (is_array($mods) && !empty($mods['product_brand_attribute'])) {
                array_unshift($taxonomies, 'pa_' . sanitize_key($mods['product_brand_attribute']));
            }
        }
        foreach (array_unique($taxonomies) as $taxonomy) {
            if (count($result) === count($featured)) { break; }
            if (!taxonomy_exists($taxonomy)) { continue; }
            $terms = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => false));
            if (is_wp_error($terms) || !is_array($terms)) { continue; }
            foreach ($terms as $term) {
                if (empty($term->name)) { continue; }
                $name = sanitize_title($term->name);
                if (!isset($allowed_slugs[$name]) || isset($result[$name])) { continue; }
                $raw = get_term_meta($term->term_id, 'enova_' . $taxonomy . '_image', true);
                if (!$raw && $taxonomy === 'pa_brand') {
                    $raw = get_term_meta($term->term_id, 'enova_pa_brand_image', true);
                }
                if (!$raw) {
                    $image_id = absint(get_term_meta($term->term_id, 'thumbnail_id', true));
                    if ($image_id) { $raw = wp_get_attachment_image_url($image_id, 'medium'); }
                }
                if (is_numeric($raw)) { $raw = wp_get_attachment_image_url(absint($raw), 'medium'); }
                if ($raw && is_string($raw)) { $result[$name] = esc_url($raw); }
            }
        }
        return $result;
    }

    private static function package_options() {
        return array('kit-complet' => 'Kit complet', 'doar-corp' => 'Doar corp');
    }

    /**
     * Afişează un şablon salvat din Elementor. Dacă ID-ul este gol / greşit,
     * formularul va afişa în loc un card implicit şi va rămâne funcţional.
     */
    private static function elementor_card($template_id) {
        $template_id = absint($template_id);
        if (!$template_id || get_post_type($template_id) !== 'elementor_library' ||
            get_post_status($template_id) !== 'publish' || !class_exists('\\Elementor\\Plugin')) {
            return '';
        }
        $elementor = \Elementor\Plugin::$instance;
        if (!$elementor || !isset($elementor->frontend)) { return ''; }
        return (string)$elementor->frontend->get_builder_content_for_display($template_id, true);
    }

    public static function post_type() {
        register_post_type(self::TYPE, array(
            'labels' => array(
                'name' => 'Solicitări Vinde Scula',
                'singular_name' => 'Solicitare',
                'menu_name' => 'Vinde Scula',
                'all_items' => 'Toate solicitările',
                'edit_item' => 'Detalii solicitare',
                'not_found' => 'Nu există solicitări.',
                'not_found_in_trash' => 'Nu există solicitări în coș.',
            ),
            'public' => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-hammer',
            'supports' => array('title'),
            'show_in_rest' => false,
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ));
    }

    /**
     * Ascunde cardurile încă de la parsarea paginii, doar când utilizatorul are
     * o categorie validă salvată sau în URL. Fără acest cod din <head>, Elementor
     * poate afișa cardurile o clipă înainte să ruleze frontend.js din footer.
     */
    public static function early_category_visibility() {
        if (is_admin()) { return; }
        ?>
        <style id="vsc-no-category-flash">
        html.vsc-category-prefill .vsc-cat-scule-acumulator,
        html.vsc-category-prefill .vsc-cat-scule-electrice,
        html.vsc-category-prefill .vsc-cat-scule-pneumatice,
        html.vsc-category-prefill .vsc-cat-acumulatori,
        html.vsc-category-prefill .vsc-cat-incarcatoare { display: none !important; }
        /* Ascundem şi rândurile goale ale cardurilor, fără să ascundem formularul. */
        html.vsc-category-prefill .vsc-categorii-elementor:not(:has(.vsc-widget, .vsc-guest-widget)),
        html.vsc-category-prefill .vsc-categorii-elementor :has(> .vsc-cat-scule-acumulator):not(:has(.vsc-widget, .vsc-guest-widget)),
        html.vsc-category-prefill .vsc-categorii-elementor :has(> .vsc-cat-scule-electrice):not(:has(.vsc-widget, .vsc-guest-widget)),
        html.vsc-category-prefill .vsc-categorii-elementor :has(> .vsc-cat-scule-pneumatice):not(:has(.vsc-widget, .vsc-guest-widget)),
        html.vsc-category-prefill .vsc-categorii-elementor :has(> .vsc-cat-acumulatori):not(:has(.vsc-widget, .vsc-guest-widget)),
        html.vsc-category-prefill .vsc-categorii-elementor :has(> .vsc-cat-incarcatoare):not(:has(.vsc-widget, .vsc-guest-widget)) { display: none !important; }
        /* Formularul revine imediat, fără să aştepte JS-ul din footer. */
        html.vsc-category-prefill .vsc-widget[hidden],
        html.vsc-category-prefill .vsc-guest-widget[hidden] { display: block !important; }
        html.vsc-category-restored .vsc-widget .vsc-step-form { animation: none !important; }
        </style>
        <script id="vsc-early-category">
        (function () {
          try {
            var valid = ['scule-acumulator','scule-electrice','scule-pneumatice','acumulatori','incarcatoare'];
            var query = new URLSearchParams(window.location.search).get('categoria') || '';
            var key = valid.indexOf(query) !== -1 ? query : (window.localStorage.getItem('vsc:selected-category:' + window.location.pathname) || '');
            if (valid.indexOf(key) !== -1) {
              window.VSC_EARLY_CATEGORY = key;
              document.documentElement.classList.add('vsc-category-prefill', 'vsc-category-restored');
            }
          } catch (ignored) { /* Storage poate fi blocat; formularul rămâne utilizabil. */ }
        })();
        </script>
        <?php
    }

    /**
     * Returnează exclusiv datele de contact ale utilizatorului autentificat.
     * Nu includem date personale în HTML-ul paginii pentru a evita cache-ul public.
     */
    public static function contact_profile() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Autentificare necesară.'), 401);
        }
        if (!check_ajax_referer('vsc_contact_profile', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat.'), 403);
        }
        nocache_headers();
        $user = wp_get_current_user();
        if (!$user || !$user->exists()) {
            wp_send_json_error(array('message' => 'Contul nu a fost găsit.'), 401);
        }

        $billing_first = sanitize_text_field(get_user_meta($user->ID, 'billing_first_name', true));
        $billing_last = sanitize_text_field(get_user_meta($user->ID, 'billing_last_name', true));
        $first = sanitize_text_field(get_user_meta($user->ID, 'first_name', true));
        $last = sanitize_text_field(get_user_meta($user->ID, 'last_name', true));
        // Preferăm perechea de nume din facturare, dacă există; apoi profilul WP.
        $billing_name = trim($billing_first . ' ' . $billing_last);
        $profile_name = trim($first . ' ' . $last);
        $name = $billing_name !== '' ? $billing_name : $profile_name;
        if ($name === '') { $name = sanitize_text_field($user->display_name); }
        if (function_exists('mb_substr')) { $name = mb_substr($name, 0, 100); }
        else { $name = substr($name, 0, 100); }

        $phone = '';
        foreach (array('billing_phone', 'shipping_phone', 'phone', 'telefon') as $meta_key) {
            $candidate = trim(sanitize_text_field(get_user_meta($user->ID, $meta_key, true)));
            if (strlen($candidate) >= 6 && strlen($candidate) <= 25 && preg_match('/^[+0-9()\s.\-]+$/', $candidate)) {
                $phone = $candidate;
                break;
            }
        }
        $billing_email = sanitize_email(get_user_meta($user->ID, 'billing_email', true));
        $email = is_email($billing_email) ? $billing_email : sanitize_email($user->user_email);
        if (!is_email($email)) { $email = ''; }

        // Localitatea și județul provin din facturare, cu fallback la livrare.
        // Nu trimitem niciodată adresa completă sau codul poștal.
        $county = '';
        $city = '';
        foreach (array('billing', 'shipping') as $source) {
            $source_county = trim(sanitize_text_field(get_user_meta($user->ID, $source . '_state', true)));
            $source_city = trim(sanitize_text_field(get_user_meta($user->ID, $source . '_city', true)));
            $country = strtoupper(trim(sanitize_text_field(get_user_meta($user->ID, $source . '_country', true))));
            if ($country === '' && function_exists('WC') && WC()->countries && method_exists(WC()->countries, 'get_base_country')) {
                $country = WC()->countries->get_base_country();
            }
            if ($source_county !== '' && $county === '') {
                // WooCommerce poate salva județul ca abreviere (ex.: NT).
                $states = array();
                if ($country !== '' && function_exists('WC') && WC()->countries && method_exists(WC()->countries, 'get_states')) {
                    $states = WC()->countries->get_states($country);
                }
                $county = is_array($states) && isset($states[$source_county])
                    ? sanitize_text_field($states[$source_county]) : $source_county;
            }
            if ($source_city !== '' && $city === '') { $city = $source_city; }
            if ($county !== '' && $city !== '') { break; }
        }
        $county = function_exists('mb_substr') ? mb_substr($county, 0, 100) : substr($county, 0, 100);
        $city = function_exists('mb_substr') ? mb_substr($city, 0, 100) : substr($city, 0, 100);

        wp_send_json_success(array('nume' => $name, 'telefon' => $phone, 'email' => $email,
            'judet' => $county, 'localitate' => $city));
    }

    public static function enqueue_account_style() {
        // Iconița portofel și indicatorul ofertelor noi apar și în meniul mobil Bigxon,
        // inclusiv când clientul deschide meniul de pe o altă pagină decât Contul meu.
        if (is_user_logged_in() && class_exists('WooCommerce')) {
            wp_enqueue_style('vsc-account-css', plugin_dir_url(__FILE__) . 'assets/account.css', array(), (string)filemtime(plugin_dir_path(__FILE__) . 'assets/account.css'));
            wp_enqueue_script('vsc-account-js', plugin_dir_url(__FILE__) . 'assets/account.js', array(), self::VERSION, true);
            wp_localize_script('vsc-account-js', 'VSC_UNREAD_OFFERS', array(
                'count' => self::unread_offer_count(get_current_user_id()),
                'label' => 'Oferte noi',
            ));
        }
        if (function_exists('is_account_page') && is_account_page()) {
            wp_enqueue_script('vsc-offer-response', plugin_dir_url(__FILE__) . 'assets/offer-response.js', array(), self::VERSION, true);
            wp_enqueue_script('vsc-bank-form', plugin_dir_url(__FILE__) . 'assets/bank-form.js', array(), self::VERSION, true);
            wp_enqueue_script('vsc-sale-finalization', plugin_dir_url(__FILE__) . 'assets/finalization.js', array(), self::VERSION, true);
        }
    }

    private static function enqueue() {
        wp_enqueue_style('vsc-categorii-css', plugin_dir_url(__FILE__) . 'assets/frontend.css', array(), self::VERSION);
        wp_enqueue_script('vsc-categorii-js', plugin_dir_url(__FILE__) . 'assets/frontend.js', array(), self::VERSION, true);
        wp_localize_script('vsc-categorii-js', 'VSC_CATEGORII', array(
            'ajax' => admin_url('admin-ajax.php'),
            'contactNonce' => is_user_logged_in() ? wp_create_nonce('vsc_contact_profile') : '',
            'loggedIn' => is_user_logged_in(),
            'draftAccount' => is_user_logged_in() ? (string) get_current_user_id() : 'guest',
            'error' => 'Nu s-a putut trimite formularul. Verifică datele și încearcă din nou.',
            'filesLimit' => 'Poți încărca maximum 5 fotografii.',
            'fileSize' => 'Fiecare fotografie poate avea cel mult 5 MB.',
        ));
    }

    /**
     * Vizitatorii aleg o categorie, însă formularul propriu-zis și nonce-ul
     * de trimitere nu sunt randate până când nu se autentifică.
     */
    private static function guest_login_gate() {
        $page_url = get_permalink(get_queried_object_id());
        if (!$page_url) { $page_url = home_url('/vinde/'); }
        $return_url = remove_query_arg(array('vsc_auth', 'redirect_to'), $page_url);
        $category = isset($_GET['categoria']) && is_scalar($_GET['categoria'])
            ? sanitize_key(wp_unslash($_GET['categoria'])) : '';
        if ($category !== '' && array_key_exists($category, self::categories())) {
            $return_url = add_query_arg('categoria', $category, $return_url);
        }
        $login_url = wp_login_url($return_url);

        // Păstrăm selecția categoriilor Elementor, însă formularul de autentificare
        // este chiar cel nativ WooCommerce, randat prin shortcode-ul oficial.
        // Astfel, Bigxon îi aplică automat layoutul, stilurile și taburile mobile.
        wp_enqueue_style('vsc-categorii-css', plugin_dir_url(__FILE__) . 'assets/frontend.css', array(), self::VERSION);
        wp_enqueue_script('vsc-guest-gate', plugin_dir_url(__FILE__) . 'assets/guest-gate.js', array(), self::VERSION, true);
        wp_localize_script('vsc-guest-gate', 'VSC_GUEST_GATE', array(
            'categories' => array_map(function ($item) { return $item['title']; }, self::categories()),
            'returnUrl' => $return_url,
        ));

        ob_start(); ?>
        <section class="vsc-guest-widget" id="formular-vinde-scula" aria-label="Autentificare pentru Vinde Scula" hidden>
            <div class="vsc-guest-intro">
                <h2>Vrei să vinzi o sculă?</h2>
                <p>Autentifică-te sau creează un cont pentru a trimite solicitarea. Vei primi ofertele și vei urmări vânzarea în <strong>Contul meu → Vânzări</strong>.</p>
            </div>
            <?php if (class_exists('WooCommerce') && shortcode_exists('woocommerce_my_account')) : ?>
                <?php echo do_shortcode('[woocommerce_my_account]'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- shortcode oficial WooCommerce ?>
            <?php else : ?>
                <div class="vsc-guest-login-fallback">
                    <h3>Autentifică-te pentru a vinde o sculă</h3>
                    <p>Este necesar un cont pentru a trimite solicitarea.</p>
                    <a href="<?php echo esc_url($login_url); ?>">Autentificare</a>
                </div>
            <?php endif; ?>
        </section>
        <?php return ob_get_clean();
    }

    /** Acceptăm numai întoarcerile către pagina Vinde, pe domeniul propriu. */
    private static function validated_auth_return($url) {
        if (!is_string($url) || $url === '') { return ''; }
        $safe = wp_validate_redirect(esc_url_raw($url), '');
        if (!$safe) { return ''; }
        $parts = wp_parse_url($safe);
        $target = wp_parse_url(home_url('/'));
        if (!is_array($parts) || !is_array($target) ||
            !isset($parts['host'], $target['host']) ||
            strcasecmp($parts['host'], $target['host']) !== 0) { return ''; }
        $path = isset($parts['path']) ? $parts['path'] : '';
        // Evităm redirecționarea spre alte endpoint-uri ale contului.
        $vinde_page = get_page_by_path('vinde');
        $vinde_path = $vinde_page ? wp_parse_url(get_permalink($vinde_page), PHP_URL_PATH) : wp_parse_url(home_url('/vinde/'), PHP_URL_PATH);
        if (untrailingslashit($path) !== untrailingslashit($vinde_path)) { return ''; }
        return $safe;
    }

    public static function auth_return_field() {
        $raw = isset($_GET['redirect_to']) && is_scalar($_GET['redirect_to'])
            ? wp_unslash($_GET['redirect_to']) : '';
        $return_url = self::validated_auth_return($raw);
        // Pe /vinde/ formularul WooCommerce este integrat chiar în pagina categoriei.
        // Câmpul este actualizat în JS când vizitatorul selectează un card Elementor.
        if (!$return_url && is_page('vinde')) {
            $category = isset($_GET['categoria']) && is_scalar($_GET['categoria'])
                ? sanitize_key(wp_unslash($_GET['categoria'])) : '';
            $page = get_page_by_path('vinde');
            $vinde_url = $page ? get_permalink($page) : home_url('/vinde/');
            if ($category !== '' && array_key_exists($category, self::categories())) {
                $vinde_url = add_query_arg('categoria', $category, $vinde_url);
            }
            $return_url = self::validated_auth_return($vinde_url);
        }
        if ($return_url) {
            echo '<input type="hidden" name="vsc_return" value="' . esc_attr($return_url) . '">';
        }
    }

    public static function auth_return_redirect($redirect) {
        $raw = '';
        foreach (array('vsc_return', 'redirect_to') as $param) {
            if (isset($_POST[$param]) && is_scalar($_POST[$param])) { $raw = wp_unslash($_POST[$param]); break; }
            if (isset($_GET[$param]) && is_scalar($_GET[$param])) { $raw = wp_unslash($_GET[$param]); break; }
        }
        $return_url = self::validated_auth_return($raw);
        return $return_url ?: $redirect;
    }

    public static function shortcode($atts = array()) {
        if (!is_user_logged_in()) { return self::guest_login_gate(); }
        $atts = shortcode_atts(array('kit_template' => '0', 'corp_template' => '0'), $atts, 'vinde_scula');
        $kit_template = self::elementor_card($atts['kit_template']);
        $corp_template = self::elementor_card($atts['corp_template']);
        self::enqueue();
        $id = wp_unique_id('vsc-');
        $categories = self::categories();
        $brand_logos = self::brand_logos();
        ob_start(); ?>
        <section class="vsc-widget" id="formular-vinde-scula" aria-label="Formular Vinde Scula" hidden>
            <div class="vsc-step-form" data-step="form">
                <div class="vsc-selected-category" data-selected-summary hidden>
                    <span class="vsc-selected-category__details"><small>Categoria selectată</small><strong data-category-label></strong></span>
                    <button type="button" class="vsc-change-category" data-change-category><span class="vsc-change-category__text">Schimbă categoria</span><span class="vsc-change-category__icon" aria-hidden="true"><svg class="vsc-change-category__arrow" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true"><path d="M3 11a9 9 0 1 1 3 6.7"/><path d="M3 4v7h7"/></svg></span></button>
                </div>

                <form class="vsc-form" enctype="multipart/form-data" novalidate>
                    <input type="hidden" name="action" value="vsc_trimite">
                    <input type="hidden" name="security" value="<?php echo esc_attr(wp_create_nonce('vsc_trimite')); ?>">
                    <div class="vsc-message" role="alert" aria-live="assertive" hidden></div>
                    <section class="vsc-wizard-panel" data-wizard-step="1" aria-label="Pasul 1 din 3: Detaliile sculei">
                    <div class="vsc-field vsc-field--full vsc-category-field" data-category-field>
                        <label for="<?php echo esc_attr($id); ?>-category">Categoria produsului <span>*</span></label>
                        <select id="<?php echo esc_attr($id); ?>-category" name="categoria" required>
                            <option value="">Selectează categoria</option>
                            <?php foreach ($categories as $key => $item) { echo '<option value="' . esc_attr($key) . '">' . esc_html($item['title']) . '</option>'; } ?>
                        </select>
                    </div>
                    <div class="vsc-trap" aria-hidden="true"><label>Nu completa acest câmp <input name="website" tabindex="-1" autocomplete="off"></label></div>

                    <h3><svg class="vsc-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4l-6.4 6.4a2 2 0 0 0 2.8 2.8l6.4-6.4a4 4 0 0 0 5.4-5.4L15 12l-3-3z"/></svg>Detaliile produsului</h3>
                    <div class="vsc-fields vsc-fields--refined">
                        <div class="vsc-field">
                            <label for="<?php echo esc_attr($id); ?>-brand">Marcă <span>*</span></label>
                            <select id="<?php echo esc_attr($id); ?>-brand" name="marca" required class="vsc-brand-native-select">
                                <option value="">Selectează marca</option>
                                <?php foreach (self::brands() as $brand) { echo '<option value="' . esc_attr($brand) . '">' . esc_html($brand) . '</option>'; } ?>
                            </select>
                            <button class="vsc-brand-trigger" type="button" data-brand-open aria-haspopup="dialog" aria-controls="<?php echo esc_attr($id); ?>-brand-dialog" hidden>
                                <span class="vsc-brand-trigger__name" data-brand-name>Alege marca sculei</span>
                                <span class="vsc-brand-trigger__arrow" aria-hidden="true">⌄</span>
                            </button>
                        </div>
                        <div class="vsc-field">
                            <div class="vsc-model-label-row">
                                <label for="<?php echo esc_attr($id); ?>-model">Model <span>*</span></label>
                                <details class="vsc-model-help" data-model-help>
                                    <summary aria-label="Unde găsesc modelul sculei?" title="Unde găsesc modelul sculei?">?</summary>
                                    <div class="vsc-model-help__content">
                                        <strong>Unde găsești modelul?</strong>
                                        <p>Pe eticheta sau plăcuța sculei. Scrie codul exact, de exemplu DHP482.</p>
                                        <img src="<?php echo esc_url(plugin_dir_url(__FILE__) . 'assets/model-tooltip-example.webp'); ?>" width="520" height="329" alt="Exemplu de etichetă a sculei cu modelul evidențiat" loading="lazy" decoding="async">
                                    </div>
                                </details>
                            </div>
                            <input id="<?php echo esc_attr($id); ?>-model" type="text" name="model" required maxlength="120" placeholder="Ex.: DHP482, GWS 750...">
                        </div>
                        <details class="vsc-platform-details vsc-field--full" data-battery-platform hidden>
                            <summary><span>Platforma acumulatorului <em>Opțional</em></span><span class="vsc-platform-details__toggle" aria-hidden="true">+</span></summary>
                            <div class="vsc-platform-details__content">
                                <p>Completează doar dacă știi sistemul acumulatorului. Opțiunile se adaptează mărcii alese.</p>
                                <div class="vsc-field">
                                    <label for="<?php echo esc_attr($id); ?>-platform">Platformă acumulator</label>
                                    <select name="platforma" id="<?php echo esc_attr($id); ?>-platform" data-platform-select>
                                        <option value="">Nu știu / nu completez</option>
                                        <?php foreach (self::battery_platforms() as $platform_brand => $platform_names) {
                                            foreach ($platform_names as $platform_name) {
                                                echo '<option value="' . esc_attr($platform_name) . '" data-platform-brand="' . esc_attr($platform_brand) . '">' . esc_html($platform_name) . '</option>';
                                            }
                                        } ?>
                                        <option value="Altă platformă">Altă platformă</option>
                                    </select>
                                </div>
                                <div class="vsc-field" data-platform-other hidden>
                                    <label for="<?php echo esc_attr($id); ?>-platform-other">Denumirea platformei</label>
                                    <input id="<?php echo esc_attr($id); ?>-platform-other" name="platforma_alta" type="text" maxlength="80" placeholder="Ex.: M-CUBE 18V" disabled>
                                </div>
                            </div>
                        </details>
                        <fieldset class="vsc-package-field vsc-field--full" data-package-field hidden>
                            <legend>Ce vinzi? <span aria-hidden="true">*</span></legend>
                            <p class="vsc-package-help">Alege o singură opțiune pentru scula cu acumulator.</p>
                            <input type="hidden" name="pachet" value="">
                            <div class="vsc-package-options" role="radiogroup" aria-label="Configurația produsului" aria-required="true">
                                <div class="vsc-package-option" role="radio" tabindex="0" aria-checked="false" aria-label="Kit complet" data-package="kit-complet">
                                    <?php if ($kit_template !== '') { echo $kit_template; // HTML generat de Elementor, şablon publicat. ?>
                                    <?php } else { ?>
                                        <div class="vsc-package-option__fallback"><span class="vsc-package-option__symbol" aria-hidden="true">▣</span><strong>Kit complet</strong><small>Sculă cu acumulator și încărcător</small></div>
                                    <?php } ?>
                                    <span class="vsc-package-option__check" aria-hidden="true">✓</span>
                                </div>
                                <div class="vsc-package-option" role="radio" tabindex="0" aria-checked="false" aria-label="Doar corp" data-package="doar-corp">
                                    <?php if ($corp_template !== '') { echo $corp_template; // HTML generat de Elementor, şablon publicat. ?>
                                    <?php } else { ?>
                                        <div class="vsc-package-option__fallback"><span class="vsc-package-option__symbol" aria-hidden="true">▰</span><strong>Doar corp</strong><small>Sculă fără acumulator și încărcător</small></div>
                                    <?php } ?>
                                    <span class="vsc-package-option__check" aria-hidden="true">✓</span>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="vsc-kit-details vsc-field--full" data-kit-details hidden disabled>
                            <legend>Ce conține kitul?</legend>
                            <p class="vsc-kit-subtitle">Completează detaliile acumulatorilor și ale accesoriilor incluse.</p>
                            <div class="vsc-kit-grid">
                                <div class="vsc-field">
                                    <label for="<?php echo esc_attr($id); ?>-kit-count">Număr acumulatori <span>*</span></label>
                                    <select id="<?php echo esc_attr($id); ?>-kit-count" name="kit_numar" required>
                                        <option value="">Selectează numărul</option>
                                        <option value="1">1 acumulator</option><option value="2">2 acumulatori</option>
                                        <option value="3">3 acumulatori</option><option value="4+">4 sau mai mulți</option>
                                    </select>
                                </div>
                                <div class="vsc-field">
                                    <label for="<?php echo esc_attr($id); ?>-kit-capacity">Capacitate acumulatori <span>*</span></label>
                                    <select id="<?php echo esc_attr($id); ?>-kit-capacity" name="kit_capacitate" required data-kit-capacity>
                                        <option value="">Selectează capacitatea</option>
                                        <?php foreach (array('1.5 Ah','2 Ah','3 Ah','4 Ah','5 Ah','6 Ah','8 Ah','9 Ah','12 Ah','Capacități diferite') as $capacity) { echo '<option value="' . esc_attr($capacity) . '">' . esc_html($capacity) . '</option>'; } ?>
                                    </select>
                                </div>
                                <div class="vsc-field vsc-field--full" data-kit-mixed hidden>
                                    <label for="<?php echo esc_attr($id); ?>-kit-mixed">Ce capacități au acumulatorii? <span>*</span></label>
                                    <input id="<?php echo esc_attr($id); ?>-kit-mixed" name="kit_capacitati_diferite" type="text" maxlength="120" placeholder="Ex.: 2 Ah + 5 Ah" disabled>
                                </div>
                                <div class="vsc-field">
                                    <label for="<?php echo esc_attr($id); ?>-kit-voltage">Tensiune acumulatori <span>*</span></label>
                                    <select id="<?php echo esc_attr($id); ?>-kit-voltage" name="kit_tensiune" required>
                                        <option value="">Selectează tensiunea</option>
                                        <?php foreach (array('10.8 V','12 V','14.4 V','18 V','20 V MAX','36 V','40 V','54 V / 60 V MAX','Altă tensiune') as $voltage) { echo '<option value="' . esc_attr($voltage) . '">' . esc_html($voltage) . '</option>'; } ?>
                                    </select>
                                </div>
                                <div class="vsc-field vsc-field--full" data-kit-other-voltage hidden>
                                    <label for="<?php echo esc_attr($id); ?>-kit-other-voltage">Precizează tensiunea acumulatorilor <span>*</span></label>
                                    <input id="<?php echo esc_attr($id); ?>-kit-other-voltage" name="kit_alta_tensiune" maxlength="60" type="text" placeholder="Ex.: 24 V" disabled>
                                </div>
                                <div class="vsc-field">
                                    <label for="<?php echo esc_attr($id); ?>-kit-charger">Încărcător inclus <span>*</span></label>
                                    <select id="<?php echo esc_attr($id); ?>-kit-charger" name="kit_incarcator" required>
                                        <option value="">Selectează tipul</option>
                                        <option value="Original">Original</option><option value="Compatibil">Compatibil</option>
                                    </select>
                                </div>
                            </div>
                            <fieldset class="vsc-kit-battery">
                                <legend>Starea acumulatorilor <span>*</span></legend>
                                <div class="vsc-kit-radio-list">
                                    <label><input type="radio" name="kit_stare_acumulatori" value="Țin foarte bine încărcarea" required><span>Țin foarte bine încărcarea</span></label>
                                    <label><input type="radio" name="kit_stare_acumulatori" value="Țin bine încărcarea"><span>Țin bine încărcarea</span></label>
                                    <label><input type="radio" name="kit_stare_acumulatori" value="Autonomie redusă"><span>Autonomie redusă</span></label>
                                    <label><input type="radio" name="kit_stare_acumulatori" value="Nu au fost testați"><span>Nu au fost testați</span></label>
                                </div>
                            </fieldset>
                            <div class="vsc-kit-accessories">
                                <strong>Accesorii incluse <small>(opțional)</small></strong>
                                <label><input type="checkbox" name="kit_valiza" value="1"><span>Valiză / cutie de transport</span></label>
                                <label><input type="checkbox" name="kit_alte_accesorii" value="1" data-kit-extras-checkbox><span>Alte accesorii</span></label>
                                <div class="vsc-field" data-kit-extras hidden>
                                    <label for="<?php echo esc_attr($id); ?>-kit-extras">Ce alte accesorii sunt incluse? <span>*</span></label>
                                    <input type="text" id="<?php echo esc_attr($id); ?>-kit-extras" name="kit_accesorii_detalii" maxlength="200" placeholder="Ex.: 2 biți, adaptor, mâner lateral" disabled>
                                </div>
                            </div>
                        </fieldset>
                        <div class="vsc-form-group-label" aria-hidden="true"><span class="vsc-section-subheading"><svg class="vsc-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 14l4-4"/><path d="M3.34 16a10 10 0 1 1 17.32 0"/><path d="M5 19h14"/><circle cx="12" cy="14" r="1"/></svg>Starea și detaliile sculei</span></div>
                        <div class="vsc-field vsc-field--condition">
                            <label for="<?php echo esc_attr($id); ?>-condition">Starea produsului <span>*</span></label>
                            <select id="<?php echo esc_attr($id); ?>-condition" name="stare" required>
                                <option value="">Selectează starea</option>
                                <?php foreach (self::conditions() as $condition => $tip) { echo '<option value="' . esc_attr($condition) . '">' . esc_html($condition) . '</option>'; } ?>
                            </select>
                            <small class="vsc-hint" data-condition-tip>Indică starea reală a sculei.</small>
                        </div>
                        <div class="vsc-field vsc-field--manufacture-year">
                            <label for="<?php echo esc_attr($id); ?>-manufacture-year">An fabricație <small>(opțional)</small></label>
                            <select id="<?php echo esc_attr($id); ?>-manufacture-year" name="an_fabricatie">
                                <option value="">Selectează anul</option>
                                <?php for ($year = (int)current_time('Y'); $year >= 1990; $year--) { ?>
                                    <option value="<?php echo esc_attr((string)$year); ?>"><?php echo esc_html((string)$year); ?></option>
                                <?php } ?>
                                <option value="Înainte de 1990">Înainte de 1990</option>
                                <option value="Nu știu / nu este vizibil">Nu știu / nu este vizibil</option>
                            </select>
                            <small class="vsc-hint">Dacă anul nu apare pe etichetă, alege „Nu știu”.</small>
                        </div>
                        <div class="vsc-field vsc-field--description">
                            <label for="<?php echo esc_attr($id); ?>-desc">Descriere (opțional)</label>
                            <textarea id="<?php echo esc_attr($id); ?>-desc" name="descriere" rows="4" maxlength="3000" placeholder="Ce accesorii include? Are urme de utilizare? Alte detalii utile..."></textarea>
                        </div>
                    </div>

                    <div class="vsc-actions">
                        <button type="button" class="vsc-button vsc-button--back" data-change-category hidden>← Înapoi la categorii</button>
                        <button type="button" class="vsc-button vsc-button--send" data-next-step>Continuă la fotografii <span aria-hidden="true">→</span></button>
                    </div>
                    </section>

                    <section class="vsc-wizard-panel" data-wizard-step="2" aria-label="Pasul 2 din 3: Fotografii" hidden>
                    <div class="vsc-photo-area">
                        <div class="vsc-photo-title"><h3><svg class="vsc-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M14.4 4H9.6l-1.8 2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-3.8z"/><circle cx="12" cy="13" r="3.5"/></svg><span class="vsc-section-title-text">Fotografii cu produsul <span class="vsc-required-marker" aria-hidden="true">*</span></span></h3><span>Obligatoriu · 1–5 imagini</span></div>
                        <details class="vsc-photo-tips">
                            <summary>Cum faci fotografii utile? <span aria-hidden="true">+</span></summary>
                            <div class="vsc-photo-tips__items">
                                <p><strong>1. Scula întreagă</strong><span>Fotografie clară, în lumină bună.</span></p>
                                <p><strong>2. Eticheta modelului</strong><span>Fotografiază codul de pe sculă.</span></p>
                                <p><strong>3. Accesorii și urme</strong><span>Arată ce este inclus și eventualele defecte.</span></p>
                            </div>
                        </details>
                        <label class="vsc-upload" for="<?php echo esc_attr($id); ?>-photos">
                            <span class="vsc-upload__symbol" aria-hidden="true">＋</span>
                            <strong>Adaugă fotografii</strong><small>JPG, PNG sau WebP · cel mult 5 MB / imagine</small>
                        </label>
                        <input class="vsc-file-input" id="<?php echo esc_attr($id); ?>-photos" name="fotografii[]" type="file" accept="image/jpeg,image/png,image/webp" aria-required="true" multiple>
                        <div class="vsc-previews" aria-live="polite"></div>
                    </div>

                    <p class="vsc-wizard-note">Adaugă cel puțin o fotografie clară a produsului. Poți încărca maximum 5.</p>
                    <div class="vsc-actions">
                        <button type="button" class="vsc-button vsc-button--back" data-prev-step>← Înapoi la detalii</button>
                        <button type="button" class="vsc-button vsc-button--send" data-next-step>Continuă la rezumat <span aria-hidden="true">→</span></button>
                    </div>
                    </section>

                    <section class="vsc-wizard-panel vsc-review" data-wizard-step="3" aria-label="Pasul 3 din 3: Verifică solicitarea" hidden>
                        <h3><svg class="vsc-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4.5V3h6v1.5"/><path d="m9 14 2 2 4-4"/></svg>Verifică solicitarea</h3>
                        <p class="vsc-review__intro">Verifică informațiile înainte să trimiți solicitarea de evaluare. Dacă trebuie să corectezi ceva, revino la detalii sau la fotografii.</p>
                        <div class="vsc-review__details">
                            <div><span>Categorie</span><strong data-vsc-review="category">—</strong></div>
                            <div><span>Marcă și model</span><strong data-vsc-review="product">—</strong></div>
                            <div><span>Starea produsului</span><strong data-vsc-review="condition">—</strong></div>
                            <div><span>An fabricație</span><strong data-vsc-review="year">—</strong></div>
                            <div data-review-package-row hidden><span>Configurație</span><strong data-vsc-review="package">—</strong></div>
                            <div data-review-platform-row hidden><span>Platformă acumulator</span><strong data-vsc-review="platform">—</strong></div>
                            <div data-review-kit-row hidden><span>Detalii kit</span><strong data-vsc-review="kit">—</strong></div>
                            <div data-review-description-row hidden class="vsc-review__details--wide"><span>Descriere</span><strong data-vsc-review="description">—</strong></div>
                        </div>
                        <div class="vsc-review__photos-heading">
                            <h4>Fotografiile produsului</h4>
                            <span data-review-photo-count></span>
                        </div>
                        <div class="vsc-review__photos" data-review-photos aria-label="Fotografii selectate"></div>
                        <p class="vsc-review__note">Oferta va fi trimisă la e-mailul contului tău și va apărea în Contul meu → Vânzări. Datele pentru ridicare și încasare vor fi cerute numai după acceptarea ofertei.</p>
                        <div class="vsc-review__terms-gate" data-vsc-terms-gate>
                            <h4><svg class="vsc-section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>Înainte de a trimite cererea</h4>
                            <p class="vsc-review__terms-intro">Citește condițiile de evaluare și vânzare, derulează până la final și confirmă că le-ai parcurs. Apoi poți bifa declarațiile și trimite cererea.</p>
                            <details class="vsc-review__terms-details" data-vsc-terms-details>
                                <summary>Condițiile ofertei <span aria-hidden="true">⌄</span></summary>
                                <div class="vsc-review__terms-scroll" data-vsc-terms-scroll tabindex="0" role="region" aria-label="Condițiile de vânzare, derulează până la final">
                                    <p><strong>Important:</strong> Oferta comunicată este bazată pe informațiile și pozele primite și se confirmă după verificarea produsului la primire (în max. 48h). Dacă produsul nu corespunde descrierii/pozelor (defecte nedeclarate, lipsă accesorii, alt model/serie), îți trimitem dovezi (poze/video) și alegi: 1) ajustăm oferta și continui vânzarea, sau 2) refuzăm achiziția și îți returnăm produsul. Dacă produsul este neconform descrierii/pozelor, returul este suportat de vânzător; dacă eroarea ne aparține, suportăm noi.</p>
                                </div>
                            </details>
                            <div class="vsc-review__terms-confirm">
                                <p data-vsc-terms-hint aria-live="polite">Deschide condițiile și parcurge textul până la capăt.</p>
                                <button type="button" class="vsc-review__terms-read" data-vsc-terms-read disabled>Confirm că am citit</button>
                            </div>
                            <input type="hidden" name="conditii_citite" value="0" data-vsc-terms-ack>
                        </div>
                        <div class="vsc-review__confirmations">
                            <label class="vsc-consent"><input type="checkbox" name="proprietar" value="1" required disabled><span><strong>Declar că sunt proprietarul produsului sau am dreptul să îl vând și că informațiile și fotografiile trimise sunt reale.</strong><small class="vsc-consent__note">Oferta finală va fi stabilită după verificarea produsului.</small></span></label>
                            <label class="vsc-consent"><input type="checkbox" name="acord" value="1" required disabled><span>Sunt de acord cu folosirea datelor mele pentru evaluarea cererii și comunicarea ofertei.<?php $privacy = get_privacy_policy_url(); if ($privacy) { ?> <a href="<?php echo esc_url($privacy); ?>" target="_blank" rel="noopener noreferrer">Politica de confidențialitate</a><?php } ?></span></label>
                        </div>
                        <div class="vsc-actions">
                            <button type="button" class="vsc-button vsc-button--back" data-prev-step>← Înapoi la fotografii</button>
                            <button type="submit" class="vsc-button vsc-button--send">Trimite cerere <span aria-hidden="true">→</span></button>
                        </div>
                    </section>
                </form>
                <dialog class="vsc-brand-dialog" id="<?php echo esc_attr($id); ?>-brand-dialog" aria-labelledby="<?php echo esc_attr($id); ?>-brand-title">
                    <div class="vsc-brand-dialog__header">
                        <div><h3 id="<?php echo esc_attr($id); ?>-brand-title">Alege marca sculei</h3><p>Selectează un singur brand. Poți căuta după nume.</p></div>
                        <button type="button" class="vsc-brand-dialog__close" data-brand-close aria-label="Închide selecția mărcii">×</button>
                    </div>
                    <div class="vsc-brand-dialog__search"><span aria-hidden="true">⌕</span><input type="search" data-brand-search placeholder="Caută Bosch, Makita, DeWalt..." aria-label="Caută un brand" autocomplete="off"></div>
                    <div class="vsc-brand-dialog__results" data-brand-list>
                        <?php foreach (self::brands() as $brand_name) : ?>
                        <button type="button" class="vsc-brand-option" data-brand-option="<?php echo esc_attr($brand_name); ?>" aria-pressed="false">
                            <span class="vsc-brand-option__media">
                                <?php $logo_url = isset($brand_logos[sanitize_title($brand_name)]) ? $brand_logos[sanitize_title($brand_name)] : ''; ?>
                                <?php if ($logo_url) : ?><img src="<?php echo esc_url($logo_url); ?>" alt="" loading="lazy" decoding="async"><?php else : ?><span class="vsc-brand-option__fallback"><?php echo esc_html($brand_name); ?></span><?php endif; ?>
                            </span>
                            <span class="vsc-brand-option__label"><?php echo esc_html($brand_name); ?></span>
                            <span class="vsc-brand-option__check" aria-hidden="true">✓</span>
                        </button>
                        <?php endforeach; ?>
                    </div>
                    <p class="vsc-brand-dialog__empty" data-brand-empty hidden>Nu am găsit acest brand. Alege unul dintre cele 12 disponibile.</p>
                    <div class="vsc-brand-dialog__footer"><button type="button" data-brand-close>ÎNCHIDE</button></div>
                </dialog>
            </div>

            <div class="vsc-success" data-step="success" role="status" hidden>
                <span class="vsc-success__icon" aria-hidden="true">✓</span>
                <h3>Solicitarea a fost trimisă!</h3>
                <p class="vsc-success-reference" data-vsc-reference hidden></p>
                <p>Am înregistrat solicitarea. Vei primi confirmarea și răspunsul pe e-mail. Datele de ridicare și încasare vor fi cerute numai dacă accepți oferta.</p>
                <?php if (is_user_logged_in() && function_exists('wc_get_account_endpoint_url')) : ?>
                <p><a href="<?php echo esc_url(wc_get_account_endpoint_url('vanzari')); ?>">Vezi vânzările mele în cont →</a></p>
                <?php endif; ?>
                <p><button type="button" class="vsc-button vsc-button--secondary" data-change-category>Trimite altă sculă</button></p>
            </div>
        </section>
        <script id="vsc-immediate-form">
        /* Pregătim formularul imediat după HTML, înaintea scripturilor amânate din footer. */
        (function () {
            try {
                var key = window.VSC_EARLY_CATEGORY || '';
                if (!key) { return; }
                var root = document.getElementById('formular-vinde-scula');
                if (!root) { return; }
                var field = root.querySelector('select[name="categoria"]');
                var summary = root.querySelector('[data-selected-summary]');
                var label = root.querySelector('[data-category-label]');
                var selectorField = root.querySelector('[data-category-field]');
                if (!field || !summary || !label || !selectorField) { return; }
                field.value = key;
                if (field.value !== key) { return; }
                label.textContent = field.options[field.selectedIndex].textContent;
                summary.hidden = false;
                selectorField.hidden = true;
                var back = root.querySelector('.vsc-button--back');
                if (back) { back.hidden = false; }
                root.hidden = false;
            } catch (ignored) { /* Scriptul obişnuit poate iniţializa formularul ulterior. */ }
        })();
        </script>
        <?php return ob_get_clean();
    }

    private static function fail($message, $code = 400) {
        wp_send_json_error(array('message' => $message), $code);
    }

    private static function length($value) {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private static function field($name) {
        if (!isset($_POST[$name]) || !is_scalar($_POST[$name])) { return ''; }
        return sanitize_text_field(wp_unslash($_POST[$name]));
    }

    /** 0 = fără limită zilnică per client. */
    private static function daily_limit() {
        return self::sanitize_daily_limit(get_option(self::OPT_DAILY_LIMIT, 5));
    }

    public static function sanitize_daily_limit($value) {
        $raw = is_scalar($value) ? trim((string)$value) : '';
        if (!preg_match('/^[0-9]{1,3}$/D', $raw)) { return 5; }
        return min(100, (int)$raw);
    }

    /** A doua limită: 0 dezactivează doar filtrul pe IP; implicit rămâne 3/oră. */
    private static function hourly_ip_limit() {
        return self::sanitize_hourly_ip_limit(get_option(self::OPT_HOURLY_IP_LIMIT, 3));
    }

    public static function sanitize_hourly_ip_limit($value) {
        $raw = is_scalar($value) ? trim((string)$value) : '';
        if (!preg_match('/^[0-9]{1,3}$/D', $raw)) { return 3; }
        return min(100, (int)$raw);
    }

    /**
     * Numărăm cererile salvate în ziua curentă, în fusul orar WordPress.
     * Identificare: utilizator autentificat SAU aceeași adresă e-mail SAU
     * același telefon. Funcționează și pentru vizitatorii fără cont și
     * include cererile retrase, fără a modifica solicitările existente.
     */
    private static function client_requests_today($email, $phone) {
        global $wpdb;
        $today = current_time('Y-m-d');
        $tomorrow = gmdate('Y-m-d', strtotime($today . ' +1 day'));
        $conditions = array(
            $wpdb->prepare(
                "EXISTS (SELECT 1 FROM {$wpdb->postmeta} em WHERE em.post_id = p.ID AND em.meta_key = %s AND LOWER(em.meta_value) = %s)",
                '_vsc_email', strtolower($email)
            ),
        );
        if ($phone !== '') {
            $conditions[] = $wpdb->prepare(
                "EXISTS (SELECT 1 FROM {$wpdb->postmeta} ph WHERE ph.post_id = p.ID AND ph.meta_key = %s AND ph.meta_value = %s)",
                '_vsc_telefon', $phone
            );
        }
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        if ($user_id > 0) {
            $conditions[] = $wpdb->prepare('p.post_author = %d', $user_id);
        }
        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             WHERE p.post_type = %s AND p.post_status = %s
             AND p.post_date >= %s AND p.post_date < %s
             AND (" . implode(' OR ', $conditions) . ')',
            self::TYPE, 'private', $today . ' 00:00:00', $tomorrow . ' 00:00:00'
        );
        return (int)$wpdb->get_var($query);
    }

    public static function transaction_ready() {
        global $wpdb;
        $engines = $wpdb->get_col($wpdb->prepare(
            'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN (%s,%s,%s)',
            $wpdb->posts, $wpdb->postmeta, $wpdb->options
        ));
        return count($engines) === 3 && count(array_filter($engines, static function($engine) {
            return strtoupper($engine) === 'INNODB';
        })) === 3;
    }

    /** Each tool is a separate request and consumes one submission. */
    public static function submission_limits($lock = true) {
        global $wpdb;
        if (!is_user_logged_in()) { return new WP_Error('unauthorized', 'Autentifică-te înainte de trimitere.', array('status'=>401)); }
        $user = wp_get_current_user();
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $context = array('rate_key'=>'vsc_rate_' . md5($ip ?: 'unknown'), 'hourly_ip_limit'=>self::hourly_ip_limit(), 'locks'=>array());
        if ($lock) {
            $names = array('user:' . $user->ID, 'email:' . strtolower($user->user_email), 'ip:' . $ip);
            sort($names, SORT_STRING);
            foreach ($names as $resource) {
                $name = 'vsc_quota_lock_' . md5($resource);
                $value = time() . ':' . wp_generate_uuid4();
                $old = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", $name));
                if ($old !== null && (int)$old < time() - 300) {
                    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $name, $old));
                }
                if ($wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", $name, $value)) !== 1) {
                    self::release_submission_quota($context);
                    return new WP_Error('quota_busy', 'O trimitere este deja în curs. Încearcă din nou.', array('status'=>409));
                }
                $context['locks'][] = array($name, $value);
            }
            register_shutdown_function(array(__CLASS__, 'release_submission_quota'), $context);
        }
        $limit = self::daily_limit();
        if ($limit > 0 && self::client_requests_today(sanitize_email($user->user_email), '') >= $limit) {
            self::release_submission_quota($context);
            return new WP_Error('daily_limit', sprintf('Ai atins limita de %d solicitări pe zi. Poți trimite o solicitare nouă mâine.', $limit), array('status'=>429));
        }
        // Refresh the transient after obtaining the connection lock.
        wp_cache_delete('_transient_' . $context['rate_key'], 'options');
        wp_cache_delete($context['rate_key'], 'transient');
        $context['count'] = $context['hourly_ip_limit'] > 0 ? (int)get_transient($context['rate_key']) : 0;
        if ($context['hourly_ip_limit'] > 0 && $context['count'] >= $context['hourly_ip_limit']) {
            self::release_submission_quota($context);
            return new WP_Error('hourly_limit', sprintf('Ai atins limita de %d solicitări pe oră de la această conexiune. Încearcă din nou mai târziu.', $context['hourly_ip_limit']), array('status'=>429));
        }
        return $context;
    }

    public static function release_submission_quota($context) {
        global $wpdb;
        foreach (isset($context['locks']) ? $context['locks'] : array() as $lease) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $lease[0], $lease[1]));
            wp_cache_delete($lease[0], 'options');
        }
    }

    public static function consume_submission_quota($context) {
        if (!$context['hourly_ip_limit']) { return true; }
        return set_transient($context['rate_key'], $context['count'] + 1, HOUR_IN_SECONDS);
    }

    public static function queue_submission($post_id) {
        update_post_meta($post_id, '_vsc_background_status', 'pending');
        update_post_meta($post_id, '_vsc_mail_next_run', time());
        self::ensure_email_queue_schedule();
        if (!self::kick_email_queue() && !wp_next_scheduled('vsc_email_queue_tick')) {
            update_post_meta($post_id, '_vsc_background_status', 'schedule_failed');
        }
    }

    public static function send() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Autentifică-te sau creează un cont înainte de a trimite solicitarea.'), 401);
        }
        if (!check_ajax_referer('vsc_trimite', 'security', false)) {
            self::fail('Sesiunea a expirat. Reîncarcă pagina și încearcă din nou.', 403);
        }
        if (self::field('website') !== '') { self::fail('Solicitarea nu a putut fi procesată.'); }
        if (self::field('vsc_shipment_id') !== '' || self::field('vsc_item_token') !== '') {
            self::fail('Formularul a fost actualizat. Reîncarcă pagina și trimite o singură sculă per solicitare.', 409);
        }

        $categories = self::categories();
        $category = self::field('categoria');
        $brand = self::field('marca');
        $model = self::field('model');
        $condition = self::field('stare');
        $package = self::field('pachet');
        $price_text = self::field('pret'); // păstrat doar pentru compatibilitate cu cererile vechi
        $description = isset($_POST['descriere']) && is_scalar($_POST['descriere']) ? sanitize_textarea_field(wp_unslash($_POST['descriere'])) : '';
        // Datele de ridicare și încasare se cer după acceptarea ofertei.
        // Toate solicitările noi aparțin în mod obligatoriu unui cont.
        $user = wp_get_current_user();
        $name = trim(sanitize_text_field((string)$user->display_name));
        if ($name === '') { $name = 'Client'; }
        $email = sanitize_email((string)$user->user_email);
        $phone = '';
        $county = '';
        $city = '';
        $agreed = self::field('acord') === '1';
        $ownership_confirmed = self::field('proprietar') === '1';
        if (self::field('conditii_citite') !== '1') {
            self::fail('Citește condițiile de vânzare și confirmă că le-ai parcurs înainte de trimitere.');
        }
        if (!$ownership_confirmed) { self::fail('Confirmă că ești proprietarul sculei și că ai dreptul să o vinzi.'); }

        if (!array_key_exists($category, $categories)) { self::fail('Alege una dintre cele 5 categorii disponibile.'); }
        if (!in_array($brand, self::brands(), true)) { self::fail('Selectează unul dintre cele 12 branduri disponibile.'); }
        if (!$brand || self::length($brand) > 80 || !$model || self::length($model) > 120) { self::fail('Completează marca și modelul produsului.'); }
        // Anul este opțional; acceptăm și sculele vechi, fără prag artificial din pluginul anterior.
        $manufacture_year = self::field('an_fabricatie');
        if ($manufacture_year !== '' && !in_array($manufacture_year, array('Înainte de 1990', 'Nu știu / nu este vizibil'), true)) {
            if (!preg_match('/^[0-9]{4}$/', $manufacture_year) ||
                (int)$manufacture_year < 1990 || (int)$manufacture_year > (int)current_time('Y')) {
                self::fail('Selectează un an de fabricație valid sau alege „Nu știu”.');
            }
        }
        $platform = self::field('platforma');
        $platform_other = self::field('platforma_alta');
        if ($category !== 'scule-acumulator') {
            $platform = '';
        } elseif ($platform === 'Altă platformă') {
            if ($platform_other === '' || self::length($platform_other) > 80) { self::fail('Completează denumirea platformei sau alege „Nu știu”.'); }
            $platform = $platform_other;
        } elseif ($platform !== '') {
            $by_brand = self::battery_platforms();
            if (!isset($by_brand[$brand]) || !in_array($platform, $by_brand[$brand], true)) {
                self::fail('Platforma aleasă nu corespunde mărcii. Selectează o opțiune din listă.');
            }
        }
        if (!array_key_exists($condition, self::conditions())) { self::fail('Selectează starea produsului.'); }
        if ($category === 'scule-acumulator') {
            if (!array_key_exists($package, self::package_options())) { self::fail('Selectează Kit complet sau Doar corp.'); }
        } else { $package = ''; }
        // Datele kitului se acceptă numai când utilizatorul a ales efectiv Kit complet.
        $kit = array();
        if ($category === 'scule-acumulator' && $package === 'kit-complet') {
            $allowed_kit = array(
                'kit_numar' => array('1', '2', '3', '4+'),
                'kit_capacitate' => array('1.5 Ah', '2 Ah', '3 Ah', '4 Ah', '5 Ah', '6 Ah', '8 Ah', '9 Ah', '12 Ah', 'Capacități diferite'),
                'kit_tensiune' => array('10.8 V', '12 V', '14.4 V', '18 V', '20 V MAX', '36 V', '40 V', '54 V / 60 V MAX', 'Altă tensiune'),
                'kit_incarcator' => array('Original', 'Compatibil'),
                'kit_stare_acumulatori' => array('Țin foarte bine încărcarea', 'Țin bine încărcarea', 'Autonomie redusă', 'Nu au fost testați'),
            );
            foreach ($allowed_kit as $field => $allowed) {
                $value = self::field($field);
                if (!in_array($value, $allowed, true)) { self::fail('Completează toate detaliile obligatorii ale kitului.'); }
                $kit[$field] = $value;
            }
            $mixed = self::field('kit_capacitati_diferite');
            if ($kit['kit_capacitate'] === 'Capacități diferite') {
                if (!$mixed || self::length($mixed) > 120) { self::fail('Precizează capacitățile diferite ale acumulatorilor.'); }
                $kit['kit_capacitati_diferite'] = $mixed;
            }
            if ($kit['kit_tensiune'] === 'Altă tensiune') {
                $other_voltage = self::field('kit_alta_tensiune');
                if (!$other_voltage || self::length($other_voltage) > 60) { self::fail('Precizează tensiunea acumulatorilor.'); }
                $kit['kit_alta_tensiune'] = $other_voltage;
            }
            $kit['kit_valiza'] = self::field('kit_valiza') === '1' ? '1' : '0';
            $kit['kit_alte_accesorii'] = self::field('kit_alte_accesorii') === '1' ? '1' : '0';
            if ($kit['kit_alte_accesorii'] === '1') {
                $extras = self::field('kit_accesorii_detalii');
                if (!$extras || self::length($extras) > 200) { self::fail('Descrie celelalte accesorii incluse în kit.'); }
                $kit['kit_accesorii_detalii'] = $extras;
            }
        }
        // Câmpul «Preț dorit» a fost scos din formular. Pentru compatibilitate
        // păstrăm meta-ul intern și salvăm 0 pentru cererile noi. Dacă o versiune
        // veche a formularului încă trimite valoarea, o acceptăm în continuare.
        if ($price_text !== '') {
            $normalized_price = str_replace(',', '.', $price_text);
            if (!is_numeric($normalized_price) || (float)$normalized_price < 0 || (float)$normalized_price > 1000000) { self::fail('Prețul trebuie să fie între 0 și 1.000.000 lei.'); }
            $price = round((float)$normalized_price, 2);
        } else {
            $price = 0.0;
        }
        if (!is_email($email) || strlen($email) > 190 || !$agreed) {
            self::fail('Este necesară o adresă de e-mail validă și acordul pentru prelucrarea datelor.');
        }
        if (self::length($description) > 3000) { self::fail('Descrierea este prea lungă.'); }

        $quota = self::submission_limits();
        if (is_wp_error($quota)) {
            $error_data = $quota->get_error_data();
            self::fail($quota->get_error_message(), isset($error_data['status']) ? $error_data['status'] : 429);
        }

        $files = array();
        if (!empty($_FILES['fotografii']) && isset($_FILES['fotografii']['name']) && is_array($_FILES['fotografii']['name'])) {
            $raw = $_FILES['fotografii'];
            $total = count($raw['name']);
            if ($total > 5) { self::fail('Poți adăuga maximum 5 fotografii.'); }
            foreach (array('type', 'tmp_name', 'error', 'size') as $part) {
                if (!isset($raw[$part]) || !is_array($raw[$part]) || count($raw[$part]) !== $total) {
                    self::fail('Datele fotografiilor nu sunt valide. Încearcă din nou.');
                }
            }
            $allowed = array('jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp');
            for ($i = 0; $i < $total; $i++) {
                // Blochează cererile multipart incomplete sau manipulate.
                if (!isset($raw['name'][$i], $raw['type'][$i], $raw['tmp_name'][$i], $raw['error'][$i], $raw['size'][$i]) ||
                    !is_string($raw['name'][$i]) || !is_string($raw['type'][$i]) ||
                    !is_string($raw['tmp_name'][$i]) || !is_scalar($raw['error'][$i]) || !is_scalar($raw['size'][$i])) {
                    self::fail('Datele fotografiilor nu sunt valide. Încearcă din nou.');
                }
                if ((int)$raw['error'][$i] === UPLOAD_ERR_NO_FILE) { continue; }
                if ((int)$raw['error'][$i] !== UPLOAD_ERR_OK) { self::fail('Eroare la încărcarea uneia dintre fotografii.'); }
                if ((int)$raw['size'][$i] <= 0 || (int)$raw['size'][$i] > 5 * 1024 * 1024) { self::fail('Fiecare fotografie trebuie să aibă cel mult 5 MB.'); }
                if (!is_uploaded_file($raw['tmp_name'][$i])) { self::fail('Încărcarea fotografiei nu este validă.'); }
                $filename = sanitize_file_name($raw['name'][$i]);
                $checked = wp_check_filetype_and_ext($raw['tmp_name'][$i], $filename, $allowed);
                if (empty($checked['type']) || !in_array($checked['type'], $allowed, true)) { self::fail('Sunt acceptate doar fotografii JPG, PNG și WebP.'); }
                $files[] = array('name' => $filename, 'type' => $checked['type'], 'tmp_name' => $raw['tmp_name'][$i], 'error' => $raw['error'][$i], 'size' => $raw['size'][$i]);
            }
        }

        // Verificăm şi pe server: nu acceptăm solicitări fără o fotografie validă,
        // chiar dacă JavaScript este dezactivat sau cererea AJAX este modificată.
        if (!$files) { self::fail('Adaugă cel puțin o fotografie a produsului.'); }
        // Fail-closed: niciodată fallback la wp-content/uploads când stocarea privată lipsește.
        if (!self::private_storage_root(true)) {
            self::fail('Stocarea privată a fotografiilor nu este disponibilă pe server. Contactează administratorul.', 503);
        }
        // Verificăm suportul WebP înainte de crearea solicitării: fără fișiere
        // JPG/PNG salvate accidental și fără solicitări incomplete.
        if (!function_exists('wp_image_editor_supports')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        if (!wp_image_editor_supports(array('mime_type' => 'image/webp'))) {
            self::fail('Serverul nu poate converti fotografiile în WebP. Contactează administratorul.', 503);
        }

        $post_id = wp_insert_post(array(
            'post_type' => self::TYPE,
            'post_status' => 'private',
            'post_author' => get_current_user_id(),
            'post_title' => sprintf('%s – %s %s – %s', $categories[$category]['title'], $brand, $model, $name),
        ), true);
        if (is_wp_error($post_id)) { self::fail('Nu am putut salva solicitarea. Te rugăm să încerci din nou.', 500); }

        $values = array('categoria' => $category, 'marca' => $brand, 'model' => $model, 'stare' => $condition,
            'pret' => $price, 'pachet' => $package, 'platforma' => $platform, 'an_fabricatie' => $manufacture_year, 'descriere' => $description, 'nume' => $name, 'telefon' => $phone, 'email' => $email,
            'judet' => $county, 'localitate' => $city,
            'metoda_incasare' => '',
            'acord_data' => current_time('mysql'),
            'proprietar_confirmat' => '1',
            'proprietar_confirmat_la' => current_time('mysql'),
            'conditii_citite_confirmate' => '1',
            'conditii_citite_confirmate_la' => current_time('mysql'));
        foreach ($values as $key => $value) { update_post_meta($post_id, '_vsc_' . $key, $value); }
        foreach ($kit as $key => $value) { update_post_meta($post_id, '_vsc_' . $key, $value); }

        // Salvăm fotografiile noi privat, în afara zonei web publice.
        // Nu creăm atașamente Media și nu generăm URL-uri directe publice.
        $photo_ids = array(); // Compatibilitate cu fluxul existent WP-Cron.
        $private_names = array();
        $private_dir = self::private_request_dir($post_id, true);
        if (!$private_dir) {
            self::rollback_upload($post_id, $photo_ids, $private_names);
            self::fail('Nu am putut pregăti dosarul privat pentru fotografii.', 500);
        }
        foreach ($files as $file) {
            $image_info = @getimagesize($file['tmp_name']);
            $extension_by_mime = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
            $detected = is_array($image_info) && isset($image_info['mime']) ? (string)$image_info['mime'] : '';
            if (!isset($extension_by_mime[$detected]) || $detected !== $file['type']) {
                self::rollback_upload($post_id, $photo_ids, $private_names);
                self::fail('Una dintre fotografii nu este o imagine validă.', 400);
            }
            // Conversie obligatorie în WebP: nu mutăm JPG/PNG în dosarul privat.
            $filename = self::save_private_webp($file['tmp_name'], $private_dir);
            if (!$filename) {
                self::rollback_upload($post_id, $photo_ids, $private_names);
                self::fail('Nu am putut comprima una dintre fotografii în WebP. Încearcă o imagine mai mică sau contactează administratorul.', 500);
            }
            $private_names[] = $filename;
            // Originalul pentru vizualizarea completă este acum WebP (max. 1800 px).
            // Miniatura de max. 640 px se generează separat, tot privat.
            self::ensure_private_preview($private_dir, $filename);
            // Generăm și miniatura de listă la încărcare, ca pagina Vânzări să fie rapidă.
            self::ensure_private_list_thumbnail($private_dir, $filename);
        }
        update_post_meta($post_id, '_vsc_private_fotografii', $private_names);
        update_post_meta($post_id, '_vsc_status', 'primita');
        self::consume_submission_quota($quota);
        self::release_submission_quota($quota);
        self::queue_submission($post_id);

        wp_send_json_success(array(
            'message' => 'Solicitarea a fost înregistrată.',
            'id' => $post_id,
            'referinta' => self::reference($post_id),
            'notificari' => 'in_asteptare',
        ));
    }

    /** Implicit rămâne calea veche (wp_mail + FluentSMTP dacă este activ). */
    private static function email_transport() {
        return self::sanitize_email_transport(get_option(self::OPT_EMAIL_TRANSPORT, 'smtp'));
    }

    public static function sanitize_email_transport($value) {
        return is_string($value) && $value === 'php_mail' ? 'php_mail' : 'smtp';
    }

    /**
     * Ca în SculeBune Marketing Lite: alegerea PHP Mail aplică temporar
     * isMail() prin phpmailer_init numai pe durata apelului wp_mail().
     * SMTP păstrează traseul wp_mail() fără intervenții. Nu modificăm
     * setările sau hook-urile celorlalte pluginuri.
     *
     * Important: dacă un alt plugin suprascrie wp_mail() și nu declanșează
     * phpmailer_init, transportul final depinde de acea implementare.
     */
    private static function send_email($recipient, $subject, $body, $headers) {
        if (self::email_transport() !== 'php_mail') {
            return wp_mail($recipient, $subject, $body, $headers);
        }

        add_action('phpmailer_init', array(__CLASS__, 'configure_local_mailer'), 999);
        try {
            return wp_mail($recipient, $subject, $body, $headers);
        } finally {
            // Nu lăsăm o modificare de transport activă pentru alte e-mailuri.
            remove_action('phpmailer_init', array(__CLASS__, 'configure_local_mailer'), 999);
        }
    }

    /** Doar în modul PHP Mail: reproducem expeditorul Marketing Lite. */
    public static function configure_local_mailer($phpmailer) {
        $phpmailer->isMail();
        $phpmailer->Encoding = 'quoted-printable';
        $phpmailer->CharSet = 'UTF-8';
        // FluentSMTP poate forța expeditorul la încărcarea wp_mail();
        // reafirmăm From doar în hook-ul temporar al acestui mesaj.
        $phpmailer->setFrom('oferte@sculebune.ro', 'Scule Bune', false);
    }

    /** SMTP păstrează info@; PHP Mail folosește doar ca expeditor oferte@. */
    private static function email_headers() {
        $from = self::email_transport() === 'php_mail'
            ? 'Scule Bune <oferte@sculebune.ro>'
            : 'SculeBune.ro <info@sculebune.ro>';
        return array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from,
            'Reply-To: SculeBune.ro <info@sculebune.ro>',
        );
    }

    /** În e-mail introducem doar text deja escap-at; nu încorporăm fișiere externe sau scripturi. */
    private static function email_layout($title, $intro, $content, $footer_note = '') {
        $title = esc_html($title);
        $intro = esc_html($intro);
        $url = esc_url(home_url('/'));
        $note = $footer_note !== '' ? '<p style="margin:12px 0 0;color:#646464;font-size:12px;line-height:1.6;">' . esc_html($footer_note) . '</p>' : '';
        return '<!DOCTYPE html><html lang="ro"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>'
            . '<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;color:#1b1b1b;">'
            . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;">' . $intro . '</div>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f5f5f5;border-collapse:collapse;">'
            . '<tr><td align="center" style="padding:26px 12px;">'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%;max-width:600px;background:#ffffff;border:1px solid #e0e0e0;border-collapse:separate;border-spacing:0;">'
            . '<tr><td style="background:#111111;padding:19px 24px;border-bottom:4px solid #ffb900;">'
            . '<a href="' . $url . '" style="color:#ffffff;text-decoration:none;font-size:20px;line-height:1.2;font-weight:700;">Scule<span style="color:#ffb900;">Bune</span>.ro</a>'
            . '</td></tr><tr><td style="padding:25px 24px 28px;">'
            . '<h1 style="font-size:22px;line-height:1.35;margin:0 0 13px;color:#111111;font-weight:700;">' . $title . '</h1>'
            . '<p style="font-size:15px;line-height:1.65;margin:0 0 20px;color:#333333;">' . $intro . '</p>'
            . $content
            . '<div style="border-top:1px solid #e6e6e6;margin-top:24px;padding-top:16px;font-size:13px;line-height:1.6;color:#606060;">'
            . 'Acest mesaj a fost trimis de Scule Bune.' . $note . '</div>'
            . '</td></tr></table></td></tr></table></body></html>';
    }

    /** Perechi etichetă/valoare: numai text escap-at; păstrăm rândurile noi din descrieri. */
    private static function email_details($rows) {
        $html = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%;border-collapse:collapse;border:1px solid #e3e3e3;">';
        $index = 0;
        foreach ($rows as $label => $value) {
            if ($value === '' || $value === null) { continue; }
            $shade = ($index++ % 2 === 0) ? '#fafafa' : '#ffffff';
            $html .= '<tr style="background:' . $shade . ';">'
                . '<th scope="row" align="left" valign="top" style="width:37%;padding:11px 12px;border-bottom:1px solid #ededed;text-align:left;font-size:13px;font-weight:600;color:#565656;">' . esc_html((string)$label) . '</th>'
                . '<td valign="top" style="padding:11px 12px;border-bottom:1px solid #ededed;font-size:14px;line-height:1.5;color:#111111;word-break:break-word;">' . nl2br(esc_html((string)$value)) . '</td></tr>';
        }
        return $html . '</table>';
    }

    private static function email_action($label, $url) {
        return '<p style="margin:22px 0 0;">'
            . '<a href="' . esc_url($url) . '" style="display:inline-block;padding:12px 20px;background:#ffb900;color:#111111;text-decoration:none;font-weight:700;font-size:14px;line-height:1.4;border-radius:4px;">' . esc_html($label) . '</a>'
            . '</p>';
    }

    private static function kit_details_for_display($post_id) {
        if (get_post_meta($post_id, '_vsc_categoria', true) !== 'scule-acumulator' ||
            get_post_meta($post_id, '_vsc_pachet', true) !== 'kit-complet') { return array(); }
        $keys = array(
            'kit_numar' => 'Număr acumulatori',
            'kit_capacitate' => 'Capacitate acumulatori',
            'kit_capacitati_diferite' => 'Capacități diferite',
            'kit_tensiune' => 'Tensiune acumulatori',
            'kit_alta_tensiune' => 'Altă tensiune (detalii)',
            'kit_incarcator' => 'Încărcător',
            'kit_stare_acumulatori' => 'Stare acumulatori',
        );
        $result = array();
        foreach ($keys as $key => $label) {
            $value = (string)get_post_meta($post_id, '_vsc_' . $key, true);
            if ($value !== '') { $result[$label] = $value; }
        }
        if (get_post_meta($post_id, '_vsc_kit_valiza', true) === '1') { $result['Valiză / cutie'] = 'Da'; }
        if (get_post_meta($post_id, '_vsc_kit_alte_accesorii', true) === '1') {
            $result['Alte accesorii'] = (string)get_post_meta($post_id, '_vsc_kit_accesorii_detalii', true);
        }
        return $result;
    }

    private static function rollback_upload($post_id, $photo_ids, $private_names = array()) {
        foreach ($photo_ids as $photo_id) { wp_delete_attachment($photo_id, true); }
        self::remove_private_photos($post_id, $private_names);
        wp_delete_post($post_id, true);
    }

    /** O singură recurență pentru coadă; funcționează și după upgrade fără reactivare. */
    public static function email_queue_intervals($schedules) {
        $schedules['vsc_every_5_minutes'] = array('interval' => 5 * MINUTE_IN_SECONDS, 'display' => 'La fiecare 5 minute (Vinde Scula)');
        return $schedules;
    }

    public static function ensure_email_queue_schedule() {
        if (!wp_next_scheduled('vsc_email_queue_tick')) {
            wp_schedule_event(time() + 120, 'vsc_every_5_minutes', 'vsc_email_queue_tick');
        }
    }

    private static function kick_email_queue() {
        // O singură pornire imediată; repetările sunt preluate de cronul periodic.
        if (wp_next_scheduled('vsc_email_queue_kick')) { return true; }
        $result = wp_schedule_single_event(time(), 'vsc_email_queue_kick', array(), true);
        if ($result && !is_wp_error($result) && function_exists('spawn_cron')) { spawn_cron(); }
        return $result && !is_wp_error($result);
    }

    private static function email_queue_log($post_id, $event, $note) {
        $history = get_post_meta($post_id, '_vsc_email_history', true);
        if (!is_array($history)) { $history = array(); }
        $history[] = array('time' => current_time('mysql'), 'event' => sanitize_key($event), 'note' => sanitize_text_field($note));
        update_post_meta($post_id, '_vsc_email_history', array_slice($history, -30));
    }

    /** Lock atomic per solicitare: previne două procese Cron concurente. */
    private static function email_lock($post_id) {
        $key = 'vsc_email_lock_' . absint($post_id);
        if (add_option($key, time(), '', 'no')) { return true; }
        $started = (int)get_option($key, 0);
        // Recuperează numai joburile rămase blocate după o întrerupere veche.
        if ($started > 0 && $started < time() - 15 * MINUTE_IN_SECONDS) {
            delete_option($key);
            return add_option($key, time(), '', 'no');
        }
        return false;
    }

    /** Lucrează doar cu notificări netrimise; nu retrimite ofertele comerciale. */
    public static function run_email_queue() {
        $now = time();
        $posts = get_posts(array(
            'post_type' => self::TYPE, 'post_status' => 'private', 'fields' => 'ids',
            'numberposts' => self::EMAIL_BATCH_SIZE, 'orderby' => 'date', 'order' => 'ASC',
            'meta_query' => array('relation' => 'AND',
                array('key' => '_vsc_background_status', 'value' => array('pending', 'retry', 'schedule_failed', 'processing'), 'compare' => 'IN'),
                array('relation' => 'OR',
                    array('key' => '_vsc_mail_next_run', 'compare' => 'NOT EXISTS'),
                    array('key' => '_vsc_mail_next_run', 'value' => $now, 'compare' => '<=', 'type' => 'NUMERIC'),
                ),
            ),
        ));
        foreach ($posts as $post_id) { self::process_background((int)$post_id); }
        // Separat de confirmări: notificăm administratorul despre deciziile
        // clienților; maximum 20 de răspunsuri per lot, fără dubluri.
        $replies = get_posts(array(
            'post_type' => self::TYPE, 'post_status' => 'private', 'fields' => 'ids',
            'numberposts' => self::EMAIL_BATCH_SIZE, 'orderby' => 'date', 'order' => 'ASC',
            'meta_query' => array('relation' => 'AND',
                array('key' => '_vsc_offer_reply_notice', 'value' => array('pending', 'retry', 'schedule_failed'), 'compare' => 'IN'),
                array('key' => '_vsc_offer_reply_notice_next_run', 'value' => $now, 'compare' => '<=', 'type' => 'NUMERIC'),
            ),
        ));
        foreach ($replies as $reply_id) { self::notify_offer_response((int)$reply_id); }
    }

    /**
     * WP-Cron procesează mesajele după salvarea solicitării și generează, unde
     * este nevoie, miniaturile Media vechi. Fiecare notificare are stare proprie.
     */
    public static function process_background($post_id) {
        $post_id = absint($post_id);
        if (!$post_id || get_post_type($post_id) !== self::TYPE || get_post_status($post_id) !== 'private') { return; }
        $status = (string)get_post_meta($post_id, '_vsc_background_status', true);
        if ($status === 'complete' || $status === 'failed') { return; }
        // Respectăm backoff-ul chiar și pentru eventuale cronuri vechi rămase din 1.3.33.
        $next_run = (int)get_post_meta($post_id, '_vsc_mail_next_run', true);
        if ($next_run > time()) { return; }
        if (!self::email_lock($post_id)) { return; }
        try {
            if ((int)get_post_meta($post_id, '_vsc_background_attempts', true) >= self::EMAIL_MAX_ATTEMPTS) {
                update_post_meta($post_id, '_vsc_background_status', 'failed');
                delete_post_meta($post_id, '_vsc_mail_next_run');
                return;
            }
            update_post_meta($post_id, '_vsc_background_status', 'processing');
            update_post_meta($post_id, '_vsc_background_last_attempt', current_time('mysql'));
            update_post_meta($post_id, '_vsc_background_attempts', (int)get_post_meta($post_id, '_vsc_background_attempts', true) + 1);

            $categories = self::categories();
            $category = (string)get_post_meta($post_id, '_vsc_categoria', true);
            $category_title = isset($categories[$category]) ? $categories[$category]['title'] : 'Necunoscută';
            $brand = (string)get_post_meta($post_id, '_vsc_marca', true);
            $model = (string)get_post_meta($post_id, '_vsc_model', true);
            $condition = (string)get_post_meta($post_id, '_vsc_stare', true);
            $price = (string)get_post_meta($post_id, '_vsc_pret', true);
            $description = (string)get_post_meta($post_id, '_vsc_descriere', true);
            $name = (string)get_post_meta($post_id, '_vsc_nume', true);
            $phone = (string)get_post_meta($post_id, '_vsc_telefon', true);
            $email = (string)get_post_meta($post_id, '_vsc_email', true);
            $county = (string)get_post_meta($post_id, '_vsc_judet', true);
            $city = (string)get_post_meta($post_id, '_vsc_localitate', true);
            $payment_method = (string)get_post_meta($post_id, '_vsc_metoda_incasare', true);
            $package = (string)get_post_meta($post_id, '_vsc_pachet', true);
            $packages = self::package_options();
            $photo_ids = get_post_meta($post_id, '_vsc_fotografii', true);
            if (!is_array($photo_ids)) { $photo_ids = array(); }
            $private_photo_count = count(self::private_photos($post_id));

            // Notificările pentru administrator merg exclusiv la info; nu la office sau la admin_email.
            $recipient = 'info@sculebune.ro';
            if (get_post_meta($post_id, '_vsc_mail_admin', true) !== 'sent') {
                $subject = 'Vinde Scula: solicitare nouă ' . self::reference($post_id);
                $details = array(
                    'Nr. comenzii' => self::reference($post_id),
                    'Categorie' => $category_title,
                    'Marcă' => $brand,
                    'Model' => $model,
                    'An fabricație' => (string)get_post_meta($post_id, '_vsc_an_fabricatie', true),
                    'Platformă acumulator' => (string)get_post_meta($post_id, '_vsc_platforma', true),
                    'Configurație' => ($category === 'scule-acumulator' && isset($packages[$package])) ? $packages[$package] : '',
                    'Stare' => $condition,
                    'Preț dorit' => ((float)$price > 0 ? $price . ' lei' : ''),
                    'Descriere' => $description,
                    'Nume' => $name,
                    'Telefon' => $phone,
                    'E-mail' => $email,
                    'Județ' => $county,
                    'Localitate' => $city,
                    'Metoda de încasare' => ($payment_method === 'transfer_bancar') ? 'Transfer bancar' : '',
                    'Număr fotografii' => (string)(count($photo_ids) + $private_photo_count),
                );
                foreach (self::kit_details_for_display($post_id) as $label => $value) {
                    $details['Kit complet — ' . $label] = $value;
                }
                $body = self::email_layout(
                    'Solicitare nouă ' . self::reference($post_id),
                    'A fost înregistrată o solicitare nouă pentru evaluarea unei scule.',
                    self::email_details($details)
                        . self::email_action('Deschide solicitarea în WordPress', admin_url('post.php?post=' . $post_id . '&action=edit'))
                );
                if (self::send_email($recipient, $subject, $body, self::email_headers())) {
                    update_post_meta($post_id, '_vsc_mail_admin', 'sent');
                    self::email_queue_log($post_id, 'admin_sent', 'Notificarea administratorului a fost acceptată de transport.');
                } else {
                    update_post_meta($post_id, '_vsc_mail_admin', 'failed');
                    self::email_queue_log($post_id, 'admin_failed', 'Transportul a refuzat notificarea administratorului.');
                }
            }
            if (is_email($email) && get_post_meta($post_id, '_vsc_mail_client', true) !== 'sent') {
                // Subiect unic pentru fiecare cerere, similar ca structură notificărilor tranzacționale.
                $subject = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) . ' – Cerere ' . self::reference($post_id) . ' – Confirmare primire';
                // Confirmarea este o notificare tranzacțională completă, cu pașii
                // următori și contactul real. Contul Vânzări este legat doar
                // solicitărilor trimise de utilizatori autentificați.
                $confirmation_html = self::email_details(array(
                    'Nr. solicitării' => self::reference($post_id),
                    'Produs' => trim($brand . ' ' . $model),
                    'Categorie' => $category_title,
                    'Preț dorit' => ((float)$price > 0 ? $price . ' lei' : ''),
                ));
                $confirmation_html .= '<h2 style="font-size:17px;line-height:1.4;color:#111111;margin:24px 0 9px;">Ce urmează?</h2>';
                $confirmation_html .= '<p style="font-size:14px;line-height:1.65;color:#333333;margin:0 0 13px;">'
                    . 'Verificăm fotografiile și detaliile sculei tale. Revenim cu oferta noastră după evaluare. '
                    . 'Nu expedia scula înainte să confirmăm împreună preluarea.</p>';
                if ((int)get_post_field('post_author', $post_id) > 0 && function_exists('wc_get_account_endpoint_url')) {
                    $confirmation_html .= self::email_action('Vezi solicitările în cont', wc_get_account_endpoint_url('vanzari'));
                }
                $confirmation_html .= '<p style="font-size:13px;line-height:1.6;color:#555555;margin:19px 0 0;">'
                    . 'Ai întrebări? Răspunde direct la acest e-mail sau scrie-ne la '
                    . '<a href="mailto:info@sculebune.ro" style="color:#111111;">info@sculebune.ro</a>.</p>';
                $body = self::email_layout(
                    'Am primit cererea ta!',
                    'Salut, ' . $name . '! Am înregistrat solicitarea ' . self::reference($post_id) . '.',
                    $confirmation_html,
                    'Păstrează numărul solicitării pentru orice întrebare. Echipa Scule Bune.'
                );
                if (self::send_email($email, $subject, $body, self::email_headers())) {
                    update_post_meta($post_id, '_vsc_mail_client', 'sent');
                    self::email_queue_log($post_id, 'client_sent', 'Confirmarea clientului a fost acceptată de transport.');
                } else {
                    update_post_meta($post_id, '_vsc_mail_client', 'failed');
                    self::email_queue_log($post_id, 'client_failed', 'Transportul a refuzat confirmarea clientului.');
                }
            }

            // Fotografiile originale există deja. Generarea mărimilor derivate nu
            // trebuie să blocheze utilizatorul care a trimis solicitarea.
            if ($photo_ids) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
                foreach ($photo_ids as $photo_id) {
                    $photo_id = absint($photo_id);
                    if (!$photo_id || get_post_meta($photo_id, '_vsc_sizes_ready', true) === '1') { continue; }
                    $path = get_attached_file($photo_id);
                    if ($path && is_file($path)) {
                        $metadata = wp_generate_attachment_metadata($photo_id, $path);
                        if (is_array($metadata) && !empty($metadata)) {
                            wp_update_attachment_metadata($photo_id, $metadata);
                            update_post_meta($photo_id, '_vsc_sizes_ready', '1');
                        }
                    }
                }
            }

            $admin_ok = get_post_meta($post_id, '_vsc_mail_admin', true) === 'sent';
            $client_ok = get_post_meta($post_id, '_vsc_mail_client', true) === 'sent';
            // Coada e-mailurilor nu trebuie blocată de generarea de miniaturi pentru
            // atașamentele Media vechi; miniaturile pot fi regenerate separat.
            if ($admin_ok && $client_ok) {
                update_post_meta($post_id, '_vsc_background_status', 'complete');
                delete_post_meta($post_id, '_vsc_mail_next_run');
            } else {
                $attempt = (int)get_post_meta($post_id, '_vsc_background_attempts', true);
                if ($attempt >= self::EMAIL_MAX_ATTEMPTS) {
                    update_post_meta($post_id, '_vsc_background_status', 'failed');
                    delete_post_meta($post_id, '_vsc_mail_next_run');
                    self::email_queue_log($post_id, 'exhausted', 'Numărul maxim de încercări a fost atins.');
                } else {
                    // Backoff: după prima încercare 5 minute, după a doua 15 minute.
                    $delay = $attempt === 1 ? 5 * MINUTE_IN_SECONDS : 15 * MINUTE_IN_SECONDS;
                    update_post_meta($post_id, '_vsc_background_status', 'retry');
                    update_post_meta($post_id, '_vsc_mail_next_run', time() + $delay);
                }
            }
        } finally {
            delete_option('vsc_email_lock_' . $post_id);
        }
    }

    /** Datele bancare sunt criptate într-un singur meta privat; niciodată în e-mailuri sau loguri. */
    private static function payment_allowed_states() {
        return array('acceptata', 'ridicare_programata', 'in_transport', 'la_verificare',
            'oferta_revizuita', 'verificare_confirmata');
    }

    private static function payment_crypto_ready() {
        return function_exists('openssl_encrypt') && function_exists('openssl_decrypt')
            && function_exists('random_bytes') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
    }

    private static function payment_secret_key() {
        // Cheia depinde de salturile WordPress; păstrează-le stabile și protejate în backup.
        return hash_hmac('sha256', 'vsc-payment-data-v1', wp_salt('auth') . '|' . wp_salt('secure_auth'), true);
    }

    private static function payment_encrypt($id, $data) {
        if (!self::payment_crypto_ready()) { return false; }
        $plain = wp_json_encode($data, JSON_UNESCAPED_UNICODE);
        if (!is_string($plain)) { return false; }
        try { $iv = random_bytes(12); } catch (Exception $e) { return false; }
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', self::payment_secret_key(), OPENSSL_RAW_DATA,
            $iv, $tag, 'vsc-payment-' . absint($id), 16);
        if ($cipher === false || strlen($tag) !== 16) { return false; }
        return 'v1:' . base64_encode($iv . $tag . $cipher);
    }

    private static function payment_decrypt($id) {
        $stored = get_post_meta($id, '_vsc_payment_details_secure', true);
        if (!is_string($stored) || strpos($stored, 'v1:') !== 0 || !self::payment_crypto_ready()) { return false; }
        $bytes = base64_decode(substr($stored, 3), true);
        if ($bytes === false || strlen($bytes) < 29) { return false; }
        $plain = openssl_decrypt(substr($bytes, 28), 'aes-256-gcm', self::payment_secret_key(),
            OPENSSL_RAW_DATA, substr($bytes, 0, 12), substr($bytes, 12, 16), 'vsc-payment-' . absint($id));
        if (!is_string($plain)) { return false; }
        $value = json_decode($plain, true);
        if (!is_array($value) || !isset($value['holder'], $value['iban']) ||
            !is_string($value['holder']) || !is_string($value['iban'])) { return false; }
        return $value;
    }

    /** Doar verificare de structură și checksum; nu dovedește titularul sau existența contului. */
    private static function payment_valid_iban($iban) {
        if (!is_string($iban)) { return false; }
        $n = strlen($iban);
        if ($n < 15 || $n > 34 || !preg_match('/^[A-Z]{2}[0-9]{2}[A-Z0-9]+$/D', $iban)) { return false; }
        // Lungimi oficiale ale țărilor uzuale; RO are obligatoriu 24 caractere.
        $lengths = array('RO'=>24,'AT'=>20,'BE'=>16,'BG'=>22,'CH'=>21,'CY'=>28,'CZ'=>24,
            'DE'=>22,'DK'=>18,'EE'=>20,'ES'=>24,'FI'=>18,'FR'=>27,'GB'=>22,'GR'=>27,
            'HR'=>21,'HU'=>28,'IE'=>22,'IS'=>26,'IT'=>27,'LI'=>21,'LT'=>20,'LU'=>20,
            'LV'=>21,'MC'=>27,'MD'=>24,'MT'=>31,'NL'=>18,'NO'=>15,'PL'=>28,'PT'=>25,
            'SE'=>24,'SI'=>19,'SK'=>24,'SM'=>27,'TR'=>26,'UA'=>29,'XK'=>20);
        $country = substr($iban, 0, 2);
        if (!isset($lengths[$country]) || $n !== $lengths[$country]) { return false; }
        $moved = substr($iban, 4) . substr($iban, 0, 4);
        $remainder = 0;
        for ($i = 0, $len = strlen($moved); $i < $len; ++$i) {
            $ord = ord($moved[$i]);
            $part = ($ord >= 65 && $ord <= 90) ? (string)($ord - 55) : $moved[$i];
            for ($j = 0, $k = strlen($part); $j < $k; ++$j) {
                $remainder = ($remainder * 10 + (int)$part[$j]) % 97;
            }
        }
        return $remainder === 1;
    }

    /** Numai proprietarul autentificat poate salva/șterge datele înainte de plată. */
    public static function save_payment_details() {
        if (!is_user_logged_in() || !check_ajax_referer('vsc_sale_action', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat. Reîncarcă pagina.'), 403);
        }
        $id = isset($_POST['sale_id']) && is_scalar($_POST['sale_id']) ? absint(wp_unslash($_POST['sale_id'])) : 0;
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)get_current_user_id()) {
            wp_send_json_error(array('message' => 'Solicitarea nu aparține contului tău.'), 403);
        }
        if (!in_array(self::workflow_state($id), self::payment_allowed_states(), true) ||
            get_post_meta($id, '_vsc_offer_reply', true) !== 'accept' ||
            !get_post_meta($id, '_vsc_offer_sent_at', true)) {
            wp_send_json_error(array('message' => 'Datele de plată se pot completa numai după acceptarea ofertei, înainte de plată.'), 409);
        }
        $operation = isset($_POST['payment_operation']) && is_scalar($_POST['payment_operation'])
            ? sanitize_key(wp_unslash($_POST['payment_operation'])) : 'save';
        if ($operation === 'delete') {
            delete_post_meta($id, '_vsc_payment_details_secure');
            delete_post_meta($id, '_vsc_payment_details_at');
            self::workflow_log($id, 'bank_details_removed', 'Clientul a șters datele bancare din cont.');
            wp_send_json_success(array('message' => 'Datele bancare au fost șterse. Completează-le din nou înainte de plată.'));
        }
        if ($operation !== 'save' || !self::payment_crypto_ready()) {
            wp_send_json_error(array('message' => 'Salvarea securizată nu este disponibilă pe server. Contactează Scule Bune.'), 503);
        }
        $holder = isset($_POST['holder']) && is_scalar($_POST['holder'])
            ? trim(sanitize_text_field(wp_unslash($_POST['holder']))) : '';
        $raw_iban = isset($_POST['iban']) && is_scalar($_POST['iban'])
            ? (string)wp_unslash($_POST['iban']) : '';
        $iban_clean = preg_replace('/[\s\x{00A0}]+/u', '', $raw_iban);
        $iban = is_string($iban_clean) ? strtoupper($iban_clean) : '';
        if (self::length($holder) < 3 || self::length($holder) > 120 ||
            !preg_match('/\p{L}/u', $holder) || preg_match('/[<>\r\n]/u', $holder) ||
            !self::payment_valid_iban($iban)) {
            wp_send_json_error(array('message' => 'Verifică titularul (3–120 caractere) și IBAN-ul. IBAN-ul trebuie să aibă structură și cifre de control valide.'), 400);
        }
        $encrypted = self::payment_encrypt($id, array('holder' => $holder, 'iban' => $iban));
        if ($encrypted === false || update_post_meta($id, '_vsc_payment_details_secure', $encrypted) === false) {
            wp_send_json_error(array('message' => 'Datele bancare nu au putut fi salvate. Încearcă din nou.'), 500);
        }
        update_post_meta($id, '_vsc_payment_details_at', current_time('mysql'));
        self::workflow_log($id, 'bank_details_saved', 'Clientul a salvat sau actualizat datele de plată (fără IBAN în istoric).');
        wp_send_json_success(array('message' => 'Datele bancare au fost salvate în siguranță. Le poți modifica până la efectuarea plății.'));
    }

    /** Adresa de ridicare este stocată separat, criptat şi legată de solicitare. */
    public static function checkout_pickup_decrypt($id) {
        $stored = get_post_meta($id, '_vsc_checkout_pickup_secure', true);
        if (!is_string($stored) || strpos($stored, 'v1:') !== 0 || !self::payment_crypto_ready()) { return false; }
        $bytes = base64_decode(substr($stored, 3), true);
        if ($bytes === false || strlen($bytes) < 29) { return false; }
        $plain = openssl_decrypt(substr($bytes, 28), 'aes-256-gcm', self::payment_secret_key(),
            OPENSSL_RAW_DATA, substr($bytes, 0, 12), substr($bytes, 12, 16), 'vsc-payment-' . absint($id));
        if (!is_string($plain)) { return false; }
        $result = json_decode($plain, true);
        $required = array('last_name','first_name','email','phone','address','county','city');
        if (!is_array($result)) { return false; }
        foreach ($required as $key) {
            if (!isset($result[$key]) || !is_string($result[$key])) { return false; }
        }
        return $result;
    }

    /** Date implicite din WooCommerce; nu publicăm niciodată IBAN-ul deja stocat. */
    private static function checkout_defaults($id) {
        $user = wp_get_current_user();
        $uid = (int)$user->ID;
        $name = trim((string)get_post_meta($id, '_vsc_nume', true));
        $parts = preg_split('/\s+/u', $name, 2);
        $first = trim((string)get_user_meta($uid, 'billing_first_name', true));
        if ($first === '') { $first = trim((string)get_user_meta($uid, 'first_name', true)); }
        $last = trim((string)get_user_meta($uid, 'billing_last_name', true));
        if ($last === '') { $last = trim((string)get_user_meta($uid, 'last_name', true)); }
        if ($last === '' && $first === '' && count($parts) > 1) {
            $last = $parts[0]; $first = $parts[1];
        }
        $billing = function($key) use ($uid) { return trim((string)get_user_meta($uid, 'billing_' . $key, true)); };
        $saved = self::checkout_pickup_decrypt($id);
        $defaults = array(
            'last_name' => $last,
            'first_name' => $first,
            'email' => $billing('email') ?: ((string)get_post_meta($id, '_vsc_email', true)),
            'phone' => $billing('phone') ?: ((string)get_post_meta($id, '_vsc_telefon', true)),
            'address' => $billing('address_1'),
            'address_2' => $billing('address_2'),
            'county' => (string)get_post_meta($id, '_vsc_judet', true) ?: $billing('state'),
            'city' => $billing('city') ?: ((string)get_post_meta($id, '_vsc_localitate', true)),
            'postcode' => $billing('postcode'),
        );
        if (is_array($saved)) { return array_merge($defaults, $saved); }
        return $defaults;
    }

    /** Un singur pas de finalizare; verificările sunt server-side, nu doar în formular. */
    public static function finalize_sale() {
        if (!is_user_logged_in() || !check_ajax_referer('vsc_sale_action', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat. Reîncarcă pagina.'), 403);
        }
        $id = isset($_POST['sale_id']) && is_scalar($_POST['sale_id']) ? absint(wp_unslash($_POST['sale_id'])) : 0;
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            (int)$post->post_author !== (int)get_current_user_id()) {
            wp_send_json_error(array('message' => 'Nu poți finaliza această solicitare.'), 403);
        }
        if (self::workflow_state($id) !== 'acceptata' ||
            (string)get_post_meta($id, '_vsc_offer_reply', true) !== 'accept' ||
            !get_post_meta($id, '_vsc_offer_sent_at', true)) {
            wp_send_json_error(array('message' => 'Finalizarea este disponibilă numai după acceptarea ofertei.'), 409);
        }
        if (get_post_meta($id, '_vsc_checkout_completed_at', true)) {
            wp_send_json_error(array('message' => 'Această vânzare a fost deja finalizată. Reîncarcă pagina.'), 409);
        }
        if (!self::payment_crypto_ready()) {
            wp_send_json_error(array('message' => 'Salvarea securizată este indisponibilă. Contactează Scule Bune.'), 503);
        }
        $fields = array(
            'last_name'=>100,'first_name'=>100,'phone'=>28,'address'=>180,
            'address_2'=>140,'county'=>100,'city'=>100,'postcode'=>20,
        );
        $data = array();
        foreach ($fields as $key => $max) {
            $raw = isset($_POST[$key]) && is_scalar($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
            $data[$key] = trim(sanitize_text_field($raw));
            if (self::length($data[$key]) > $max) {
                wp_send_json_error(array('message' => 'Unul dintre câmpuri este prea lung: ' . $key), 400);
            }
        }
        $data['email'] = isset($_POST['email']) && is_scalar($_POST['email'])
            ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $digits = preg_replace('/\D+/', '', $data['phone']);
        if (self::length($data['last_name']) < 2 || self::length($data['first_name']) < 2 ||
            !is_email($data['email']) || strlen($data['email']) > 190 ||
            !preg_match('/^\+?[0-9\s\(\)\-]{9,28}$/D', $data['phone']) ||
            strlen($digits) < 9 || strlen($digits) > 15 ||
            self::length($data['address']) < 5 || self::length($data['county']) < 2 ||
            self::length($data['city']) < 2) {
            wp_send_json_error(array('message' => 'Completează corect numele, prenumele, telefonul, e-mailul și adresa de ridicare.'), 400);
        }
        $ownership = isset($_POST['ownership']) && is_scalar($_POST['ownership']) ? (string)wp_unslash($_POST['ownership']) : '';
        $terms = isset($_POST['terms']) && is_scalar($_POST['terms']) ? (string)wp_unslash($_POST['terms']) : '';
        $privacy = isset($_POST['privacy']) && is_scalar($_POST['privacy']) ? (string)wp_unslash($_POST['privacy']) : '';
        if ($ownership !== 'yes' || $terms !== 'yes' || $privacy !== 'yes') {
            wp_send_json_error(array('message' => 'Confirmă proprietatea produsului și faptul că ai citit condițiile și politica de confidențialitate.'), 400);
        }
        $old_bank = self::payment_decrypt($id);
        $has_new_bank = isset($_POST['iban']) && is_scalar($_POST['iban']) &&
            trim((string)wp_unslash($_POST['iban'])) !== '';
        if ($has_new_bank) {
            $holder = isset($_POST['holder']) && is_scalar($_POST['holder'])
                ? trim(sanitize_text_field(wp_unslash($_POST['holder']))) : '';
            $clean = preg_replace('/[\s\x{00A0}]+/u', '', (string)wp_unslash($_POST['iban']));
            $iban = is_string($clean) ? strtoupper($clean) : '';
            if (self::length($holder) < 3 || self::length($holder) > 120 || !self::payment_valid_iban($iban)) {
                wp_send_json_error(array('message' => 'Numele titularului sau IBAN-ul nu este valid.'), 400);
            }
            $bank_data = array('holder'=>$holder, 'iban'=>$iban);
        } elseif (is_array($old_bank)) {
            $bank_data = $old_bank;
        } else {
            wp_send_json_error(array('message' => 'Completează numele titularului și un IBAN valid.'), 400);
        }
        $lock = self::acquire_checkout_lock($id);
        if (is_wp_error($lock)) { self::fail($lock->get_error_message(), 409); }
        global $wpdb;
        $targets = array($id);
        $error = '';
        if (!self::transaction_ready() || $wpdb->query('START TRANSACTION') === false) {
            self::release_checkout_lock($lock);
            self::fail('Serverul nu permite confirmarea sigură a ridicării. Contactează administratorul.', 503);
        }
        try {
            // Re-read after locking: request-local meta may predate another finalization.
            clean_post_cache($id);
            foreach ($targets as $target) {
                clean_post_cache($target);
                $item = get_post($target);
                if (!$item || $item->post_type !== self::TYPE || $item->post_status !== 'private' ||
                    (int)$item->post_author !== get_current_user_id() || self::workflow_state($target) !== 'acceptata' ||
                    get_post_meta($target, '_vsc_offer_reply', true) !== 'accept' || !get_post_meta($target, '_vsc_offer_sent_at', true) ||
                    get_post_meta($target, '_vsc_checkout_completed_at', true)) {
                    throw new RuntimeException('Starea unei scule s-a modificat sau ridicarea a fost deja confirmată. Reîncarcă pagina.');
                }
            }
            foreach ($targets as $target) {
                // Both payloads are bound cryptographically to this individual item ID.
                $bank_cipher = self::payment_encrypt($target, $bank_data);
                $pickup_cipher = self::payment_encrypt($target, $data);
                if ($bank_cipher === false || $pickup_cipher === false ||
                    update_post_meta($target, '_vsc_payment_details_secure', $bank_cipher) === false ||
                    update_post_meta($target, '_vsc_checkout_pickup_secure', $pickup_cipher) === false ||
                    !self::checkout_meta($target, '_vsc_payment_details_at', current_time('mysql')) ||
                    !self::checkout_meta($target, '_vsc_checkout_terms_version', 'v1.4.1') ||
                    !add_post_meta($target, '_vsc_checkout_completed_at', current_time('mysql'), true)) {
                    throw new RuntimeException('Datele de ridicare nu au putut fi salvate integral. Încearcă din nou.');
                }
            }
            if ($wpdb->query('COMMIT') === false) { throw new RuntimeException('Nu am putut confirma salvarea.'); }
        } catch (Throwable $exception) {
            $wpdb->query('ROLLBACK');
            $error = $exception->getMessage();
        } finally {
            foreach (is_array($targets) ? $targets : array($id) as $target) { clean_post_cache($target); }
            self::release_checkout_lock($lock);
        }
        if ($error !== '') { self::fail($error, 409); }
        foreach ($targets as $target) {
            self::workflow_log($target, 'checkout_completed', 'Clientul a confirmat ridicarea și încasarea. Datele personale nu sunt incluse în istoric.');
        }
        // Notificarea către administrator nu conține IBAN, adresă sau telefon.
        $admin_mail = self::send_email('info@sculebune.ro',
            'Finalizare vânzare – ' . self::reference($id) . ' – Scule Bune',
            self::email_layout('Date de ridicare primite',
                'Clientul a finalizat vânzarea ' . self::reference($id) . '.',
                '<p>Poți programa ridicarea din WordPress → Vinde Scula → Solicitări.</p>'), self::email_headers());
        update_post_meta($id, '_vsc_checkout_admin_notice', $admin_mail ? 'server_accepted' : 'send_failed');
        wp_send_json_success(array('message' => 'Vânzarea a fost finalizată. Scule Bune va organiza ridicarea prin curier. Nu expedia coletul înainte de instrucțiuni.'));
    }

    /** Stop the removed batch feature without altering any existing requests. */
    public static function retire_shipment_scheduler() {
        if (wp_next_scheduled('vsc_shipments_cleanup')) { wp_clear_scheduled_hook('vsc_shipments_cleanup'); }
    }

    private static function acquire_checkout_lock($id) {
        global $wpdb;
        $name = 'vsc_checkout_lock_' . absint($id);
        $value = time() . ':' . wp_generate_uuid4();
        $old = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", $name));
        if ($old !== null && (int)$old < time() - 5 * MINUTE_IN_SECONDS) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $name, $old));
        }
        if ($wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", $name, $value)) !== 1) {
            return new WP_Error('vsc_checkout_busy', 'Finalizarea este deja în curs. Reîncarcă pagina.');
        }
        $lease = array('name'=>$name, 'value'=>$value);
        register_shutdown_function(array(__CLASS__, 'release_checkout_lock'), $lease);
        return $lease;
    }

    public static function release_checkout_lock($lease) {
        if (!is_array($lease) || empty($lease['name']) || !isset($lease['value']) ||
            !preg_match('/^vsc_checkout_lock_[0-9]+$/D', $lease['name'])) { return; }
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $lease['name'], $lease['value']));
        wp_cache_delete($lease['name'], 'options');
    }

    private static function checkout_meta($id, $key, $value) {
        return get_post_meta($id, $key, true) === $value || update_post_meta($id, $key, $value) !== false;
    }

    /** Ecranul clientului este activ după acceptare, fără a expune IBAN-ul salvat. */
    private static function account_finalization($id) {
        $completed = (string)get_post_meta($id, '_vsc_checkout_completed_at', true);
        $pickup = self::checkout_pickup_decrypt($id);
        $bank = self::payment_decrypt($id);
        if ($completed !== '') {
            echo '<section class="vsc-finalization vsc-finalization--done"><h3>Vânzare finalizată <span class="vsc-finalization__check">✓</span></h3>';
            echo '<p><strong>Am primit datele pentru ridicare.</strong> Scule Bune va organiza curierul. Nu expedia coletul înainte de a primi instrucțiuni.</p>';
            if (is_array($pickup)) {
                echo '<p><strong>Ridicare:</strong> ' . esc_html($pickup['address'] . ', ' . $pickup['city'] . ', ' . $pickup['county']) . '</p>';
            }
            if (is_array($bank)) {
                echo '<p><strong>Cont pentru plată:</strong> IBAN terminat în ' . esc_html(substr($bank['iban'], -4)) . '</p>';
            }
            echo '<p class="vsc-finalization__help">Ai greșit adresa de ridicare? Contactează Scule Bune înainte de programarea curierului.</p></section>';
            echo '<details class="vsc-finalization-bank"><summary>Schimbă IBAN-ul pentru încasare</summary>';
            self::account_payment_form($id, 'acceptata');
            echo '</details>';
            return;
        }
        echo '<section class="vsc-finalization-intro"><h3>Următorul pas: finalizează vânzarea</h3>';
        echo '<p>Completează datele pentru ridicarea prin curier și pentru plata prin transfer bancar.</p>';
        $open = isset($_GET['vsc_finalizare']) && is_scalar($_GET['vsc_finalizare']) &&
            (string)wp_unslash($_GET['vsc_finalizare']) === '1';
        if (!$open) {
            $url = add_query_arg(array('vsc_detalii'=>$id,'vsc_finalizare'=>'1'),
                function_exists('wc_get_account_endpoint_url') ? wc_get_account_endpoint_url('vanzari') : get_permalink());
            echo '<a class="vsc-finalization__button" href="' . esc_url($url) . '#vsc-finalizare">Finalizează vânzarea →</a></section>';
            return;
        }
        echo '</section>';
        $v = self::checkout_defaults($id);
        $url_terms = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('terms') : '';
        $url_privacy = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
        echo '<section class="vsc-finalization" id="vsc-finalizare" data-vsc-finalization data-sale-id="' . esc_attr($id) . '">';
        echo '<h3>Finalizează vânzarea</h3><p>Preț acceptat: <strong>'
            . esc_html(number_format_i18n((float)get_post_meta($id, '_vsc_offer_amount', true), 2))
            . ' lei</strong> — după verificarea produsului, conform condițiilor de vânzare.</p>';
        if (!self::payment_crypto_ready()) {
            echo '<p class="vsc-finalization__error">Datele bancare nu pot fi salvate securizat pe acest server. Contactează Scule Bune.</p></section>'; return;
        }
        echo '<form class="vsc-finalization__form" style="display:block!important;width:100%!important;max-width:none!important" novalidate autocomplete="on"><div class="vsc-finalization__main" style="display:block!important;width:100%!important;max-width:none!important;grid-column:1/-1!important">';
        echo '<h4>1. Date de contact și ridicare</h4><div class="vsc-finalization__grid">';
        $inputs = array(
            'last_name'=>array('Nume','text',100,'family-name',true),
            'first_name'=>array('Prenume','text',100,'given-name',true),
            'email'=>array('Email','email',190,'email',true),
            'phone'=>array('Telefon','tel',28,'tel',true),
            'address'=>array('Stradă și număr','text',180,'street-address',true),
            'address_2'=>array('Bloc, scară, apartament (opțional)','text',140,'off',false),
            'county'=>array('Județ','text',100,'address-level1',true),
            'city'=>array('Localitate','text',100,'address-level2',true),
            'postcode'=>array('Cod poștal (opțional)','text',20,'postal-code',false),
        );
        foreach ($inputs as $key => $input) {
            $required = $input[4] ? ' required' : '';
            echo '<label class="vsc-finalization__field' . (in_array($key, array('address','address_2'), true) ? ' is-wide' : '') . '">'
                . '<span>' . esc_html($input[0]) . ($input[4] ? ' *' : '') . '</span>'
                . '<input name="' . esc_attr($key) . '" type="' . esc_attr($input[1]) . '" maxlength="' . esc_attr($input[2]) . '"'
                . ' autocomplete="' . esc_attr($input[3]) . '" value="' . esc_attr($v[$key]) . '"' . $required . '></label>';
        }
        echo '</div><h4>2. Contul în care primești banii</h4>';
        if (is_array($bank)) {
            echo '<p class="vsc-finalization__saved">Ai deja un cont bancar salvat (IBAN •••• '
                . esc_html(substr($bank['iban'], -4)) . '). Îl vom folosi dacă nu introduci altul.</p>';
        }
        echo '<div class="vsc-finalization__grid"><label class="vsc-finalization__field"><span>Titular cont'
            . (is_array($bank) ? ' (doar dacă schimbi IBAN-ul)' : ' *') . '</span><input name="holder" type="text" maxlength="120" autocomplete="off"'
            . (is_array($bank) ? '' : ' required') . '></label>';
        echo '<label class="vsc-finalization__field"><span>IBAN'
            . (is_array($bank) ? ' (doar dacă îl schimbi)' : ' *') . '</span><input name="iban" type="text" maxlength="50" autocomplete="off" spellcheck="false" autocapitalize="characters" placeholder="RO00 XXXX XXXX XXXX XXXX XXXX"'
            . (is_array($bank) ? '' : ' required') . '></label></div>';
        echo '<p class="vsc-finalization__help">Nu cerem numărul cardului, PIN sau CVV. Datele bancare sunt criptate și se folosesc doar pentru transferul bancar.</p>';
        echo '<h4>3. Predarea sculei</h4><div class="vsc-finalization__delivery"><strong>Ridicare prin curier</strong><p>Scule Bune organizează ridicarea și îți va confirma detaliile. Nu trimite coletul înainte de instrucțiuni.</p></div>';
        $product = trim((string)get_post_meta($id, '_vsc_marca', true) . ' ' . (string)get_post_meta($id, '_vsc_model', true));
        echo '<section class="vsc-finalization__summary" style="display:block!important;clear:both!important;width:100%!important;max-width:none!important;grid-column:1/-1!important;margin:24px 0 0!important"><h4>Rezumatul vânzării</h4>';
        echo '<div class="vsc-finalization__summary-item"><span>Produs</span><strong>' . esc_html($product !== '' ? $product : 'Scula ta') . '</strong></div>';
        echo '<div class="vsc-finalization__summary-item"><span>Ofertă acceptată</span><strong>' . esc_html(number_format_i18n((float)get_post_meta($id, '_vsc_offer_amount', true), 2)) . ' lei</strong></div>';
        echo '<div class="vsc-finalization__summary-item"><span>Predare</span><strong>Ridicare prin curier</strong></div>';
        echo '<p class="vsc-finalization__summary-note">Plata se face prin transfer bancar după verificarea sculei. Dacă evaluarea se schimbă, îți vom cere acordul pentru orice ofertă nouă.</p>';
        echo '<h4>4. Confirmări</h4>';
        echo '<label class="vsc-finalization__consent"><input name="ownership" value="yes" type="checkbox" required> Declar că sunt proprietarul produsului și că am dreptul să îl vând.</label>';
        echo '<label class="vsc-finalization__consent"><input name="terms" value="yes" type="checkbox" required> Am citit și accept '
            . ($url_terms && $url_terms !== home_url('/') ? '<a href="' . esc_url($url_terms) . '" target="_blank" rel="noopener">Termenii și condițiile</a>' : 'condițiile de vânzare și transport') . '.</label>';
        echo '<label class="vsc-finalization__consent"><input name="privacy" value="yes" type="checkbox" required> Am citit '
            . ($url_privacy ? '<a href="' . esc_url($url_privacy) . '" target="_blank" rel="noopener">Politica de confidențialitate</a>' : 'informarea privind prelucrarea datelor') . '.</label>';
        echo '<button type="submit" class="vsc-finalization__button">Confirmă și finalizează vânzarea</button>';
        echo '<p class="vsc-finalization__feedback" role="status" aria-live="polite" hidden></p>';
        echo '</section></div></form></section>';
    }

    /** IBAN-ul complet se livrează numai la cerere, exclusiv administratorului, în etapa de plată. */
    public static function admin_reveal_payment() {
        $id = isset($_POST['request_id']) && is_scalar($_POST['request_id']) ? absint(wp_unslash($_POST['request_id'])) : 0;
        if (!$id || !current_user_can('manage_options') || !current_user_can('edit_post', $id) ||
            !check_ajax_referer('vsc_admin_workflow_' . $id, 'security', false)) {
            wp_send_json_error(array('message' => 'Acces neautorizat.'), 403);
        }
        $post = get_post($id);
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private' ||
            self::workflow_state($id) !== 'verificare_confirmata') {
            wp_send_json_error(array('message' => 'Datele bancare pot fi vizualizate doar în etapa de plată.'), 403);
        }
        $details = self::payment_decrypt($id);
        if ($details === false) {
            wp_send_json_error(array('message' => 'Datele nu sunt disponibile. Cere clientului să le completeze din cont.'), 409);
        }
        nocache_headers();
        wp_send_json_success(array('holder' => $details['holder'], 'iban' => $details['iban']));
    }

    /** Vizualizare în cont: fără date complete precompletate sau trimise spre browser. */
    private static function account_payment_form($id, $state) {
        if (!in_array($state, self::payment_allowed_states(), true) ||
            get_post_meta($id, '_vsc_offer_reply', true) !== 'accept') { return; }
        $has_cipher = (bool)get_post_meta($id, '_vsc_payment_details_secure', true);
        $details = $has_cipher ? self::payment_decrypt($id) : false;
        echo '<section class="vsc-bank-form" data-vsc-payment-form data-sale-id="' . esc_attr($id) . '" aria-label="Date pentru încasare">';
        echo '<h3>Unde dorești să primești banii?</h3>';
        if ($details !== false) {
            echo '<p class="vsc-bank-form__saved" role="status">Datele bancare sunt salvate. IBAN: •••• '
                . esc_html(substr($details['iban'], -4)) . '</p>';
            echo '<p>Poți introduce un alt IBAN pentru a înlocui datele existente. Câmpurile rămân goale pentru protecția contului.</p>';
        } elseif ($has_cipher) {
            echo '<p class="vsc-bank-form__warning">Datele bancare vechi nu pot fi citite. Te rugăm să le introduci din nou.</p>';
        } else {
            echo '<p>După verificarea sculei, îți vom transfera banii în acest cont. Poți completa datele acum sau mai târziu, dar înainte de plată.</p>';
        }
        if (!self::payment_crypto_ready()) {
            echo '<p class="vsc-bank-form__warning">Salvarea bancară securizată este temporar indisponibilă. Contactează echipa Scule Bune.</p></section>';
            return;
        }
        echo '<form class="vsc-bank-form__fields" autocomplete="off" novalidate>';
        echo '<p><label for="vsc-bank-holder">Numele titularului contului</label>';
        echo '<input id="vsc-bank-holder" name="vsc_holder" type="text" autocomplete="off" minlength="3" maxlength="120" required placeholder="Nume și prenume / denumirea firmei"></p>';
        echo '<p><label for="vsc-bank-iban">IBAN (nu numărul cardului)</label>';
        echo '<input id="vsc-bank-iban" name="vsc_iban" type="text" inputmode="text" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="50" required placeholder="RO00 XXXX XXXX XXXX XXXX XXXX"></p>';
        echo '<p class="vsc-bank-form__help">Nu solicităm numărul cardului, CVV, PIN sau parola de internet banking. Verificăm formatul IBAN, nu existența contului. Verifică atent datele înainte de salvare.</p>';
        echo '<div class="vsc-bank-form__buttons"><button type="submit" class="vsc-bank-form__submit">'
            . ($details !== false ? 'Actualizează datele' : 'Salvează datele bancare') . '</button>';
        if ($has_cipher) { echo '<button type="button" class="vsc-bank-form__delete" data-vsc-bank-delete>Șterge datele salvate</button>'; }
        echo '</div><p class="vsc-bank-form__feedback" role="status" aria-live="polite" hidden></p></form></section>';
    }

    /** Stările workflow-ului; nu folosim post_status WordPress pentru ele. */
    public static function workflow_state($id) {
        $s = (string) get_post_meta($id, '_vsc_status', true);
        return in_array($s, array('primită', 'primita'), true) || $s === '' ? 'primita' : $s;
    }

    /** Flux buyback: acceptare -> ridicare -> verificare -> plată sau retur. */
    private static function workflow_transitions($state) {
        $map = array(
            'primita' => array('in_evaluare', 'respinsa'),
            'in_evaluare' => array('primita', 'respinsa'),
            'oferta_trimisa' => array('respinsa'),
            'acceptata' => array('ridicare_programata'),
            'ridicare_programata' => array('in_transport'),
            'in_transport' => array('la_verificare'),
            'la_verificare' => array('verificare_confirmata', 'retur_pregatit'),
            'oferta_revizuita' => array(), // doar clientul poate răspunde
            'verificare_confirmata' => array('platita'),
            'retur_pregatit' => array('returnata'),
            'respinsa' => array(), 'finalizata' => array(), 'retrasa' => array(),
            'platita' => array(), 'returnata' => array(),
        );
        return isset($map[$state]) ? $map[$state] : array();
    }

    /** Etichetele utilizate exclusiv de echipa Scule Bune / administrație. */
    private static function workflow_labels() {
        return array(
            'primita' => 'Cerere primită',
            'in_evaluare' => 'În evaluare',
            'oferta_trimisa' => 'Ofertă trimisă',
            'acceptata' => 'Acceptată de client',
            'ridicare_programata' => 'Ridicare programată',
            'in_transport' => 'În transport',
            'la_verificare' => 'Primită pentru verificare',
            'oferta_revizuita' => 'Ofertă revizuită trimisă',
            'verificare_confirmata' => 'Verificare finalizată – de plată',
            'retur_pregatit' => 'Retur de pregătit',
            'returnata' => 'Retur finalizat',
            'platita' => 'Plată efectuată',
            'respinsa' => 'Cerere respinsă',
            'finalizata' => 'Finalizată (istoric)',
            'retrasa' => 'Retrasă de client',
        );
    }

    /** Update condițional: refuză supra-scrierea unei decizii concurente. */
    private static function change_workflow_state($id, $expected, $next) {
        $raw = (string)get_post_meta($id, '_vsc_status', true);
        $normalized = in_array($raw, array('', 'primită', 'primita'), true) ? 'primita' : $raw;
        if ($normalized !== $expected) { return false; }
        if (!metadata_exists('post', $id, '_vsc_status')) {
            return (bool)add_post_meta($id, '_vsc_status', $next, true);
        }
        global $wpdb;
        $changed = $wpdb->update($wpdb->postmeta, array('meta_value' => $next),
            array('post_id' => $id, 'meta_key' => '_vsc_status', 'meta_value' => $raw),
            array('%s'), array('%d','%s','%s'));
        wp_cache_delete($id, 'post_meta');
        return $changed !== false && $changed === 1;
    }

    /** Mesaj de progres: nu include adrese, IBAN sau date bancare. */
    public static function notify_client_progress($id, $state) {
        $email = sanitize_email((string)get_post_meta($id, '_vsc_email', true));
        if (!is_email($email)) { return false; }
        $courier = (string)get_post_meta($id, '_vsc_transport_curier', true);
        $awb = (string)get_post_meta($id, '_vsc_transport_awb', true);
        $extras = array('Solicitare' => self::reference($id), 'Etapă' => self::account_status($id)[0]);
        if (in_array($state, array('ridicare_programata','in_transport'), true)) {
            if ($courier !== '') { $extras['Curier'] = $courier; }
            if ($awb !== '') { $extras['AWB'] = $awb; }
        }
        if ($state === 'retur_pregatit') {
            $return_awb = (string)get_post_meta($id, '_vsc_retur_awb', true);
            if ($return_awb !== '') { $extras['AWB retur'] = $return_awb; }
        }
        if ($state === 'platita') {
            $extras['Valoarea confirmată'] = number_format_i18n((float)get_post_meta($id, '_vsc_offer_amount', true), 2) . ' lei';
        }
        $notes = array(
            'ridicare_programata' => 'Echipa Scule Bune organizează ridicarea. Nu expedia produsul până nu primești instrucțiuni concrete.',
            'in_transport' => 'Coletul a fost marcat în transport de echipa noastră.',
            'la_verificare' => 'Produsul a ajuns la noi și urmează să fie verificat.',
            'verificare_confirmata' => 'Verificarea este încheiată. Asigură-te că ai completat IBAN-ul în Contul meu → Vânzări pentru a putea primi plata.',
            'retur_pregatit' => 'Returul produsului este în pregătire. Vei fi contactat pentru detaliile expedierii.',
            'returnata' => 'Produsul a fost marcat returnat. Dacă există o problemă, contactează echipa Scule Bune.',
            'platita' => 'Echipa noastră a marcat transferul bancar ca efectuat. Momentul încasării depinde de bancă.',
        );
        $intro = $notes[$state] ?? 'Starea solicitării tale a fost actualizată.';
        $body = self::email_layout('Actualizare solicitare ' . self::reference($id), $intro, self::email_details($extras));
        $ok = self::send_email($email, 'Actualizare Vinde Scula – ' . self::reference($id), $body, self::email_headers());
        update_post_meta($id, '_vsc_last_progress_mail', $ok ? 'accepted_by_mail_server' : 'failed');
        self::workflow_log($id, 'progress_email', $ok ? 'Notificarea de progres a fost predată serverului.' : 'Trimiterea notificării de progres a eșuat.');
        return $ok;
    }

    public static function workflow_log($id, $action, $description) {
        $history = get_post_meta($id, '_vsc_workflow_history', true);
        if (!is_array($history)) { $history = array(); }
        $history[] = array('at' => current_time('mysql'), 'by' => get_current_user_id(),
            'action' => sanitize_key($action), 'description' => sanitize_text_field($description));
        update_post_meta($id, '_vsc_workflow_history', array_slice($history, -50));
    }

    /** Panoul din admin are CSS și JS proprii; nu afectează tema Bigxon. */
    public static function admin_workflow_assets($hook) {
        // Ecranele de statistici și editare au nevoie numai de CSS-ul administrativ.
        $page = isset($_GET['page']) && is_string($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page === 'vsc-panou-oferte' && current_user_can('manage_options')) {
            wp_enqueue_style('vsc-admin-workflow', plugins_url('assets/admin-workflow.css', __FILE__), array(), self::VERSION);
            return;
        }
        // Lista principală (Toate solicitările) nu încărca înainte stilul stărilor.
        if ($hook === 'edit.php') {
            $screen = get_current_screen();
            if ($screen && $screen->post_type === self::TYPE) {
                wp_enqueue_style('vsc-admin-workflow', plugins_url('assets/admin-workflow.css', __FILE__), array(), self::VERSION);
            }
            return;
        }
        if ($hook !== 'post.php' && $hook !== 'post-new.php') { return; }
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== self::TYPE) { return; }
        wp_enqueue_style('vsc-admin-workflow', plugins_url('assets/admin-workflow.css', __FILE__), array(), self::VERSION);
        wp_enqueue_script('vsc-admin-workflow', plugins_url('assets/admin-workflow.js', __FILE__), array(), self::VERSION, true);
    }

    /** Operațiile sensibile sunt validate exclusiv pe server. */
    public static function admin_workflow() {
        $id = isset($_POST['request_id']) && is_scalar($_POST['request_id']) ? absint(wp_unslash($_POST['request_id'])) : 0;
        if (!$id || !(current_user_can('manage_options') || current_user_can('manage_woocommerce')) ||
            !current_user_can('edit_post', $id) || !check_ajax_referer('vsc_admin_workflow_' . $id, 'security', false)) {
            wp_send_json_error(array('message' => 'Nu ai permisiunea necesară sau sesiunea a expirat.'), 403);
        }
        $post = get_post($id);
        if (!$post || $post->post_type !== self::TYPE || $post->post_status !== 'private') {
            wp_send_json_error(array('message' => 'Solicitarea nu mai este disponibilă.'), 404);
        }
        $state = self::workflow_state($id);
        $expected = isset($_POST['expected']) && is_scalar($_POST['expected']) ? sanitize_key(wp_unslash($_POST['expected'])) : '';
        if ($expected !== $state) {
            wp_send_json_error(array('message' => 'Starea solicitării s-a schimbat. Reîncarcă pagina.'), 409);
        }
        if (!isset(self::workflow_labels()[$state])) {
            wp_send_json_error(array('message' => 'Stare necunoscută. Contactează administratorul.'), 409);
        }
        $action = isset($_POST['operation']) && is_scalar($_POST['operation']) ? sanitize_key(wp_unslash($_POST['operation'])) : '';
        if ($action === 'note') {
            // Notele rămân numai în administrare, nu în răspunsuri sau e-mailuri.
            if (!current_user_can('manage_options')) {
                wp_send_json_error(array('message' => 'Doar administratorul poate adăuga note interne.'), 403);
            }
            $note = isset($_POST['note']) && is_string($_POST['note'])
                ? trim(sanitize_textarea_field(wp_unslash($_POST['note']))) : '';
            $length = function_exists('mb_strlen') ? mb_strlen($note, 'UTF-8') : strlen($note);
            if ($length < 1 || $length > 1000) {
                wp_send_json_error(array('message' => 'Nota trebuie să conțină între 1 și 1.000 de caractere.'), 400);
            }
            $notes = get_post_meta($id, '_vsc_admin_notes', true);
            if (!is_array($notes)) { $notes = array(); }
            $notes[] = array('at' => current_time('mysql'), 'by' => get_current_user_id(), 'text' => $note);
            update_post_meta($id, '_vsc_admin_notes', array_slice($notes, -50));
            self::workflow_log($id, 'admin_note', 'Notă internă adăugată de administrator.');
            wp_send_json_success(array('message' => 'Nota internă a fost salvată.'));
        }
        if ($action === 'shipping') {
            if (!in_array($state, array('acceptata','ridicare_programata','in_transport','la_verificare','retur_pregatit'), true)) {
                wp_send_json_error(array('message' => 'Transportul nu poate fi actualizat în această etapă.'), 409);
            }
            $courier = isset($_POST['courier']) && is_scalar($_POST['courier'])
                ? trim(sanitize_text_field(wp_unslash($_POST['courier']))) : '';
            $awb = isset($_POST['awb']) && is_scalar($_POST['awb'])
                ? trim(sanitize_text_field(wp_unslash($_POST['awb']))) : '';
            $return_awb = isset($_POST['return_awb']) && is_scalar($_POST['return_awb'])
                ? trim(sanitize_text_field(wp_unslash($_POST['return_awb']))) : '';
            if (self::length($courier) > 80 || self::length($awb) > 100 || self::length($return_awb) > 100 ||
                ($awb !== '' && !preg_match('/^[\p{L}\p{N} ._\/-]+$/uD', $awb)) ||
                ($return_awb !== '' && !preg_match('/^[\p{L}\p{N} ._\/-]+$/uD', $return_awb))) {
                wp_send_json_error(array('message' => 'Curierul sau numărul AWB conține caractere nepermise ori este prea lung.'), 400);
            }
            update_post_meta($id, '_vsc_transport_curier', $courier);
            update_post_meta($id, '_vsc_transport_awb', $awb);
            if ($state === 'retur_pregatit') { update_post_meta($id, '_vsc_retur_awb', $return_awb); }
            self::workflow_log($id, 'shipping', 'Datele de transport/AWB au fost actualizate.');
            wp_send_json_success(array('message' => 'Datele de transport au fost salvate. Nu s-a generat automat un AWB.'));
        }
        if ($action === 'revision') {
            if ($state !== 'la_verificare') {
                wp_send_json_error(array('message' => 'O ofertă revizuită este permisă numai după primirea produsului la verificare.'), 409);
            }
            $raw = isset($_POST['revision_amount']) && is_scalar($_POST['revision_amount'])
                ? trim(sanitize_text_field(wp_unslash($_POST['revision_amount']))) : '';
            $reason = isset($_POST['revision_reason']) && is_string($_POST['revision_reason'])
                ? trim(sanitize_textarea_field(wp_unslash($_POST['revision_reason']))) : '';
            if (!preg_match('/^\d{1,7}(?:[\.,]\d{1,2})?$/D', $raw)) {
                wp_send_json_error(array('message' => 'Introdu o sumă revizuită validă.'), 400);
            }
            $amount = round((float)str_replace(',', '.', $raw), 2);
            $original = (float)get_post_meta($id, '_vsc_offer_amount', true);
            if ($amount < 1 || $amount > 1000000 || abs($original - $amount) < 0.005 ||
                self::length($reason) < 10 || self::length($reason) > 800) {
                wp_send_json_error(array('message' => 'Suma trebuie să difere de oferta acceptată, iar motivul trebuie să aibă între 10 și 800 caractere.'), 400);
            }
            $email = sanitize_email((string)get_post_meta($id, '_vsc_email', true));
            if (!is_email($email)) { wp_send_json_error(array('message' => 'Adresa de e-mail a clientului nu este validă.'), 400); }
            $mail_body = self::email_layout('Propunere revizuită ' . self::reference($id),
                'După verificarea produsului, propunem o sumă actualizată. Te rugăm să accepți sau să refuzi exclusiv din Contul meu → Vânzări.',
                self::email_details(array('Oferta anterioară' => number_format_i18n($original, 2) . ' lei',
                    'Oferta revizuită' => number_format_i18n($amount, 2) . ' lei'))
                . '<p><strong>Motiv:</strong> ' . nl2br(esc_html($reason)) . '</p>'
                . '<p>Dacă refuzi, vom organiza returnarea produsului conform condițiilor convenite.</p>');
            // Blocare scurtă: împiedică două trimiteri simultane ale aceleiași revizuiri.
            $lock = 'vsc_revision_lock_' . $id;
            if (!add_option($lock, time(), '', 'no')) {
                // Dacă o cerere PHP a fost întreruptă, eliberăm blocajul expirat.
                $locked_at = (int)get_option($lock, 0);
                if ($locked_at > 0 && $locked_at < time() - 15 * MINUTE_IN_SECONDS) {
                    delete_option($lock);
                }
                if (!add_option($lock, time(), '', 'no')) {
                    wp_send_json_error(array('message' => 'Altă trimitere este în curs. Reîncarcă pagina.'), 409);
                }
            }
            if (self::workflow_state($id) !== 'la_verificare') {
                delete_option($lock);
                wp_send_json_error(array('message' => 'Starea s-a modificat. Reîncarcă pagina.'), 409);
            }
            if (!self::send_email($email, 'Ofertă revizuită – ' . self::reference($id), $mail_body, self::email_headers())) {
                self::workflow_log($id, 'revision_mail_failed', 'E-mailul cu revizuirea nu a fost acceptat; starea nu s-a schimbat.');
                delete_option($lock);
                wp_send_json_error(array('message' => 'Serverul de e-mail a respins trimiterea. Revizuirea nu a fost activată.'), 502);
            }
            update_post_meta($id, '_vsc_revision_amount', $amount);
            update_post_meta($id, '_vsc_revision_reason', $reason);
            update_post_meta($id, '_vsc_revision_sent_at', current_time('mysql'));
            delete_post_meta($id, '_vsc_revision_reply');
            if (!self::change_workflow_state($id, 'la_verificare', 'oferta_revizuita')) {
                delete_option($lock);
                wp_send_json_error(array('message' => 'E-mail acceptat, dar starea s-a schimbat simultan. Verifică solicitarea.'), 409);
            }
            self::workflow_log($id, 'revision', 'Ofertă revizuită de ' . number_format_i18n($amount, 2) . ' lei trimisă, motiv înregistrat.');
            delete_option($lock);
            wp_send_json_success(array('message' => 'Oferta revizuită este disponibilă în contul clientului. E-mailul a fost predat serverului.'));
        }
        if ($action === 'status') {
            $revision_lock_at = (int)get_option('vsc_revision_lock_' . $id, 0);
            if ($revision_lock_at > 0 && $revision_lock_at >= time() - 15 * MINUTE_IN_SECONDS) {
                wp_send_json_error(array('message' => 'O ofertă revizuită este în curs de trimitere. Reîncarcă pagina.'), 409);
            }
            $next = isset($_POST['next_status']) && is_scalar($_POST['next_status']) ? sanitize_key(wp_unslash($_POST['next_status'])) : '';
            if ($next === 'acceptata' && !get_post_meta($id, '_vsc_offer_sent_at', true)) {
                wp_send_json_error(array('message' => 'Nu există o ofertă trimisă pentru această solicitare.'), 409);
            }
            if (!in_array($next, self::workflow_transitions($state), true)) {
                wp_send_json_error(array('message' => 'Această schimbare de stare nu este permisă.'), 409);
            }
            if ($state === 'acceptata' && $next === 'ridicare_programata' &&
                (!get_post_meta($id, '_vsc_checkout_completed_at', true) || self::checkout_pickup_decrypt($id) === false)) {
                wp_send_json_error(array('message' => 'Clientul trebuie să finalizeze datele pentru ridicare și încasare în Contul meu → Vânzări.'), 409);
            }
            if ($next === 'in_transport' &&
                (trim((string)get_post_meta($id, '_vsc_transport_curier', true)) === '' ||
                 trim((string)get_post_meta($id, '_vsc_transport_awb', true)) === '')) {
                wp_send_json_error(array('message' => 'Salvează firma de curierat și AWB-ul înainte de a marca transportul.'), 409);
            }
            if ($next === 'platita') {
                if (!current_user_can('manage_options')) {
                    wp_send_json_error(array('message' => 'Doar administratorul poate confirma efectuarea plății.'), 403);
                }
                if (self::payment_decrypt($id) === false) {
                    wp_send_json_error(array('message' => 'Clientul trebuie să salveze un IBAN valid înainte de confirmarea plății.'), 409);
                }
                $payment_confirmed = isset($_POST['payment_confirmed']) && is_scalar($_POST['payment_confirmed'])
                    ? sanitize_text_field(wp_unslash($_POST['payment_confirmed'])) : '';
                if ($payment_confirmed !== 'yes') {
                    wp_send_json_error(array('message' => 'Confirmă explicit că transferul bancar a fost efectuat în afara pluginului.'), 400);
                }
            }
            if (!self::change_workflow_state($id, $state, $next)) {
                wp_send_json_error(array('message' => 'Altă persoană a modificat starea. Reîncarcă pagina.'), 409);
            }
            $labels = self::workflow_labels();
            if ($next === 'platita') {
                update_post_meta($id, '_vsc_payment_confirmed_at', current_time('mysql'));
                update_post_meta($id, '_vsc_payment_confirmed_by', get_current_user_id());
            }
            self::workflow_log($id, 'status', 'Stare schimbată: ' . $labels[$state] . ' → ' . $labels[$next]);
            $needs_mail = in_array($next, array('ridicare_programata','in_transport','la_verificare',
                'verificare_confirmata','retur_pregatit','returnata','platita'), true);
            $mailed = !$needs_mail || self::notify_client_progress($id, $next);
            wp_send_json_success(array('message' => $mailed
                ? 'Starea a fost actualizată. Notificarea, dacă este cazul, a fost predată serverului de e-mail.'
                : 'Starea a fost salvată, dar e-mailul către client NU a putut fi trimis. Contactează clientul manual.',
                'status' => $labels[$next]));
        }
        if ($action === 'offer') {
            if (!in_array($state, array('primita', 'in_evaluare'), true)) {
                wp_send_json_error(array('message' => 'Poți trimite o ofertă numai pentru solicitările primite sau în evaluare.'), 409);
            }
            $raw = isset($_POST['amount']) && is_scalar($_POST['amount']) ? trim(sanitize_text_field(wp_unslash($_POST['amount']))) : '';
            if (!preg_match('/^\d{1,7}(?:[\.,]\d{1,2})?$/D', $raw)) {
                wp_send_json_error(array('message' => 'Introdu o ofertă validă (ex.: 450 sau 450,50).'), 400);
            }
            $amount = round((float)str_replace(',', '.', $raw), 2);
            if ($amount < 1 || $amount > 1000000) {
                wp_send_json_error(array('message' => 'Oferta trebuie să fie între 1 și 1.000.000 lei.'), 400);
            }
            $message = isset($_POST['message']) && is_scalar($_POST['message'])
                ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
            if (self::length($message) > 800) {
                wp_send_json_error(array('message' => 'Mesajul poate avea maximum 800 de caractere.'), 400);
            }
            $email = sanitize_email((string)get_post_meta($id, '_vsc_email', true));
            if (!is_email($email)) {
                wp_send_json_error(array('message' => 'Solicitarea nu are o adresă de e-mail validă.'), 400);
            }
            $client = (string)get_post_meta($id, '_vsc_nume', true);
            $brand = (string)get_post_meta($id, '_vsc_marca', true);
            $model = (string)get_post_meta($id, '_vsc_model', true);
            $subject = 'Oferta pentru scula ta – ' . self::reference($id) . ' – Scule Bune';
            $message_html = $message !== ''
                ? '<h2 style="margin:20px 0 10px;font-size:16px;color:#111111;">Mesaj pentru tine</h2>'
                    . '<p style="font-size:14px;line-height:1.6;margin:0;color:#333333;">' . nl2br(esc_html($message)) . '</p>'
                : '';
            $body = self::email_layout(
                'Oferta pentru scula ta ' . self::reference($id),
                'Salut, ' . $client . '! Am evaluat solicitarea ta și îți transmitem oferta noastră.',
                self::email_details(array(
                    'Nr. comenzii' => self::reference($id),
                    'Produs' => trim($brand . ' ' . $model),
                    'Oferta noastră' => number_format_i18n($amount, 2) . ' lei',
                ))
                . $message_html
                . '<p style="font-size:14px;line-height:1.65;color:#333333;margin:20px 0 0;">'
                . 'Pentru a accepta sau refuza oferta, intră în Contul meu → Vânzări. '
                . 'Datele bancare vor fi solicitate numai după confirmarea acceptării ofertei.'
                . '</p>'
            );
            $headers = self::email_headers();
            // Salvăm ciorna pentru recuperare dacă serverul refuză trimiterea.
            update_post_meta($id, '_vsc_offer_draft_amount', $amount);
            update_post_meta($id, '_vsc_offer_draft_message', $message);
            if (!self::send_email($email, $subject, $body, $headers)) {
                self::workflow_log($id, 'mail_failed', 'Încercare nereușită de trimitere ofertă; ciornă păstrată.');
                wp_send_json_error(array('message' => 'Serverul de e-mail nu a acceptat oferta. Nu am schimbat starea; poți reîncerca.'), 502);
            }
            update_post_meta($id, '_vsc_offer_amount', $amount);
            update_post_meta($id, '_vsc_offer_message', $message);
            update_post_meta($id, '_vsc_offer_sent_at', current_time('mysql'));
            update_post_meta($id, '_vsc_offer_mail', 'accepted_by_mail_server');
            update_post_meta($id, '_vsc_status', 'oferta_trimisa');
            delete_post_meta($id, '_vsc_offer_draft_amount');
            delete_post_meta($id, '_vsc_offer_draft_message');
            self::workflow_log($id, 'offer', 'Ofertă de ' . number_format_i18n($amount, 2) . ' lei predată serverului de e-mail.');
            wp_send_json_success(array('message' => 'Oferta a fost predată serverului de e-mail și înregistrată. Livrarea efectivă trebuie verificată.'));
        }
        wp_send_json_error(array('message' => 'Operație necunoscută.'), 400);
    }

    /** Interfață ghidată: întâi decizia și pasul următor, apoi informațiile opționale. */
    public static function workflow_box($post) {
        if (!(current_user_can('manage_options') || current_user_can('manage_woocommerce'))) {
            echo '<p>Evaluarea solicitărilor este rezervată echipei autorizate.</p>'; return;
        }
        $id = (int)$post->ID;
        if (!$id || $post->post_status !== 'private') {
            echo '<p>Salvează solicitarea ca privată pentru a gestiona evaluarea.</p>'; return;
        }
        $state = self::workflow_state($id);
        $labels = self::workflow_labels();
        $transitions = self::workflow_transitions($state);
        $sent = (string)get_post_meta($id, '_vsc_offer_sent_at', true);
        $amount = (float)get_post_meta($id, '_vsc_offer_amount', true);
        $draft = get_post_meta($id, '_vsc_offer_draft_amount', true);
        $draft_message = (string)get_post_meta($id, '_vsc_offer_draft_message', true);
        $reply = (string)get_post_meta($id, '_vsc_offer_reply', true);
        $reply_at = (string)get_post_meta($id, '_vsc_offer_reply_at', true);
        $revision_amount = (float)get_post_meta($id, '_vsc_revision_amount', true);
        $revision_reply = (string)get_post_meta($id, '_vsc_revision_reply', true);
        $product = trim((string)get_post_meta($id, '_vsc_marca', true) . ' ' . (string)get_post_meta($id, '_vsc_model', true));
        $courier = (string)get_post_meta($id, '_vsc_transport_curier', true);
        $awb = (string)get_post_meta($id, '_vsc_transport_awb', true);
        $return_awb = (string)get_post_meta($id, '_vsc_retur_awb', true);
        $finished = in_array($state, array('respinsa','retrasa','finalizata','platita','returnata'), true);
        $tone = in_array($state, array('respinsa','retrasa'), true) ? 'rejected'
            : (in_array($state, array('platita','returnata','finalizata'), true) ? 'complete'
            : (in_array($state, array('acceptata','verificare_confirmata'), true) ? 'accepted' : 'pending'));
        $next_text = array(
            'primita' => 'Verifică detaliile și începe evaluarea. Dacă ai evaluat deja scula, poți trimite direct oferta.',
            'in_evaluare' => 'Stabilește suma pe care o oferă Scule Bune și trimite oferta clientului.',
            'oferta_trimisa' => 'Așteaptă acceptul sau refuzul clientului în Contul meu → Vânzări.',
            'acceptata' => 'Așteaptă ca vânzătorul să finalizeze datele pentru ridicare și plată. După finalizare, poți organiza curierul.',
            'ridicare_programata' => 'Salvează firma de curierat și AWB-ul, apoi confirmă când coletul a fost preluat.',
            'in_transport' => 'Urmărește coletul. Când scula ajunge la magazin, confirmă primirea pentru verificare.',
            'la_verificare' => 'Verifică starea reală a sculei. Confirmă suma acceptată sau propune o sumă nouă, cu motiv.',
            'oferta_revizuita' => 'Așteaptă răspunsul clientului la noua ofertă. Nu confirma plata înainte de răspuns.',
            'verificare_confirmata' => 'Verifică datele bancare salvate de client, efectuează transferul separat de plugin și marchează plata doar după efectuare.',
            'retur_pregatit' => 'Organizează returnarea sculei și marchează returul după ce a fost efectuat.',
            'platita' => 'Nu mai este nimic de făcut în acest panou. Transferul a fost marcat ca efectuat.',
            'returnata' => 'Nu mai este nimic de făcut în acest panou. Returul a fost marcat ca finalizat.',
            'finalizata' => 'Solicitarea este închisă. Nu mai sunt disponibile acțiuni.',
            'retrasa' => 'Solicitarea a fost retrasă. Nu mai sunt disponibile acțiuni.',
            'respinsa' => $reply === 'refuse'
                ? 'Clientul a refuzat oferta. Solicitarea este închisă și nu mai trebuie să faci nimic.'
                : 'Solicitarea este respinsă. Nu mai sunt disponibile acțiuni.',
        );

        echo '<div class="vsc-admin-workflow" data-request-id="' . esc_attr($id) . '" data-state="' . esc_attr($state)
            . '" data-url="' . esc_url(admin_url('admin-ajax.php')) . '" data-nonce="' . esc_attr(wp_create_nonce('vsc_admin_workflow_' . $id)) . '">';
        echo '<div class="vsc-admin-overview">';
        echo '<div class="vsc-admin-overview-header"><div><div class="vsc-admin-eyebrow">SOLICITARE ' . esc_html(self::reference($id))
            . '</div><h3>' . esc_html($product !== '' ? $product : 'Produs fără model specificat') . '</h3></div>';
        echo '<span class="vsc-admin-badge is-' . esc_attr($tone) . '">' . esc_html(self::admin_status_label($id)) . '</span></div>';
        echo '<div class="vsc-admin-overview-cards">';
        echo '<div class="vsc-admin-overview-card"><span>OFERTA SCULE BUNE</span>';
        if ($sent && $amount > 0) {
            echo '<strong>' . esc_html(number_format_i18n($amount, 2)) . ' lei</strong><small>Trimisă la ' . esc_html($sent) . '</small>';
        } else {
            echo '<strong class="vsc-admin-empty">Nu a fost trimisă</strong>';
        }
        echo '</div><div class="vsc-admin-overview-card"><span>RĂSPUNSUL CLIENTULUI</span>';
        if ($reply === 'refuse') {
            echo '<strong class="vsc-admin-response is-rejected">Refuzată</strong>';
        } elseif ($reply === 'accept') {
            echo '<strong class="vsc-admin-response is-accepted">Acceptată</strong>';
        } else {
            echo '<strong class="vsc-admin-empty">' . ($sent ? 'În așteptare' : 'Nu există încă ofertă') . '</strong>';
        }
        if ($reply_at !== '') { echo '<small>' . esc_html($reply_at) . '</small>'; }
        echo '</div></div>';
        if ($revision_amount > 0 && in_array($state, array('oferta_revizuita','verificare_confirmata','retur_pregatit','returnata','platita'), true)) {
            echo '<div class="vsc-admin-revision-summary"><strong>Ofertă revizuită: ' . esc_html(number_format_i18n($revision_amount, 2)) . ' lei</strong>';
            if ($revision_reply === 'accept') { echo ' · acceptată de client'; }
            elseif ($revision_reply === 'refuse') { echo ' · refuzată de client'; }
            else { echo ' · în așteptarea răspunsului'; }
            echo '</div>';
        }
        echo '</div>';
        if (in_array($state, array('acceptata','ridicare_programata','in_transport','la_verificare','verificare_confirmata'), true)) {
            $pickup = self::checkout_pickup_decrypt($id);
            echo '<div class="vsc-admin-pickup"><h3>Date pentru ridicare (client)</h3>';
            if ($pickup !== false && get_post_meta($id, '_vsc_checkout_completed_at', true)) {
                echo '<p><strong>Formular finalizat.</strong> Detaliile sunt disponibile doar în administrare.</p>';
                if (current_user_can('manage_options')) {
                    echo '<dl>';
                    $pickup_items = array('last_name'=>'Nume','first_name'=>'Prenume','phone'=>'Telefon',
                        'email'=>'Email','address'=>'Adresă','address_2'=>'Adresă suplimentară',
                        'county'=>'Județ','city'=>'Localitate','postcode'=>'Cod poștal');
                    foreach ($pickup_items as $k=>$title) {
                        if (!empty($pickup[$k])) { echo '<dt>' . esc_html($title) . '</dt><dd>' . esc_html($pickup[$k]) . '</dd>'; }
                    }
                    echo '</dl>';
                }
            } elseif ($state === 'acceptata') {
                echo '<p class="vsc-admin-pickup__warning"><strong>Așteaptă clientul.</strong> Clientul trebuie să apese „Finalizează vânzarea” și să completeze adresa și IBAN-ul din Contul meu → Vânzări. Nu programa încă ridicarea.</p>';
            } else {
                echo '<p>Această solicitare a început înainte de introducerea noului formular. Verifică datele de contact din detaliile solicitării înainte să contactezi curierul.</p>';
            }
            echo '</div>';
        }
        echo '<p class="vsc-admin-feedback" role="status" aria-live="polite" hidden></p>';

        if ($state === 'acceptata' && get_post_meta($id, '_vsc_checkout_completed_at', true) && self::checkout_pickup_decrypt($id) !== false) {
            $next_text['acceptata'] = 'Datele de ridicare și încasare sunt primite. Poți organiza curierul și confirma programarea.';
        }
        echo '<section class="vsc-admin-next-step' . ($finished ? ' is-final' : '') . '" aria-label="Următoarea acțiune">';
        echo '<h3>' . ($finished ? 'Situația solicitării' : 'Ce trebuie să faci acum?') . '</h3>';
        echo '<p>' . esc_html($next_text[$state] ?? 'Verifică starea solicitării înainte de orice modificare.') . '</p>';

        if ($state === 'primita') {
            echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="in_evaluare">Începe evaluarea</button>';
        }
        if (in_array($state, array('primita','in_evaluare'), true)) {
            if ($state === 'primita') { echo '<details class="vsc-admin-inline-details"><summary>Ai evaluat deja? Trimite oferta direct</summary>'; }
            echo '<div class="vsc-admin-action-form"><h4>Trimite o ofertă clientului</h4>';
            echo '<p><label for="vsc-offer-amount">Suma oferită (lei)</label><input id="vsc-offer-amount" type="text" inputmode="decimal" maxlength="12" placeholder="Ex.: 450,00" value="' . esc_attr($draft !== '' ? (string)$draft : '') . '"></p>';
            echo '<p><label for="vsc-offer-message">Mesaj pentru client (opțional)</label><textarea id="vsc-offer-message" rows="3" maxlength="800" placeholder="Poți explica pe scurt oferta">' . esc_textarea($draft_message) . '</textarea></p>';
            echo '<p class="description">Oferta va fi trimisă la adresa ' . esc_html((string)get_post_meta($id, '_vsc_email', true)) . '.</p>';
            echo '<button class="button button-primary" type="button" data-workflow-operation="offer">Trimite oferta</button></div>';
            if ($state === 'primita') { echo '</details>'; }
        }
        if (in_array($state, array('acceptata','ridicare_programata'), true)) {
            echo '<div class="vsc-admin-action-form"><h4>Transportul sculei</h4>';
            echo '<p><label for="vsc-shipping-courier">Firma de curierat</label><input id="vsc-shipping-courier" type="text" maxlength="80" value="' . esc_attr($courier) . '" placeholder="Ex.: FAN Courier"></p>';
            echo '<p><label for="vsc-shipping-awb">Număr AWB (când este disponibil)</label><input id="vsc-shipping-awb" type="text" maxlength="100" value="' . esc_attr($awb) . '" placeholder="Numărul de expediție"></p>';
            echo '<button type="button" class="button button-secondary" data-workflow-operation="shipping">Salvează curierul și AWB-ul</button>';
            echo '<p class="description">Curierul se comandă separat; acest formular doar păstrează datele.</p></div>';
            if ($state === 'acceptata') {
                if (get_post_meta($id, '_vsc_checkout_completed_at', true) && self::checkout_pickup_decrypt($id) !== false) {
                    echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="ridicare_programata">Confirmă programarea ridicării</button>';
                }
            } else {
                echo '<p class="vsc-admin-action-hint">După salvarea curierului și a AWB-ului:</p>';
                echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="in_transport">Marchează coletul în transport</button>';
            }
        }
        if ($state === 'in_transport') {
            if ($awb !== '' || $courier !== '') {
                echo '<p class="vsc-admin-transport-preview"><strong>Transport:</strong> ' . esc_html(trim($courier . ' · ' . $awb, ' ·')) . '</p>';
            }
            echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="la_verificare">Confirmă primirea coletului</button>';
        }
        if ($state === 'la_verificare') {
            echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="verificare_confirmata">Confirmă verificarea – prețul rămâne neschimbat</button>';
            echo '<details class="vsc-admin-inline-details"><summary>Scula nu corespunde? Propune altă sumă</summary>';
            echo '<div class="vsc-admin-action-form"><p><label for="vsc-revision-amount">Noua ofertă (lei)</label><input id="vsc-revision-amount" type="text" inputmode="decimal" maxlength="12" placeholder="Ex.: 500,00"></p>';
            echo '<p><label for="vsc-revision-reason">Motivul schimbării (vizibil clientului)</label><textarea id="vsc-revision-reason" rows="3" maxlength="800" placeholder="Descrie diferențele observate la verificare"></textarea></p>';
            echo '<button class="button button-secondary" type="button" data-workflow-operation="revision">Trimite oferta revizuită</button></div></details>';
            echo '<p class="description">Dacă produsul nu poate fi cumpărat, inițiază returul din „Opțiuni avansate”.</p>';
        }
        if ($state === 'oferta_revizuita') {
            echo '<p><strong>Motivul revizuirii:</strong> ' . nl2br(esc_html((string)get_post_meta($id, '_vsc_revision_reason', true))) . '</p>';
        }
        if ($state === 'verificare_confirmata') {
            $payment_admin_ready = current_user_can('manage_options') && self::payment_decrypt($id) !== false;
            if (current_user_can('manage_options')) {
                if ($payment_admin_ready) {
                    echo '<div class="vsc-admin-bank-status is-ready"><strong>Date bancare primite</strong><p>IBAN-ul complet nu este afișat automat.</p>';
                    echo '<button type="button" class="button button-secondary" data-vsc-reveal-bank>Vezi IBAN și titularul pentru plată</button>';
                    echo '<div class="vsc-admin-bank-secret" role="status" aria-live="polite" hidden></div></div>';
                } else {
                    echo '<div class="vsc-admin-bank-status is-missing"><strong>Date bancare lipsă</strong><p>Cere clientului să intre în Contul meu → Vânzări → Detalii solicitare și să salveze titularul și IBAN-ul. Nu efectua plata până atunci.</p></div>';
                }
            } else {
                echo '<p class="description">Vizualizarea datelor bancare este rezervată administratorului.</p>';
            }
            if ($payment_admin_ready) {
                echo '<p><label class="vsc-admin-payment"><input type="checkbox" id="vsc-payment-confirmed" value="yes"> Confirm că am efectuat deja transferul bancar, separat de plugin.</label></p>';
                echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="platita">Marchează ca plătită</button>';
                echo '<p class="description">Acest buton doar înregistrează efectuarea transferului; nu trimite bani.</p>';
            }
        }
        if ($state === 'retur_pregatit') {
            echo '<div class="vsc-admin-action-form"><h4>Transport retur</h4>';
            echo '<p><label for="vsc-shipping-courier">Firma de curierat</label><input id="vsc-shipping-courier" type="text" maxlength="80" value="' . esc_attr($courier) . '"></p>';
            echo '<p><label for="vsc-shipping-awb">AWB ridicare inițială</label><input id="vsc-shipping-awb" type="text" maxlength="100" value="' . esc_attr($awb) . '"></p>';
            echo '<p><label for="vsc-return-awb">AWB retur</label><input id="vsc-return-awb" type="text" maxlength="100" value="' . esc_attr($return_awb) . '" placeholder="Numărul de retur"></p>';
            echo '<button class="button button-secondary" type="button" data-workflow-operation="shipping">Salvează datele returului</button></div>';
            echo '<button class="button button-primary" type="button" data-workflow-operation="status" data-next-state="returnata">Confirmă returul finalizat</button>';
        }
        echo '</section>';

        // Nu afișăm o acțiune de plată manuală înainte de primirea datelor bancare.
        if ($state === 'verificare_confirmata' && empty($payment_admin_ready)) { $transitions = array(); }
        // Opțiunile manuale sunt accesibile fără să domine primul ecran.
        if ($transitions || in_array($state, array('in_transport','la_verificare'), true)) {
            echo '<details class="vsc-admin-more"><summary>Opțiuni avansate</summary>';
            if ($transitions) {
                echo '<p class="description">Folosește schimbarea manuală numai dacă situația a fost confirmată prin alt canal.</p>';
                echo '<div class="vsc-admin-row"><label for="vsc-next-state">Schimbă starea</label><select id="vsc-next-state">';
                foreach ($transitions as $target) {
                    if ($target === 'platita' &&
                        (!current_user_can('manage_options') || self::payment_decrypt($id) === false)) { continue; }
                    echo '<option value="' . esc_attr($target) . '">' . esc_html($labels[$target] ?? $target) . '</option>';
                }
                echo '</select><button class="button" type="button" data-workflow-operation="status">Actualizează starea manual</button></div>';
            }
            if (in_array($state, array('in_transport','la_verificare'), true)) {
                echo '<h4>Corectează datele de transport</h4>';
                echo '<p><label for="vsc-shipping-courier">Firma de curierat</label><input id="vsc-shipping-courier" type="text" maxlength="80" value="' . esc_attr($courier) . '"></p>';
                echo '<p><label for="vsc-shipping-awb">AWB</label><input id="vsc-shipping-awb" type="text" maxlength="100" value="' . esc_attr($awb) . '"></p>';
                echo '<button type="button" class="button" data-workflow-operation="shipping">Salvează corectura</button>';
            }
            echo '<p class="description">Notificările automate sunt predate serverului de e-mail; primirea în inbox nu poate fi garantată.</p></details>';
        }

        echo '<details class="vsc-admin-more"><summary>Istoric și notițe (opțional)</summary>';
        if ($sent) {
            echo '<p><strong>Ofertă transmisă:</strong> ' . esc_html(number_format_i18n($amount, 2)) . ' lei · ' . esc_html($sent) . '</p>';
        }
        if (in_array($reply, array('accept','refuse'), true)) {
            $notice_state = (string)get_post_meta($id, '_vsc_offer_reply_notice', true);
            $notice_states = array('sent'=>'Predată serverului de e-mail', 'pending'=>'În așteptare',
                'retry'=>'Se reîncearcă', 'failed'=>'Trimitere eșuată', 'schedule_failed'=>'Programare nereușită');
            echo '<p><strong>Decizia inițială:</strong> ' . ($reply === 'accept' ? 'Acceptată' : 'Refuzată')
                . ' · ' . esc_html($reply_at) . '</p>';
            echo '<p><strong>Notificarea administratorului:</strong> ' . esc_html($notice_states[$notice_state] ?? 'Necunoscută') . '</p>';
        }
        if (current_user_can('manage_options')) {
            echo '<h4>Notițe interne (doar administrator)</h4>';
            echo '<p class="description">Nu sunt trimise clientului. După salvare nu pot fi editate.</p>';
            echo '<p><label for="vsc-admin-note">Notă nouă</label><textarea id="vsc-admin-note" rows="3" maxlength="1000" placeholder="Ex.: Contactat clientul, așteptăm răspunsul curierului."></textarea></p>';
            echo '<button type="button" class="button" data-workflow-operation="note">Salvează nota</button>';
            $notes = get_post_meta($id, '_vsc_admin_notes', true);
            if (is_array($notes) && $notes) {
                echo '<ol class="vsc-admin-history vsc-admin-notes">';
                foreach (array_reverse(array_slice($notes, -10)) as $item) {
                    if (!is_array($item)) { continue; }
                    $author = get_userdata(absint($item['by'] ?? 0));
                    echo '<li><strong>' . esc_html((string)($item['at'] ?? '')) . '</strong> · '
                        . esc_html($author ? $author->display_name : 'Administrator') . '<div class="vsc-admin-note-body">'
                        . nl2br(esc_html((string)($item['text'] ?? ''))) . '</div></li>';
                }
                echo '</ol>';
            }
        }
        $history = get_post_meta($id, '_vsc_workflow_history', true);
        if (is_array($history) && $history) {
            echo '<h4>Istoric acțiuni</h4><ol class="vsc-admin-history">';
            foreach (array_reverse(array_slice($history, -12)) as $event) {
                if (!is_array($event)) { continue; }
                $who = get_userdata(absint($event['by'] ?? 0));
                echo '<li><strong>' . esc_html((string)($event['at'] ?? '')) . '</strong> · '
                    . esc_html((string)($event['description'] ?? '')) . ' <small>— '
                    . esc_html($who ? $who->display_name : 'Administrator') . '</small></li>';
            }
            echo '</ol>';
        }
        echo '</details></div>';
    }

    public static function meta_box() {
        add_meta_box('vsc_solicitare_workflow', 'Situația solicitării și pașii următori', array(__CLASS__, 'workflow_box'), self::TYPE, 'normal', 'high');
        add_meta_box('vsc_solicitare_details', 'Detaliile solicitării', array(__CLASS__, 'meta_content'), self::TYPE, 'normal', 'default');
    }

    /** Rezoluția și mărimea ORIGINALULUI, numai pentru pagina de administrare. */
    private static function admin_photo_file_info($path) {
        if (!is_string($path) || $path === '' || is_link($path) || !is_file($path) || !is_readable($path)) {
            return 'Informații indisponibile';
        }
        $parts = array();
        $dimensions = @getimagesize($path);
        if (is_array($dimensions) && !empty($dimensions[0]) && !empty($dimensions[1])) {
            $parts[] = (int)$dimensions[0] . ' × ' . (int)$dimensions[1] . ' px';
        }
        $bytes = @filesize($path);
        if (is_int($bytes) && $bytes >= 0) {
            $parts[] = size_format($bytes, 1);
        }
        return $parts ? implode(' · ', $parts) : 'Informații indisponibile';
    }

    public static function meta_content($post) {
        $categories = self::categories();
        $category = get_post_meta($post->ID, '_vsc_categoria', true);
        $package = get_post_meta($post->ID, '_vsc_pachet', true);
        $fields = array(
            'Nr. comenzii' => self::reference($post->ID),
            'Stare solicitare' => self::admin_status_label($post->ID),
            'Categorie' => isset($categories[$category]) ? $categories[$category]['title'] : $category,
            'Marcă' => get_post_meta($post->ID, '_vsc_marca', true),
            'Model' => get_post_meta($post->ID, '_vsc_model', true),
            'An fabricație' => get_post_meta($post->ID, '_vsc_an_fabricatie', true),
            'Platformă acumulator' => get_post_meta($post->ID, '_vsc_platforma', true),
            'Stare' => get_post_meta($post->ID, '_vsc_stare', true),
            'Preț dorit' => ((float)get_post_meta($post->ID, '_vsc_pret', true) > 0 ? get_post_meta($post->ID, '_vsc_pret', true) . ' lei' : ''),
            'Descriere' => get_post_meta($post->ID, '_vsc_descriere', true),
            'Nume' => get_post_meta($post->ID, '_vsc_nume', true),
            'Telefon' => get_post_meta($post->ID, '_vsc_telefon', true),
            'E-mail' => get_post_meta($post->ID, '_vsc_email', true),
            'Județ' => get_post_meta($post->ID, '_vsc_judet', true),
            'Localitate' => get_post_meta($post->ID, '_vsc_localitate', true),
            'Acord de prelucrare' => get_post_meta($post->ID, '_vsc_acord_data', true),
            'Procesare notificări' => get_post_meta($post->ID, '_vsc_background_status', true) ?: 'necunoscută',
            'E-mail administrator' => get_post_meta($post->ID, '_vsc_mail_admin', true) === 'sent' ? 'Predat serverului de e-mail' : 'În așteptare / nereușit',
            'E-mail client' => get_post_meta($post->ID, '_vsc_mail_client', true) === 'sent' ? 'Predat serverului de e-mail' : 'În așteptare / nereușit',
        );
        $offered_at = get_post_meta($post->ID, '_vsc_offer_sent_at', true);
        if ($offered_at) {
            $fields['Preț ofertat'] = number_format_i18n((float)get_post_meta($post->ID, '_vsc_offer_amount', true), 2) . ' lei';
            $fields['Oferta trimisă la'] = $offered_at;
        }
        if (get_post_meta($post->ID, '_vsc_metoda_incasare', true) === 'transfer_bancar') {
            $fields['Metoda de încasare'] = 'Transfer bancar';
        }
        if ($category === 'scule-acumulator') {
            $options = self::package_options();
            $fields = array_slice($fields, 0, 3, true) + array('Configurație' => isset($options[$package]) ? $options[$package] : 'Nespecificată') + array_slice($fields, 3, null, true);
        }
        $kit_details = self::kit_details_for_display($post->ID);
        if ($kit_details) {
            // Inserăm informațiile noi după configurația produsului.
            $top = array_slice($fields, 0, 4, true);
            $rest = array_slice($fields, 4, null, true);
            $fields = $top + $kit_details + $rest;
        }
        echo '<table class="widefat striped"><tbody>';
        foreach ($fields as $label => $value) { if ((string)$value === '') { continue; } echo '<tr><th scope="row" style="width:160px">' . esc_html($label) . '</th><td>' . nl2br(esc_html((string)$value)) . '</td></tr>'; }
        echo '</tbody></table>';
        $photos = get_post_meta($post->ID, '_vsc_fotografii', true);
        $private_photos = self::private_photos($post->ID);
        if ((is_array($photos) && $photos) || $private_photos) {
            echo '<h3>Fotografii</h3><div style="display:flex;flex-wrap:wrap;align-items:flex-start;gap:12px">';
            if (is_array($photos)) {
                foreach ($photos as $photo_id) {
                    $photo_id = absint($photo_id);
                    $url = wp_get_attachment_url($photo_id);
                    if (!$url) { continue; }
                    $info = self::admin_photo_file_info(get_attached_file($photo_id));
                    echo '<div style="width:135px;text-align:center">';
                    echo '<a target="_blank" rel="noopener noreferrer" href="' . esc_url($url) . '">' . wp_get_attachment_image($photo_id, array(135, 135)) . '</a>';
                    echo '<div style="font-size:11px;line-height:1.5;color:#646970;margin-top:5px">' . esc_html($info) . '</div>';
                    echo '</div>';
                }
            }
            $private_dir = self::private_request_dir($post->ID);
            foreach ($private_photos as $filename) {
                $url = self::private_photo_url($post->ID, $filename);
                $preview_url = self::private_photo_url($post->ID, $filename, true);
                if (!$url || !$preview_url) { continue; }
                $info = self::admin_photo_file_info($private_dir ? $private_dir . '/' . $filename : '');
                echo '<div style="width:135px;text-align:center">';
                echo '<a target="_blank" rel="noopener noreferrer" href="' . esc_url($url) . '"><img src="' . esc_url($preview_url) . '" width="135" height="135" style="object-fit:contain" loading="lazy" decoding="async" alt="Fotografie privată"></a>';
                echo '<div style="font-size:11px;line-height:1.5;color:#646970;margin-top:5px">' . esc_html($info) . '</div>';
                echo '</div>';
            }
            echo '</div>';
        }
    }

    public static function columns($columns) {
        return array('cb' => '<input type="checkbox">', 'vsc_ref' => 'Nr. comenzii', 'title' => 'Solicitare', 'vsc_status' => 'Stare solicitare', 'vsc_category' => 'Categorie',
            'vsc_brand' => 'Marcă', 'vsc_price' => 'Preț', 'vsc_phone' => 'Telefon', 'date' => 'Data');
    }

    public static function column($column, $post_id) {
        if ($column === 'vsc_ref') { echo esc_html(self::reference($post_id)); }
        elseif ($column === 'vsc_status') { echo self::admin_status_badge($post_id); }
        elseif ($column === 'vsc_category') {
            $key = get_post_meta($post_id, '_vsc_categoria', true);
            $categories = self::categories();
            echo esc_html(isset($categories[$key]) ? $categories[$key]['title'] : $key);
        } elseif ($column === 'vsc_brand') { echo esc_html(get_post_meta($post_id, '_vsc_marca', true)); }
        elseif ($column === 'vsc_price') { echo esc_html(get_post_meta($post_id, '_vsc_pret', true)) . ' lei'; }
        elseif ($column === 'vsc_phone') { echo esc_html(get_post_meta($post_id, '_vsc_telefon', true)); }
    }

    /** Filtru de stare în lista standard de solicitări WordPress. */
    public static function admin_status_filter($post_type, $which = 'top') {
        if ($post_type !== self::TYPE || $which !== 'top') { return; }
        $current = isset($_GET['vsc_status']) && is_string($_GET['vsc_status'])
            ? sanitize_key(wp_unslash($_GET['vsc_status'])) : '';
        echo '<label class="screen-reader-text" for="vsc-status-filter">Filtrează după starea solicitării</label>';
        echo '<select name="vsc_status" id="vsc-status-filter"><option value="">Toate stările Vinde Scula</option>';
        foreach (self::workflow_labels() as $value => $label) {
            if ($value === 'respinsa') { $label = 'Cereri respinse / oferte refuzate'; }
            echo '<option value="' . esc_attr($value) . '"' . selected($current, $value, false)
                . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }

    /** Aplică filtrarea doar interogării principale din lista acestui post type. */
    public static function admin_filter_requests($query) {
        if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== self::TYPE) { return; }
        $status = isset($_GET['vsc_status']) && is_string($_GET['vsc_status'])
            ? sanitize_key(wp_unslash($_GET['vsc_status'])) : '';
        $labels = self::workflow_labels();
        if (!isset($labels[$status])) { return; }
        $condition = $status === 'primita'
            ? array('relation' => 'OR',
                array('key' => '_vsc_status', 'compare' => 'NOT EXISTS'),
                array('key' => '_vsc_status', 'value' => array('', 'primita', 'primită'), 'compare' => 'IN'))
            : array('key' => '_vsc_status', 'value' => $status, 'compare' => '=');
        $meta_query = $query->get('meta_query');
        if (!is_array($meta_query)) { $meta_query = array(); }
        $meta_query[] = $condition;
        $query->set('meta_query', $meta_query);
    }

    /** Statistici agregate fără încărcarea tuturor solicitărilor în memorie. */
    private static function admin_offer_counts() {
        global $wpdb;
        $counts = array_fill_keys(array_keys(self::workflow_labels()), 0);
        $counts['accept_client'] = 0;
        $counts['refuse_client'] = 0;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT m.meta_value AS state, COUNT(DISTINCT p.ID) AS total
             FROM {$wpdb->posts} AS p
             LEFT JOIN {$wpdb->postmeta} AS m ON m.post_id = p.ID AND m.meta_key = %s
             WHERE p.post_type = %s AND p.post_status = 'private'
             GROUP BY m.meta_value", '_vsc_status', self::TYPE), ARRAY_A);
        foreach ((array)$rows as $row) {
            $state = isset($row['state']) ? (string)$row['state'] : '';
            if ($state === '' || $state === 'primită') { $state = 'primita'; }
            if (isset($counts[$state])) { $counts[$state] += (int)$row['total']; }
        }
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT m.meta_value AS reply, COUNT(DISTINCT p.ID) AS total
             FROM {$wpdb->posts} AS p
             INNER JOIN {$wpdb->postmeta} AS m ON m.post_id = p.ID AND m.meta_key = %s
             WHERE p.post_type = %s AND p.post_status = 'private'
               AND m.meta_value IN ('accept', 'refuse')
             GROUP BY m.meta_value", '_vsc_offer_reply', self::TYPE), ARRAY_A);
        foreach ((array)$rows as $row) {
            $reply = (string)$row['reply'];
            if ($reply === 'accept' || $reply === 'refuse') { $counts[$reply . '_client'] = (int)$row['total']; }
        }
        return $counts;
    }

    /** Panou pentru deciziile luate de clienți; acces administrativ exclusiv. */
    public static function admin_offers_dashboard() {
        if (!current_user_can('manage_options')) { wp_die('Acces interzis.', '', array('response' => 403)); }
        $filter = isset($_GET['vsc_reply']) && is_string($_GET['vsc_reply'])
            ? sanitize_key(wp_unslash($_GET['vsc_reply'])) : 'all';
        if (!in_array($filter, array('all', 'accept', 'refuse'), true)) { $filter = 'all'; }
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $counts = self::admin_offer_counts();
        $admin_list = admin_url('edit.php?post_type=' . self::TYPE);
        $dashboard = add_query_arg(array('post_type' => self::TYPE, 'page' => 'vsc-panou-oferte'), admin_url('edit.php'));
        $cards = array(
            array('label' => 'Cereri primite', 'count' => $counts['primita'], 'url' => add_query_arg('vsc_status', 'primita', $admin_list)),
            array('label' => 'În evaluare', 'count' => $counts['in_evaluare'], 'url' => add_query_arg('vsc_status', 'in_evaluare', $admin_list)),
            array('label' => 'Oferte în așteptarea răspunsului', 'count' => $counts['oferta_trimisa'], 'url' => add_query_arg('vsc_status', 'oferta_trimisa', $admin_list)),
            array('label' => 'Acceptate de client', 'count' => $counts['accept_client'], 'url' => add_query_arg('vsc_reply', 'accept', $dashboard)),
            array('label' => 'Refuzate de client', 'count' => $counts['refuse_client'], 'url' => add_query_arg('vsc_reply', 'refuse', $dashboard)),
            array('label' => 'Ridicări programate', 'count' => $counts['ridicare_programata'], 'url' => add_query_arg('vsc_status', 'ridicare_programata', $admin_list)),
            array('label' => 'În transport', 'count' => $counts['in_transport'], 'url' => add_query_arg('vsc_status', 'in_transport', $admin_list)),
            array('label' => 'De verificat', 'count' => $counts['la_verificare'], 'url' => add_query_arg('vsc_status', 'la_verificare', $admin_list)),
            array('label' => 'Revizuiri în așteptare', 'count' => $counts['oferta_revizuita'], 'url' => add_query_arg('vsc_status', 'oferta_revizuita', $admin_list)),
            array('label' => 'De plătit', 'count' => $counts['verificare_confirmata'], 'url' => add_query_arg('vsc_status', 'verificare_confirmata', $admin_list)),
            array('label' => 'Plătite', 'count' => $counts['platita'], 'url' => add_query_arg('vsc_status', 'platita', $admin_list)),
            array('label' => 'Retururi în pregătire', 'count' => $counts['retur_pregatit'], 'url' => add_query_arg('vsc_status', 'retur_pregatit', $admin_list)),
            array('label' => 'Finalizate (vechi)', 'count' => $counts['finalizata'], 'url' => add_query_arg('vsc_status', 'finalizata', $admin_list)),
        );
        $meta = array(array('key' => '_vsc_offer_reply', 'value' => $filter === 'all'
            ? array('accept', 'refuse') : $filter, 'compare' => $filter === 'all' ? 'IN' : '='));
        $query = new WP_Query(array('post_type' => self::TYPE, 'post_status' => 'private',
            'posts_per_page' => 20, 'paged' => $paged, 'ignore_sticky_posts' => true,
            'meta_key' => '_vsc_offer_reply_at', 'orderby' => 'meta_value', 'order' => 'DESC',
            'meta_query' => $meta));
        $notice_labels = array('sent' => 'Predată serverului', 'pending' => 'În așteptare',
            'retry' => 'Reîncercare', 'failed' => 'Eșuată', 'schedule_failed' => 'Programare eșuată');
        echo '<div class="wrap vsc-admin-dashboard"><h1>Vinde Scula – Panou oferte</h1>';
        echo '<p>Urmărește solicitările și răspunsurile primite de la clienți. Datele se citesc din WordPress la încărcarea paginii.</p>';
        echo '<div class="vsc-admin-stats">';
        foreach ($cards as $card) {
            echo '<a class="vsc-admin-stat" href="' . esc_url($card['url']) . '">'
                . '<span>' . esc_html($card['label']) . '</span><strong>' . esc_html(number_format_i18n($card['count'])) . '</strong></a>';
        }
        echo '</div><h2>Răspunsuri recente ale clienților</h2>';
        echo '<nav class="vsc-admin-filters" aria-label="Filtru răspunsuri">';
        foreach (array('all' => 'Toate răspunsurile', 'accept' => 'Acceptate', 'refuse' => 'Refuzate') as $key => $label) {
            echo '<a class="button' . ($filter === $key ? ' button-primary' : '') . '" href="'
                . esc_url(add_query_arg('vsc_reply', $key, $dashboard)) . '"'
                . ($filter === $key ? ' aria-current="page"' : '') . '>' . esc_html($label) . '</a>';
        }
        echo '</nav><div class="vsc-admin-table-wrap"><table class="widefat fixed striped"><thead><tr>'
            . '<th>Solicitare</th><th>Produs</th><th>Decizia clientului</th><th>Ofertă</th>'
            . '<th>Stare actuală</th><th>Data răspunsului</th><th>Notificare admin</th><th>Acțiune</th></tr></thead><tbody>';
        if (!$query->have_posts()) {
            echo '<tr><td colspan="8">Nu există răspunsuri pentru acest filtru.</td></tr>';
        }
        foreach ($query->posts as $post) {
            $id = (int)$post->ID;
            $reply = (string)get_post_meta($id, '_vsc_offer_reply', true);
            $notice = (string)get_post_meta($id, '_vsc_offer_reply_notice', true);
            $product = trim((string)get_post_meta($id, '_vsc_marca', true) . ' ' . (string)get_post_meta($id, '_vsc_model', true));
            $price = (float)get_post_meta($id, '_vsc_offer_amount', true);
            echo '<tr><td><strong>' . esc_html(self::reference($id)) . '</strong></td>'
                . '<td>' . esc_html($product !== '' ? $product : 'Nespecificat') . '</td>'
                . '<td>' . esc_html($reply === 'accept' ? 'Acceptată' : 'Refuzată') . '</td>'
                . '<td>' . esc_html(number_format_i18n($price, 2)) . ' lei</td>'
                . '<td>' . self::admin_status_badge($id) . '</td>'
                . '<td>' . esc_html((string)get_post_meta($id, '_vsc_offer_reply_at', true)) . '</td>'
                . '<td>' . esc_html($notice_labels[$notice] ?? 'Necunoscută') . '</td>'
                . '<td><a href="' . esc_url(get_edit_post_link($id)) . '">Deschide solicitarea</a></td></tr>';
        }
        echo '</tbody></table></div>';
        $pages = paginate_links(array('base' => add_query_arg(array('vsc_reply' => $filter,
            'paged' => '%#%'), $dashboard), 'format' => '', 'total' => (int)$query->max_num_pages,
            'current' => $paged, 'type' => 'plain'));
        if ($pages) { echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post($pages) . '</div></div>'; }
        wp_reset_postdata();
        echo '<p class="description">Acceptat de serverul de e-mail nu înseamnă neapărat livrat în inbox. Notițele interne se adaugă în detaliile fiecărei solicitări.</p>';
        echo '</div>';
    }

    /** Retrimite doar mesajele care nu au fost deja acceptate; max. 250 cereri per clic. */
    public static function retry_failed_emails() {
        if (!current_user_can('manage_options')) { wp_die('Acces interzis.', 403); }
        check_admin_referer('vsc_retry_failed_emails');
        $ids = get_posts(array('post_type' => self::TYPE, 'post_status' => 'private',
            'fields' => 'ids', 'numberposts' => 250, 'orderby' => 'date', 'order' => 'ASC',
            'meta_query' => array('relation' => 'AND',
                array('key' => '_vsc_background_status',
                    'value' => array('failed', 'schedule_failed'), 'compare' => 'IN'),
                array('relation' => 'OR',
                    array('key' => '_vsc_mail_admin', 'compare' => 'NOT EXISTS'),
                    array('key' => '_vsc_mail_admin', 'value' => 'sent', 'compare' => '!='),
                    array('key' => '_vsc_mail_client', 'compare' => 'NOT EXISTS'),
                    array('key' => '_vsc_mail_client', 'value' => 'sent', 'compare' => '!='),
                ),
            )));
        $count = 0;
        foreach ($ids as $id) {
            $admin_sent = get_post_meta($id, '_vsc_mail_admin', true) === 'sent';
            $client_sent = get_post_meta($id, '_vsc_mail_client', true) === 'sent';
            if ($admin_sent && $client_sent) { continue; }
            // Nu resetăm niciodată steagurile 'sent' și nu retrimitem ofertele.
            update_post_meta($id, '_vsc_background_attempts', 0);
            update_post_meta($id, '_vsc_background_status', 'pending');
            update_post_meta($id, '_vsc_mail_next_run', time());
            self::email_queue_log($id, 'manual_retry', 'Reprogramare în bloc de către administrator.');
            $count++;
        }
        if ($count) { self::kick_email_queue(); }
        wp_safe_redirect(add_query_arg(array('post_type' => self::TYPE, 'page' => 'vsc-emailuri',
            'vsc_requeued' => $count), admin_url('edit.php')));
        exit;
    }

    private static function email_queue_count($states) {
        $query = new WP_Query(array('post_type' => self::TYPE, 'post_status' => 'private',
            'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false,
            'meta_query' => array(array('key' => '_vsc_background_status', 'value' => $states, 'compare' => 'IN'))));
        return (int)$query->found_posts;
    }

    public static function email_queue_page() {
        if (!current_user_can('manage_options')) { return; }
        $allowed = array('all','pending','retry','schedule_failed','processing','failed','complete');
        $filter = isset($_GET['vsc_state']) && is_scalar($_GET['vsc_state']) ? sanitize_key(wp_unslash($_GET['vsc_state'])) : 'all';
        if (!in_array($filter, $allowed, true)) { $filter = 'all'; }
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $meta = $filter === 'all'
            ? array(array('key' => '_vsc_background_status', 'compare' => 'EXISTS'))
            : array(array('key' => '_vsc_background_status', 'value' => $filter));
        $query = new WP_Query(array('post_type' => self::TYPE, 'post_status' => 'private',
            'posts_per_page' => 20, 'paged' => $paged, 'orderby' => 'date', 'order' => 'DESC',
            'meta_query' => $meta));
        $labels = array('pending'=>'În așteptare','retry'=>'Reîncercare programată',
            'schedule_failed'=>'Programare eșuată','processing'=>'În procesare',
            'failed'=>'Eșuat definitiv','complete'=>'Complet');
        echo '<div class="wrap"><h1>Vinde Scula – E-mailuri</h1>';
        echo '<p>Coada automată trimite confirmările și notificările administrative în loturi de cel mult 20 de solicitări. WP-Cron rulează la aproximativ 5 minute, în funcție de traficul site-ului. Maximum 3 încercări, cu pauze între ele.</p>';
        echo '<p><strong>Important:</strong> „Trimis” înseamnă acceptat de mecanismul de expediere, nu livrat în Inbox. Ofertele trimise manual nu se retrimit automat.</p>';
        echo '<p><strong>În așteptare:</strong> ' . esc_html(self::email_queue_count(array('pending', 'retry', 'processing', 'schedule_failed')))
            . ' &nbsp; <strong>Eșuate:</strong> ' . esc_html(self::email_queue_count(array('failed')))
            . ' &nbsp; <strong>Completate:</strong> ' . esc_html(self::email_queue_count(array('complete'))) . '</p>';
        if (isset($_GET['vsc_requeued'])) {
            echo '<div class="notice notice-success"><p>' . esc_html(absint($_GET['vsc_requeued'])) . ' solicitări au fost reprogramate. Mesajele deja trimise sunt omise.</p></div>';
        }
        echo '<form method="get" style="margin:16px 0">';
        echo '<input type="hidden" name="post_type" value="' . esc_attr(self::TYPE) . '">';
        echo '<input type="hidden" name="page" value="vsc-emailuri">';
        echo '<label for="vsc-state-filter">Afișează: </label> <select id="vsc-state-filter" name="vsc_state">';
        echo '<option value="all">Toate</option>';
        foreach ($labels as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($filter, $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select> <button class="button">Filtrează</button></form>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:12px 0">';
        echo '<input type="hidden" name="action" value="vsc_retry_failed_emails">';
        wp_nonce_field('vsc_retry_failed_emails');
        echo '<button type="submit" class="button button-secondary" onclick="return confirm(&quot;Reprogramezi doar notificările eșuate? Ofertele nu sunt afectate.&quot;)">Retrimite toate eșuate (max. 250 / clic)</button>';
        echo '</form>';
        echo '<table class="widefat striped" style="max-width:1150px"><thead><tr><th>Solicitare</th><th>Stare coadă</th><th>Administrator</th><th>Client</th><th>Încercări</th><th>Ultima încercare</th><th>Istoric</th></tr></thead><tbody>';
        if (!$query->have_posts()) { echo '<tr><td colspan="7">Nu există solicitări pentru acest filtru.</td></tr>'; }
        foreach ($query->posts as $post) {
            $id = (int)$post->ID;
            $state = (string)get_post_meta($id, '_vsc_background_status', true);
            $a = get_post_meta($id, '_vsc_mail_admin', true) === 'sent' ? 'Trimis' : 'Netrimis';
            $c = get_post_meta($id, '_vsc_mail_client', true) === 'sent' ? 'Trimis' : 'Netrimis';
            $url = get_edit_post_link($id);
            echo '<tr><td><a href="' . esc_url($url) . '">' . esc_html(self::reference($id)) . '</a></td>';
            echo '<td>' . esc_html(isset($labels[$state]) ? $labels[$state] : $state) . '</td>';
            echo '<td>' . esc_html($a) . '</td><td>' . esc_html($c) . '</td>';
            echo '<td>' . esc_html((int)get_post_meta($id, '_vsc_background_attempts', true)) . ' / ' . esc_html(self::EMAIL_MAX_ATTEMPTS) . '</td>';
            echo '<td>' . esc_html((string)get_post_meta($id, '_vsc_background_last_attempt', true)) . '</td>';
            $history = get_post_meta($id, '_vsc_email_history', true);
            echo '<td>';
            if (is_array($history) && $history) {
                echo '<details><summary>' . esc_html(count($history)) . ' evenimente</summary><ul style="min-width:190px">';
                foreach (array_reverse($history) as $item) {
                    if (!is_array($item)) { continue; }
                    echo '<li><small>' . esc_html(isset($item['time']) ? $item['time'] : '') . ' — '
                        . esc_html(isset($item['note']) ? $item['note'] : '') . '</small></li>';
                }
                echo '</ul></details>';
            } else { echo '—'; }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        $base = add_query_arg(array('post_type' => self::TYPE, 'page' => 'vsc-emailuri',
            'vsc_state' => $filter, 'paged' => '%#%'), admin_url('edit.php'));
        $pages = paginate_links(array('base' => $base, 'format' => '', 'total' => $query->max_num_pages,
            'current' => $paged, 'type' => 'plain'));
        if ($pages) { echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post($pages) . '</div></div>'; }
        wp_reset_postdata();
        echo '</div>';
    }

    public static function admin_menu() {
        add_submenu_page('edit.php?post_type=' . self::TYPE, 'Panou oferte Vinde Scula', 'Panou oferte', 'manage_options', 'vsc-panou-oferte', array(__CLASS__, 'admin_offers_dashboard'));
        add_submenu_page('edit.php?post_type=' . self::TYPE, 'Setări Vinde Scula', 'Setări', 'manage_options', 'vsc-setari', array(__CLASS__, 'settings_page'));
        add_submenu_page('edit.php?post_type=' . self::TYPE, 'E-mailuri Vinde Scula', 'E-mailuri', 'manage_options', 'vsc-emailuri', array(__CLASS__, 'email_queue_page'));
    }

    public static function settings() {
        // Adresa notificărilor este fixă în versiunea actuală; nu mai înregistrăm
        // opțiunea veche, pentru ca salvarea limitei să nu o golească accidental.
        register_setting('vsc_options', self::OPT_DAILY_LIMIT, array(
            'type' => 'integer',
            'sanitize_callback' => array(__CLASS__, 'sanitize_daily_limit'),
            'default' => 5,
        ));
        register_setting('vsc_options', self::OPT_HOURLY_IP_LIMIT, array(
            'type' => 'integer',
            'sanitize_callback' => array(__CLASS__, 'sanitize_hourly_ip_limit'),
            'default' => 3,
        ));
        register_setting('vsc_options', self::OPT_EMAIL_TRANSPORT, array(
            'type' => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_email_transport'),
            'default' => 'smtp',
        ));
    }

    public static function settings_page() {
        if (!current_user_can('manage_options')) { return; }
        ?>
        <div class="wrap"><h1>Vinde Scula – Setări</h1>
            <p>Shortcode pentru afișarea formularului: <code>[vinde_scula]</code></p>
            <form method="post" action="<?php echo esc_url(admin_url('options.php')); ?>">
                <?php settings_fields('vsc_options'); ?>
                <table class="form-table"><tbody>
                    <tr>
                        <th scope="row"><label for="vsc-max-daily">Limită cereri per client / zi</label></th>
                        <td>
                            <input type="number" id="vsc-max-daily"
                                   name="<?php echo esc_attr(self::OPT_DAILY_LIMIT); ?>"
                                   value="<?php echo esc_attr(self::daily_limit()); ?>"
                                   min="0" max="100" step="1" class="small-text">
                            <p class="description">Numărul maxim de solicitări trimise de același client într-o zi (ora site-ului). Implicit: 5. Valoarea 0 = fără limită zilnică.</p>
                            <p class="description">Se verifică după contul WordPress, adresa e-mail sau telefonul completat. Se numără și cererile retrase.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="vsc-max-hourly-ip">Limită cereri per IP / oră</label></th>
                        <td>
                            <input type="number" id="vsc-max-hourly-ip"
                                   name="<?php echo esc_attr(self::OPT_HOURLY_IP_LIMIT); ?>"
                                   value="<?php echo esc_attr(self::hourly_ip_limit()); ?>"
                                   min="0" max="100" step="1" class="small-text">
                            <p class="description">Protecție anti-spam pentru aceeași conexiune (adresă IP). Implicit: 3 cereri/oră. Valoarea 0 o dezactivează separat, fără a modifica limita per client/zi.</p>
                            <p class="description">Fiecare sculă se trimite într-o solicitare separată și se numără separat pentru limite și statistici.</p>
                            <p class="description">Mai mulți clienți pot folosi aceeași conexiune. Dezactivarea limitei pe IP reduce protecția împotriva trimiterilor abuzive.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Metodă de trimitere e-mailuri</th>
                        <td>
                            <fieldset>
                                <label><input type="radio" name="<?php echo esc_attr(self::OPT_EMAIL_TRANSPORT); ?>"
                                    value="smtp" <?php checked(self::email_transport(), 'smtp'); ?>>
                                    <strong>SMTP / FluentSMTP</strong> — prin <code>wp_mail()</code></label><br>
                                <label><input type="radio" name="<?php echo esc_attr(self::OPT_EMAIL_TRANSPORT); ?>"
                                    value="php_mail" <?php checked(self::email_transport(), 'php_mail'); ?>>
                                    <strong>PHP Mail (ca Marketing Lite)</strong> — <code>wp_mail()</code> cu hook temporar <code>phpmailer_init</code></label>
                            </fieldset>
                            <p class="description">Se aplică doar confirmărilor, notificărilor și ofertelor Vinde Scula. Alte pluginuri nu sunt afectate.</p>
                            <p class="description">În modul PHP Mail, expeditorul este oferte@sculebune.ro, iar răspunsurile merg la info@sculebune.ro. SMTP păstrează info@sculebune.ro. Dacă un plugin înlocuiește wp_mail() sau forțează ulterior expeditorul, rezultatul poate diferi. Livrarea în Inbox nu este garantată.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">E-mail pentru notificări</th>
                        <td><code>info@sculebune.ro</code>
                        <p class="description">Destinatar fix pentru solicitările noi. Solicitările sunt salvate și în WordPress.</p></td>
                    </tr>
                </tbody></table>
                <?php submit_button('Salvează setările'); ?>
            </form>
            <p><strong>Fotografii private:</strong> Fotografiile noi se salvează în afara directorului public al site-ului și sunt afișate numai administratorului autorizat sau proprietarului autentificat al cererii. Fotografiile vechi din Biblioteca Media rămân la locația lor și pot avea URL-uri publice.</p>
            <?php if (!self::private_storage_root(true)) : ?>
                <div class="notice notice-error inline"><p><strong>Stocarea privată nu poate fi inițializată.</strong> Verifică permisiunile folderului părinte din hosting. Alternativ, definește <code>VSC_PRIVATE_UPLOAD_DIR</code> în <code>wp-config.php</code>, cu o cale absolută, inscriptibilă, în afara folderului public. Formularul va refuza încărcările până când fotografiile pot fi stocate privat.</p></div>
            <?php else : ?>
                <p><strong>Stocare privată:</strong> <span style="color:#137333">activă</span>. Fotografiile noi nu intră în Biblioteca Media.</p>
            <?php endif; ?>
            <p><strong>Compresie fotografii noi:</strong> WebP automat, calitate 76%, maximum 1800 px pe latura lungă. Fotografiile deja salvate nu sunt convertite sau șterse.</p>
            <?php
            if (!function_exists('wp_image_editor_supports')) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
            }
            ?>
            <p><strong>Suport WebP pe server:</strong>
                <?php if (wp_image_editor_supports(array('mime_type' => 'image/webp'))) : ?>
                    <span style="color:#137333">disponibil</span>.
                <?php else : ?>
                    <span style="color:#b32d2e">indisponibil</span>. Activează WebP în GD/Imagick la hosting; altfel încărcarea fotografiilor noi va fi refuzată.
                <?php endif; ?>
            </p>
        </div>
        <?php
    }
}
require_once __DIR__ . '/includes/class-vsc-statistics.php';
VSC_Categorii_Plugin::init();
VSC_Statistics::init();
register_activation_hook(__FILE__, array('VSC_Categorii_Plugin', 'activate'));
register_deactivation_hook(__FILE__, array('VSC_Categorii_Plugin', 'deactivate'));
