# Vinde Scula 1.4.1

- Formularul trimite o singură sculă. Pașii existenți și limita de 1–5
  fotografii pentru fiecare solicitare sunt păstrate.
- O altă sculă se trimite printr-un formular separat, după încheierea
  solicitării curente. Oferta, datele bancare, ridicarea, transportul,
  verificarea, returul și plata se gestionează individual.
- Sunt eliminate componentele active pentru adăugarea mai multor scule
  înaintea trimiterii și pentru ridicarea comună.
- Statisticile administrative sunt păstrate: solicitări primite, oferte,
  acceptări, achiziții, rate, durata până la prima ofertă și distribuția
  pe categorii. Filtrarea folosește data creării și fusul orar al site-ului.
- Sunt păstrate izolarea fotografiilor temporare între pagini, restaurarea
  locală a formularului timp de 12 ore și protecția interacțiunilor în curs.
- Actualizarea păstrează înregistrările și metadatele istorice existente.

## Istoric

Arhiva versiunii 1.4.0 este păstrată separat, ca versiune anterioară.
Versiunea 1.4.1 folosește solicitări individuale pentru fiecare sculă.

Baza istorică este 1.3.89. Pregătirea acelei baze este documentată în
[CLEANUP.md](CLEANUP.md); istoricul original se află în `docs/HISTORY.txt`.
