=== 00. Vinde Scula – Formular cu Categorii ===
Stable tag: 1.4.2
Requires at least: 6.0
Requires PHP: 7.4

Solicitări de vânzare pentru cinci categorii de scule, cu formular individual,
oferte, ridicare și plată pentru fiecare solicitare și statistici administrative.

== Utilizare ==

Folosește shortcode-ul [vinde_scula]. Parametrul URL
categoria=scule-electrice poate preselecta o categorie. Vizitatorii pot alege
categoria și apoi se autentifică sau își creează cont pentru a continua.

WooCommerce este necesar pentru fluxul complet Contul meu → Vânzări.
Elementor, tema Bigxon și integrarea siglelor sunt opționale.

Marca se alege din lista de 12 mărci, fără câmp de căutare. După alegere,
butonul afișează sigla disponibilă și numele mărcii. Sunt reutilizate
imaginile deja existente în SculeBune Marketing Lite sau în taxonomiile
WooCommerce/Bigxon. Dacă nu există o siglă, rămâne afișat numele mărcii;
pluginul de marketing nu trebuie activat și nu se adaugă o sursă externă.

Anul fabricației este opțional și apare după model, la detaliile sculei.
Lista începe cu anul curent al site-ului și coboară până la 2020 inclusiv
(2026–2020 în 2026), urmată de „Înainte de 2020” și
„Nu știu / nu este vizibil”. Anii salvați în solicitările vechi se păstrează.

Pentru sculele cu acumulator, platforma rămâne opțională și lista afișează
numai platformele mărcii alese, alături de opțiunile generale. „Altă platformă”
permite introducerea denumirii, inclusiv pentru mărcile fără platforme
predefinite. La schimbarea mărcii, alege o platformă corespunzătoare;
platforma nu este salvată pentru celelalte categorii.

1. Alege categoria și completează pașii formularului pentru o singură sculă.
2. Adaugă între 1 și 5 fotografii valide și confirmă datele cerute.
3. Trimite solicitarea pentru evaluare. Formularul trimis creează o singură
   solicitare pentru scula completată.
4. Consultă și acceptă sau refuză oferta din Contul meu → Vânzări.
5. Pentru oferta acceptată, completează datele bancare și adresa de ridicare
   ale acelei solicitări. Oferta, ridicarea, verificarea și plata sunt individuale.

Pentru o altă sculă, completează și trimite un formular separat. După
confirmarea unei trimiteri poți începe o nouă solicitare.

Formularul în lucru și fotografiile lui se pot restaura local timp de
12 ore, dacă browserul permite stocarea sesiunii și IndexedDB. Fiecare pagină
folosește o copie proprie a fotografiilor temporare. Trimiterea reușită
șterge ciorna locală a formularului respectiv.

== Administrarea vânzărilor ==

Fiecare sculă are solicitarea, oferta, decizia clientului, datele de ridicare,
curierul, AWB-ul, verificarea, returul și plata proprie. Actualizarea unei
solicitări se aplică acelei scule. Pluginul nu execută transferuri bancare
și nu generează automat AWB-uri.

== Statistici ==

Solicitări → Statistici este disponibilă administratorilor cu permisiunea
manage_options. Perioada selectează inclusiv datele de creare ale
solicitărilor, în fusul orar al site-ului; rezultatele acestora sunt cele
înregistrate până în prezent, indiferent de data răspunsului sau a plății.
Sunt incluse solicitările private, câte una pentru fiecare sculă.

Sunt afișate sculele primite, ofertele trimise, acceptările explicite și
sculele achiziționate, plus rezultate pe categorii. Rata de acceptare
raportează acceptările cu ofertă la sculele cu ofertă; rata de achiziție
raportează sculele plătite la cele primite. Durata medie până la prima
ofertă folosește numai date valide, ulterioare sau egale creării.
„—” indică lipsa unei baze de calcul.

== Cerințe pentru fotografii și date private ==

- WordPress minimum 6.0, PHP minimum 7.4 și WooCommerce pentru contul clientului.
- GD sau Imagick cu suport WebP; maximum 5 fotografii per sculă, fiecare de
  maximum 5 MiB. upload_max_filesize trebuie să fie minimum 5M și
  post_max_size peste 25M; găzduirea trebuie să permită procesarea imaginilor.
- Director privat, inscriptibil, în afara rădăcinii publice; poate fi stabilit
  prin constanta VSC_PRIVATE_UPLOAD_DIR.
- OpenSSL cu AES-256-GCM pentru date bancare și datele de ridicare.
- Tabelele WordPress posts, postmeta și options trebuie să folosească InnoDB
  pentru operațiunile tranzacționale.
- WP-Cron funcțional pentru notificări.
- Fotografiile istorice păstrate în Media Library nu devin automat private.

Versiunile minime sunt cerințe declarate; mediul local de verificare folosește
WordPress 7.1.3, PHP 8.3.36 și WooCommerce 11.2.1.

== Actualizare și copii de siguranță ==

Înainte de actualizare, salvează baza de date și directorul fotografiilor
private. Păstrează configurația WordPress, inclusiv cheile și salturile:
schimbarea acestora poate împiedica decriptarea datelor deja salvate. O copie
doar a directorului public uploads nu include fotografiile private noi.

Actualizarea păstrează înregistrările și metadatele istorice existente.

== Notificări și operațiuni ==

Notificările folosesc wp_mail și o coadă WP-Cron. Configurarea SMTP aparține
instalării WordPress. Administratorul destinat notificărilor este info@sculebune.ro.

Istoricul original este păstrat în docs/HISTORY.txt; schimbările funcționale
din această versiune sunt descrise în CHANGELOG.md. CLEANUP.md documentează
pregătirea bazei istorice și limitele curățării surselor.
