# Vinde Scula 1.4.2

- Alegerea mărcii folosește lista celor 12 mărci, fără căutare. Butonul
  afișează sigla disponibilă și numele mărcii selectate, cu rezervă textuală
  când imaginea lipsește. Siglele existente din pluginul de marketing sau
  taxonomiile WooCommerce/Bigxon sunt reutilizate.
- Anul fabricației apare după model, în detaliile sculei. Câmpul opțional
  oferă anul curent până la 2020 inclusiv, „Înainte de 2020” și
  „Nu știu / nu este vizibil”. Valorile istorice rămân nemodificate.
- Platformele pentru sculele cu acumulator sunt filtrate după marca aleasă.
  Opțiunile generale și introducerea altei platforme rămân disponibile.
  Serverul verifică potrivirea platformei predefinite cu marca și elimină
  platforma trimisă pentru celelalte categorii.
- Sunt păstrate formularul pentru o singură sculă, fluxul individual al
  vânzării și statisticile administrative.

## Versiunea 1.4.1

- Formularul trimite o singură sculă. Pașii existenți și limita de 1–5
  fotografii pentru fiecare solicitare sunt păstrate.
- O altă sculă se trimite printr-un formular separat, după încheierea
  solicitării curente. Oferta, datele bancare, ridicarea, transportul,
  verificarea, returul și plata se gestionează individual.
- Sunt eliminate componentele active pentru adăugarea mai multor scule
  înaintea trimiterii și pentru ridicarea comună.
- Statisticile administrative sunt păstrate: solicitări primite, oferte,
  acceptări, achiziții, rate, durata până la prima ofertă și distribuția
  pe categorii. Filtrarea folosește data creării și fusul orar al site-ului.
- Sunt păstrate izolarea fotografiilor temporare între pagini, restaurarea
  locală a formularului timp de 12 ore și protecția interacțiunilor în curs.
- Actualizarea păstrează înregistrările și metadatele istorice existente.

## Istoric

Arhivele versiunilor anterioare sunt păstrate separat.
Începând cu 1.4.1, solicitările sunt individuale pentru fiecare sculă.

Baza istorică este 1.3.89. Pregătirea acelei baze este documentată în
[CLEANUP.md](CLEANUP.md); istoricul original se află în `docs/HISTORY.txt`.
