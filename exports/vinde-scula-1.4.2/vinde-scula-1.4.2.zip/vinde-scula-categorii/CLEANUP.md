# Curățarea surselor și baza istorică

Versiunea 1.4.2 păstrează formularul pentru o singură sculă și statisticile
administrative. Începând cu 1.4.1, componentele active pentru trimiterea mai
multor scule și ridicarea comună sunt eliminate din surse. Fiecare ofertă, ridicare și plată
aparține solicitării individuale.

În 1.4.2 sunt simplificate alegerea mărcii, anul fabricației și platforma
acumulatorului. Restrângerea listei de ani pentru formularele noi nu
rescrie metadatele solicitărilor istorice. Siglele existente sunt reutilizate
din pluginul de marketing sau taxonomiile WooCommerce/Bigxon, cu numele
mărcii afișat când imaginea lipsește; nu sunt adăugate imagini externe.

Această curățare nu șterge înregistrările sau metadatele istorice din baza
de date. Înainte de actualizare, salvează baza de date, fotografiile private
și configurația WordPress cu cheile și salturile necesare decriptării.
Cerințele de director privat, AES-256-GCM și InnoDB sunt descrise în
[README.txt](README.txt).

## Pregătirea bazei 1.3.89

- Indentare consecventă a corpului `try` din `process_background`.
- README al bazei actualizat pentru versiunea și shortcode-ul de atunci.
- Istoricul original păstrat integral în `docs/HISTORY.txt`.
- În acea etapă nu s-au schimbat versiunea, logica, activele sau structura datelor.

Aceste patru puncte descriu exclusiv pregătirea istorică a bazei 1.3.89.
Schimbările funcționale ale versiunii curente sunt în
[CHANGELOG.md](CHANGELOG.md).
