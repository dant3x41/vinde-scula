# Curățare pentru Vinde Scula 1.3.89

- Indentare consecventă a corpului `try` din `process_background`.
- README actualizat pentru versiunea și shortcode-ul curent.
- Istoricul original păstrat integral în `docs/HISTORY.txt`.
- Fără schimbarea versiunii, a logicii, a activelor sau a structurii datelor.

Această variantă păstrează comportamentul și problemele versiunii 1.3.89.
Raportul de audit este livrat separat. Arhiva originală și versiunea activă
în mediul de dezvoltare sunt păstrate.
