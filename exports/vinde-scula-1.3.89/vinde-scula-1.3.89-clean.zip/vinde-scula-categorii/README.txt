=== 00. Vinde Scula – Formular cu Categorii ===
Stable tag: 1.3.89
Requires at least: 6.0
Requires PHP: 7.4

Plugin pentru solicitări de vânzare, evaluare și finalizare, cu cinci categorii.
Versiunile minime de mai sus sunt cele declarate de plugin. Mediul verificat:
WordPress 7.1.3, PHP 8.3.36 și WooCommerce 11.2.1.

== Utilizare ==

Folosește shortcode-ul [vinde_scula]. Trimiterea solicitării cere autentificare,
confirmările formularului și cel puțin o fotografie validă. Parametrul URL
categoria=scule-electrice poate preselecta o categorie.

WooCommerce este necesar pentru fluxul complet Contul meu → Vânzări.
Elementor, tema Bigxon și integrarea siglelor sunt opționale. În versiunea
1.3.89 există o problemă raportată pentru shortcode-ul independent afișat
vizitatorilor fără categorie preselectată și fără carduri de categorii.

== Cerințe pentru fotografii și date private ==

- GD sau Imagick cu suport WebP; maximum 5 fotografii, fiecare de maximum 5 MiB.
- upload_max_filesize de minimum 5M și post_max_size peste 25M.
- Director privat, inscriptibil, în afara rădăcinii publice; poate fi stabilit
  prin constanta VSC_PRIVATE_UPLOAD_DIR.
- OpenSSL cu AES-256-GCM pentru date bancare și datele de ridicare.
- Păstrează salturile WordPress: schimbarea lor afectează datele deja criptate.
- Fotografiile istorice păstrate în Media Library nu devin automat private.

== Notificări și operațiuni ==

Notificările folosesc wp_mail și o coadă WP-Cron. Configurarea SMTP aparține
instalării WordPress. Administratorul destinat notificărilor este info@sculebune.ro.
Pluginul nu execută transferuri bancare și nu generează automat AWB-uri.

== Această arhivă clean ==

Codul PHP are numai o corecție de indentare în process_background.
Fișierele JavaScript, CSS, SVG și WebP sunt identice cu arhiva originală.
Istoricul original este păstrat integral în docs/HISTORY.txt.
Problemele identificate în audit necesită corecții funcționale separate;
această arhivă nu le remediază. Vezi CLEANUP.md pentru lista modificărilor.
