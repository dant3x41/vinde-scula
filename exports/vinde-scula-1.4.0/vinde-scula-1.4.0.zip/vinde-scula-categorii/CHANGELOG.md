# Vinde Scula 1.4.0

- Expediții cu 1–3 scule, inclusiv din categorii diferite. Fiecare sculă are
  formularul și cele 1–5 fotografii proprii. Sculele se pot elimina înainte
  de trimiterea întregii expediții.
- Ciorne private pe server, cu recuperarea listei în sesiunea de browser,
  expirare după 48 de ore și maximum 3 expediții netrimise per cont.
- Trimitere comună cu verificări pe server și o singură unitate din limita
  de trimiteri pentru întreaga expediție. Reîncercările sunt tratate idempotent.
- Oferte și răspunsuri independente pentru fiecare sculă. Ridicarea comună
  devine disponibilă după soluționarea tuturor ofertelor și include exclusiv
  sculele acceptate; sculele respinse sau retrase sunt excluse.
- Un singur formular de finalizare pentru adresa de ridicare și contul
  bancar comun. Fiecare solicitare acceptată primește date criptate separat,
  asociate propriului identificator. Salvarea este tranzacțională.
- Curier, AWB și sincronizarea etapelor de transport până la primirea pentru
  verificare pentru sculele din ridicarea comună. Returul, revizuirea și
  plata rămân independente pentru fiecare sculă.
- Pagină administrativă de statistici cu interval inclusiv după data creării
  solicitărilor în fusul orar al site-ului: scule, expediții, oferte,
  acceptări, achiziții, rate de conversie, durata până la prima ofertă și
  distribuția pe categorii. Ciornele și coșul nu sunt numărate.
- Fotografii temporare izolate între pagini și flux de alegere a categoriei
  pentru vizitatori inclusiv pe paginile fără carduri externe de categorii.
  Ciorna locală a formularului și fotografiilor are o durată de 12 ore,
  separată de durata ciornei de expediție salvate pe server.

## Baza istorică

Versiunea pornește din 1.3.89. Pregătirea fără schimbări funcționale a acelei
baze este documentată în [CLEANUP.md](CLEANUP.md); istoricul original se află
în `docs/HISTORY.txt`.
