<?php
/** Private collections of tools submitted and collected together. */
if (!defined('ABSPATH')) { exit; }

final class VSC_Shipments {
    const TYPE = 'vsc_expeditie';
    const MAX_ITEMS = 3;
    const MAX_DRAFTS = 3;
    const DRAFT_TTL = 172800;
    private static $locks = array();

    public static function init() {
        add_action('init', array(__CLASS__, 'register_type'));
        add_action('init', array(__CLASS__, 'ensure_cleanup'), 35);
        add_action('vsc_shipments_cleanup', array(__CLASS__, 'cleanup_expired'));
        add_action('wp_ajax_vsc_shipment', array(__CLASS__, 'ajax'));
        add_action('wp_ajax_nopriv_vsc_shipment', array(__CLASS__, 'guest'));
        register_shutdown_function(array(__CLASS__, 'release_all_locks'));
    }

    public static function register_type() {
        register_post_type(self::TYPE, array(
            'labels' => array('name' => 'Expediții Vinde Scula', 'singular_name' => 'Expediție'),
            'public' => false, 'publicly_queryable' => false, 'exclude_from_search' => true,
            'show_ui' => false, 'show_in_rest' => false, 'supports' => array('title'),
            'capability_type' => 'post', 'map_meta_cap' => true,
        ));
    }

    public static function ensure_cleanup() {
        if (!wp_next_scheduled('vsc_shipments_cleanup')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'vsc_shipments_cleanup');
        }
    }

    private static function error($message, $status = 409) {
        return new WP_Error('vsc_shipment', $message, array('status' => $status));
    }

    private static function uuid($value) {
        return is_string($value) && preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $value)
            ? strtolower($value) : '';
    }

    private static function group($id) {
        $post = get_post(absint($id));
        return $post && $post->post_type === self::TYPE && $post->post_status === 'private' ? $post : null;
    }

    private static function owned_group($id) {
        $group = self::group($id);
        if (!$group) { return self::error('Expediția nu mai este disponibilă.', 404); }
        if (!is_user_logged_in() || (int)$group->post_author !== get_current_user_id()) {
            return self::error('Expediția nu aparține contului tău.', 403);
        }
        return $group;
    }

    private static function state($id) {
        $state = (string)get_post_meta($id, '_vsc_shipment_state', true);
        return in_array($state, array('draft', 'submitted', 'pickup_ready'), true) ? $state : '';
    }

    private static function item_ids($group_id) {
        $group = self::group($group_id);
        if (!$group) { return array(); }
        $ids = get_posts(array(
            'post_type' => 'vsc_solicitare', 'post_status' => array('draft', 'private'),
            'author' => (int)$group->post_author, 'numberposts' => -1, 'fields' => 'ids',
            'meta_key' => '_vsc_shipment_id', 'meta_value' => (string)$group_id,
            'orderby' => 'ID', 'order' => 'ASC', 'suppress_filters' => true,
        ));
        return array_values(array_map('intval', $ids));
    }

    private static function item_state($id) {
        $state = (string)get_post_meta($id, '_vsc_status', true);
        return in_array($state, array('', 'primită', 'primita'), true) ? 'primita' : $state;
    }

    private static function selected_ids($group_id) {
        $value = get_post_meta($group_id, '_vsc_shipment_selected_ids', true);
        if (!is_array($value)) { return array(); }
        return array_values(array_unique(array_filter(array_map('absint', $value))));
    }

    /** Discard objects read before acquiring the lease, including persistent-cache entries. */
    private static function refresh_group($group_id) {
        clean_post_cache(absint($group_id));
        wp_cache_delete(absint($group_id), 'post_meta');
        foreach (self::item_ids($group_id) as $id) {
            clean_post_cache($id);
            wp_cache_delete($id, 'post_meta');
        }
    }

    public static function group_id($item_id) {
        $item = get_post(absint($item_id));
        if (!$item || $item->post_type !== 'vsc_solicitare') { return 0; }
        $id = absint(get_post_meta($item->ID, '_vsc_shipment_id', true));
        $group = $id ? self::group($id) : null;
        return $group && (int)$group->post_author === (int)$item->post_author ? $id : 0;
    }

    public static function describe($item_id) {
        $group_id = self::group_id($item_id);
        return $group_id ? self::snapshot($group_id) : null;
    }

    public static function snapshot($group_id) {
        $group = self::group($group_id);
        $staff = $group && (current_user_can('manage_options') ||
            (current_user_can('edit_others_posts') && current_user_can('read_private_posts') && current_user_can('edit_post', $group->ID)));
        if (!$group || !is_user_logged_in() ||
            ((int)$group->post_author !== get_current_user_id() && !$staff)) {
            return self::error('Expediția nu este disponibilă.', 403);
        }
        $items = array();
        foreach (self::item_ids($group->ID) as $id) {
            $post = get_post($id);
            $name = trim((string)get_post_meta($id, '_vsc_marca', true) . ' ' . (string)get_post_meta($id, '_vsc_model', true));
            $photos = get_post_meta($id, '_vsc_private_fotografii', true);
            $items[] = array('id' => $id, 'reference' => '#' . $id,
                'name' => $name !== '' ? $name : get_the_title($id),
                'photos' => is_array($photos) ? count($photos) : 0,
                'status' => $post->post_status === 'draft' ? 'draft' : self::item_state($id));
        }
        return array('id' => (int)$group->ID, 'reference' => 'EXP-' . $group->ID,
            'state' => self::state($group->ID), 'max_items' => self::MAX_ITEMS, 'items' => $items,
            'expires_at' => (int)get_post_meta($group->ID, '_vsc_shipment_expires', true),
            'selected_ids' => self::selected_ids($group->ID));
    }

    /** Lease owner is included in compare-and-delete, so an old owner cannot release a new lease. */
    public static function acquire_lock($group_id) {
        global $wpdb;
        $name = 'vsc_shipment_lock_' . ((int)$group_id < 0 ? 'item_' : '') . absint($group_id);
        $token = wp_json_encode(array('owner' => wp_generate_uuid4(), 'expires' => time() + 5 * MINUTE_IN_SECONDS));
        for ($attempt = 0; $attempt < 2; ++$attempt) {
            $inserted = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", $name, $token));
            if ($inserted === 1) {
                $lock = array('name' => $name, 'value' => $token, 'group_id' => absint($group_id));
                self::$locks[$name] = $lock;
                return $lock;
            }
            $old = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", $name));
            $lease = is_string($old) ? json_decode($old, true) : null;
            if (!is_array($lease) || empty($lease['expires']) || (int)$lease['expires'] >= time()) { break; }
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $name, $old));
        }
        return self::error('O altă operație asupra expediției este în curs. Încearcă din nou.');
    }

    public static function release_lock($lock) {
        if (!is_array($lock) || empty($lock['name']) || !isset($lock['value']) ||
            !preg_match('/^vsc_shipment_lock_(?:item_)?[0-9]+$/D', $lock['name'])) { return; }
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $lock['name'], $lock['value']));
        wp_cache_delete($lock['name'], 'options');
        if (isset(self::$locks[$lock['name']]) && self::$locks[$lock['name']]['value'] === $lock['value']) {
            unset(self::$locks[$lock['name']]);
        }
    }

    public static function release_all_locks() {
        foreach (self::$locks as $lock) { self::release_lock($lock); }
    }

    public static function create_group($client_token) {
        if (!is_user_logged_in()) { return self::error('Autentifică-te pentru a crea o expediție.', 401); }
        $token = self::uuid($client_token);
        if ($token === '') { return self::error('Identificatorul expediției nu este valid.', 400); }
        $user_id = get_current_user_id();
        // Serialize creation per customer as well as per group: concurrent tabs cannot exceed the draft cap.
        $lock = self::acquire_lock(1000000000 + $user_id);
        if (is_wp_error($lock)) { return $lock; }
        try {
            self::cleanup_expired($user_id);
            $existing = get_posts(array('post_type' => self::TYPE, 'post_status' => 'private', 'author' => $user_id,
                'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_vsc_shipment_client_token', 'meta_value' => $token));
            if ($existing) { return self::snapshot((int)$existing[0]); }
            $drafts = get_posts(array('post_type' => self::TYPE, 'post_status' => 'private', 'author' => $user_id,
                'numberposts' => self::MAX_DRAFTS, 'fields' => 'ids', 'meta_key' => '_vsc_shipment_state', 'meta_value' => 'draft'));
            if (count($drafts) >= self::MAX_DRAFTS) { return self::error('Ai deja trei expediții netrimise. Continuă una dintre ele.'); }
            $id = wp_insert_post(array('post_type' => self::TYPE, 'post_status' => 'private', 'post_author' => $user_id,
                'post_title' => 'Expediție scule', 'meta_input' => array('_vsc_shipment_state' => 'draft',
                    '_vsc_shipment_client_token' => $token, '_vsc_shipment_expires' => time() + self::DRAFT_TTL)), true);
            if (is_wp_error($id) || !$id) { return self::error('Expediția nu a putut fi creată.', 500); }
            return self::snapshot($id);
        } finally { self::release_lock($lock); }
    }

    public static function begin_item($group_id, $token) {
        $group = self::owned_group($group_id);
        if (is_wp_error($group)) { return $group; }
        $token = self::uuid($token);
        if ($token === '') { return self::error('Identificatorul sculei nu este valid.', 400); }
        $lock = self::acquire_lock($group->ID);
        if (is_wp_error($lock)) { return $lock; }
        self::refresh_group($group->ID);
        $fresh = self::owned_group($group->ID);
        if (is_wp_error($fresh)) { self::release_lock($lock); return $fresh; }
        $group = $fresh;
        foreach (self::item_ids($group->ID) as $id) {
            if ((string)get_post_meta($id, '_vsc_shipment_item_token', true) === $token) {
                return array('group_id' => (int)$group->ID, 'token' => $token, 'lock' => $lock, 'prior_item_id' => $id);
            }
        }
        if (self::state($group->ID) !== 'draft' || (int)get_post_meta($group->ID, '_vsc_shipment_expires', true) < time()) {
            self::release_lock($lock);
            return self::error('Expediția a fost trimisă sau a expirat. Creează una nouă.', 410);
        }
        if (count(self::item_ids($group->ID)) >= self::MAX_ITEMS) {
            self::release_lock($lock);
            return self::error('Poți adăuga maximum trei scule într-o expediție.', 409);
        }
        return array('group_id' => (int)$group->ID, 'token' => $token, 'lock' => $lock, 'prior_item_id' => 0);
    }

    public static function release_item($context) {
        if (is_array($context) && isset($context['lock'])) { self::release_lock($context['lock']); }
    }

    public static function complete_item($context, $post_id) {
        if (!is_array($context) || empty($context['group_id']) || empty($context['token']) || empty($context['lock'])) {
            return self::error('Contextul sculei nu este valid.', 400);
        }
        try {
            self::refresh_group($context['group_id']);
            clean_post_cache(absint($post_id));
            if (!empty($context['prior_item_id'])) { return self::snapshot($context['group_id']); }
            $group = self::owned_group($context['group_id']);
            $post = get_post(absint($post_id));
            if (is_wp_error($group) || !$post || $post->post_type !== 'vsc_solicitare' || $post->post_status !== 'draft' ||
                (int)$post->post_author !== get_current_user_id() || self::state($group->ID) !== 'draft') {
                return self::error('Scula nu poate fi adăugată acestei expediții.', 409);
            }
            $prior_group = absint(get_post_meta($post->ID, '_vsc_shipment_id', true));
            if ($prior_group && $prior_group !== (int)$group->ID) { return self::error('Scula este deja asociată altei expediții.', 409); }
            $members = self::item_ids($group->ID);
            if (count($members) > self::MAX_ITEMS ||
                (!in_array((int)$post->ID, $members, true) && count($members) >= self::MAX_ITEMS)) {
                return self::error('Poți adăuga maximum trei scule într-o expediție.', 409);
            }
            update_post_meta($post->ID, '_vsc_shipment_id', (int)$group->ID);
            update_post_meta($post->ID, '_vsc_shipment_item_token', $context['token']);
            return self::snapshot($group->ID);
        } finally { self::release_item($context); }
    }

    public static function remove_item($group_id, $item_id) {
        $group = self::owned_group($group_id);
        if (is_wp_error($group)) { return $group; }
        $lock = self::acquire_lock($group->ID);
        if (is_wp_error($lock)) { return $lock; }
        try {
            self::refresh_group($group->ID);
            $fresh = self::owned_group($group->ID);
            if (is_wp_error($fresh)) { return $fresh; }
            $group = $fresh;
            $post = get_post(absint($item_id));
            if (self::state($group->ID) !== 'draft' || !$post || $post->post_status !== 'draft' ||
                !in_array((int)$post->ID, self::item_ids($group->ID), true)) {
                return self::error('Doar sculele unei expediții netrimise pot fi eliminate.', 409);
            }
            if (!wp_delete_post($post->ID, true)) { return self::error('Scula nu a putut fi eliminată.', 500); }
            return self::snapshot($group->ID);
        } finally { self::release_lock($lock); }
    }

    public static function finalize_group($group_id) {
        $group = self::owned_group($group_id);
        if (is_wp_error($group)) { return $group; }
        $lock = self::acquire_lock($group->ID);
        if (is_wp_error($lock)) { return $lock; }
        $quota = null;
        $ids = array();
        $transaction = false;
        global $wpdb;
        try {
            self::refresh_group($group->ID);
            $fresh = self::owned_group($group->ID);
            if (is_wp_error($fresh)) { return $fresh; }
            $group = $fresh;
            if (in_array(self::state($group->ID), array('submitted', 'pickup_ready'), true)) { return self::snapshot($group->ID); }
            if (self::state($group->ID) !== 'draft' || (int)get_post_meta($group->ID, '_vsc_shipment_expires', true) < time()) {
                return self::error('Expediția a expirat. Creează una nouă.', 410);
            }
            $ids = self::item_ids($group->ID);
            if (!$ids || count($ids) > self::MAX_ITEMS) { return self::error('Adaugă între una și trei scule înainte de trimitere.', 409); }
            foreach ($ids as $id) {
                $item = get_post($id);
                $photos = get_post_meta($id, '_vsc_private_fotografii', true);
                if ($item->post_status !== 'draft' || (int)$item->post_author !== get_current_user_id() ||
                    !is_array($photos) || !$photos || count($photos) > 5) {
                    return self::error('Una dintre scule nu este completă. Verifică fotografiile și reîncearcă.', 400);
                }
            }
            if (!is_callable(array('VSC_Categorii_Plugin', 'submission_limits')) ||
                !is_callable(array('VSC_Categorii_Plugin', 'consume_submission_quota')) ||
                !is_callable(array('VSC_Categorii_Plugin', 'queue_submission'))) {
                return self::error('Trimiterea expedițiilor nu este disponibilă.', 503);
            }
            $quota = VSC_Categorii_Plugin::submission_limits();
            if (is_wp_error($quota)) { return $quota; }
            if (!VSC_Categorii_Plugin::transaction_ready() || $wpdb->query('START TRANSACTION') === false) {
                return self::error('Serverul nu permite trimiterea sigură a expediției. Contactează administratorul.', 503);
            }
            $transaction = true;
            $now = current_time('mysql'); $now_gmt = current_time('mysql', true);
            foreach ($ids as $id) {
                $updated = wp_update_post(array('ID' => $id, 'post_status' => 'private', 'post_date' => $now, 'post_date_gmt' => $now_gmt), true);
                if (is_wp_error($updated) || !$updated ||
                    (get_post_meta($id, '_vsc_status', true) !== 'primita' && update_post_meta($id, '_vsc_status', 'primita') === false)) {
                    throw new RuntimeException('O sculă nu a putut fi trimisă.');
                }
            }
            $updated = wp_update_post(array('ID' => $group->ID, 'post_date' => $now, 'post_date_gmt' => $now_gmt), true);
            if (is_wp_error($updated) || !$updated || update_post_meta($group->ID, '_vsc_shipment_state', 'submitted') === false ||
                !VSC_Categorii_Plugin::consume_submission_quota($quota)) {
                throw new RuntimeException('Expediția nu a putut fi trimisă.');
            }
            update_post_meta($group->ID, '_vsc_shipment_submitted_at', $now);
            if ($wpdb->query('COMMIT') === false) { throw new RuntimeException('Trimiterea nu a putut fi confirmată.'); }
            $transaction = false;
            foreach ($ids as $id) { VSC_Categorii_Plugin::queue_submission($id); }
            return self::snapshot($group->ID);
        } catch (Throwable $error) {
            if ($transaction) { $wpdb->query('ROLLBACK'); $transaction = false; }
            foreach (array_merge($ids, array((int)$group->ID)) as $id) { clean_post_cache($id); wp_cache_delete($id, 'post_meta'); }
            return self::error('Expediția nu a putut fi trimisă. Datele au fost păstrate pentru reîncercare.', 500);
        } finally {
            if ($transaction) { $wpdb->query('ROLLBACK'); }
            if (is_array($quota) && is_callable(array('VSC_Categorii_Plugin', 'release_submission_quota'))) {
                VSC_Categorii_Plugin::release_submission_quota($quota);
            }
            self::release_lock($lock);
        }
    }

    public static function checkout_targets($anchor_id) {
        $anchor = get_post(absint($anchor_id));
        if (!$anchor || $anchor->post_type !== 'vsc_solicitare' || $anchor->post_status !== 'private' ||
            !is_user_logged_in() || (int)$anchor->post_author !== get_current_user_id()) {
            return self::error('Solicitarea nu aparține contului tău.', 403);
        }
        $group_id = self::group_id($anchor->ID);
        if (!$group_id) { return array((int)$anchor->ID); }
        if (!in_array(self::state($group_id), array('submitted', 'pickup_ready'), true)) { return self::error('Expediția nu a fost trimisă.'); }
        $members = self::item_ids($group_id);
        $frozen = self::selected_ids($group_id);
        if ($frozen) {
            if (!in_array((int)$anchor->ID, $frozen, true) || array_diff($frozen, $members)) { return self::error('Scula nu este inclusă în această ridicare.'); }
            return $frozen;
        }
        $accepted = array();
        foreach ($members as $id) {
            $state = self::item_state($id);
            if (in_array($state, array('respinsa', 'retrasa'), true)) { continue; }
            if ($state !== 'acceptata' || get_post_meta($id, '_vsc_offer_reply', true) !== 'accept' ||
                !get_post_meta($id, '_vsc_offer_sent_at', true)) {
                return self::error('Răspunde tuturor ofertelor din expediție înainte de a finaliza ridicarea.');
            }
            $accepted[] = $id;
        }
        if (!$accepted || !in_array((int)$anchor->ID, $accepted, true)) { return self::error('Nu există scule acceptate pentru această ridicare.'); }
        return $accepted;
    }

    /** Called while the main checkout holds the group lease and its SQL transaction. */
    public static function freeze_pickup($anchor_id, $ids) {
        $group_id = self::group_id($anchor_id);
        if (!$group_id) { return true; }
        $expected = self::checkout_targets($anchor_id);
        if (is_wp_error($expected)) { return $expected; }
        $ids = array_values(array_unique(array_map('absint', (array)$ids)));
        sort($ids); $compare = $expected; sort($compare);
        if ($ids !== $compare) { return self::error('Lista sculelor acceptate s-a modificat. Reîncarcă pagina.'); }
        $frozen = self::selected_ids($group_id);
        if ($frozen) { sort($frozen); return $frozen === $ids ? true : self::error('Ridicarea include deja alte scule.'); }
        if (!add_post_meta($group_id, '_vsc_shipment_selected_ids', $ids, true) ||
            update_post_meta($group_id, '_vsc_shipment_state', 'pickup_ready') === false) {
            return self::error('Ridicarea comună nu a putut fi salvată.', 500);
        }
        update_post_meta($group_id, '_vsc_shipment_pickup_at', current_time('mysql'));
        return true;
    }

    public static function logistics_targets($anchor_id) {
        $group_id = self::group_id($anchor_id);
        if (!$group_id) { return array(absint($anchor_id)); }
        $selected = self::selected_ids($group_id);
        if (!$selected || !in_array(absint($anchor_id), $selected, true)) { return array(absint($anchor_id)); }
        if (array_diff($selected, self::item_ids($group_id))) { return self::error('Expediția conține scule indisponibile.'); }
        return $selected;
    }

    public static function cleanup_expired($user_id = 0) {
        $query = array('post_type' => self::TYPE, 'post_status' => 'private', 'numberposts' => 100, 'fields' => 'ids',
            'meta_query' => array(array('key' => '_vsc_shipment_state', 'value' => 'draft'),
                array('key' => '_vsc_shipment_expires', 'value' => time(), 'compare' => '<', 'type' => 'NUMERIC')));
        if ($user_id) { $query['author'] = absint($user_id); }
        foreach (get_posts($query) as $group_id) {
            $lock = self::acquire_lock($group_id);
            if (is_wp_error($lock)) { continue; }
            try {
                self::refresh_group($group_id);
                if (self::state($group_id) !== 'draft' || (int)get_post_meta($group_id, '_vsc_shipment_expires', true) >= time()) { continue; }
                $ids = self::item_ids($group_id);
                $safe = true;
                foreach ($ids as $id) { if (get_post_status($id) !== 'draft') { $safe = false; break; } }
                if (!$safe) { continue; }
                $deleted = true;
                foreach ($ids as $id) { if (!wp_delete_post($id, true)) { $deleted = false; } }
                if ($deleted) { wp_delete_post($group_id, true); }
            } finally { self::release_lock($lock); }
        }
    }

    public static function guest() {
        wp_send_json_error(array('message' => 'Autentifică-te pentru a gestiona expediția.'), 401);
    }

    public static function ajax() {
        if (!is_user_logged_in()) { self::guest(); }
        if (!check_ajax_referer('vsc_shipment', 'security', false)) {
            wp_send_json_error(array('message' => 'Sesiunea a expirat. Reîncarcă pagina.'), 403);
        }
        $operation = isset($_POST['operation']) && is_scalar($_POST['operation']) ? sanitize_key(wp_unslash($_POST['operation'])) : '';
        $id = isset($_POST['shipment_id']) && is_scalar($_POST['shipment_id']) ? absint(wp_unslash($_POST['shipment_id'])) : 0;
        if ($operation === 'create') {
            $token = isset($_POST['client_token']) && is_string($_POST['client_token']) ? wp_unslash($_POST['client_token']) : '';
            $result = self::create_group($token);
        } elseif ($operation === 'list') {
            $owned = self::owned_group($id);
            $result = is_wp_error($owned) ? $owned : self::snapshot($id);
        } elseif ($operation === 'remove') {
            $item = isset($_POST['item_id']) && is_scalar($_POST['item_id']) ? absint(wp_unslash($_POST['item_id'])) : 0;
            $result = self::remove_item($id, $item);
        } elseif ($operation === 'finalize') {
            $result = self::finalize_group($id);
        } else { $result = self::error('Operație necunoscută.', 400); }
        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            wp_send_json_error(array('message' => $result->get_error_message()), is_array($data) && isset($data['status']) ? (int)$data['status'] : 409);
        }
        wp_send_json_success(array('shipment' => $result));
    }
}
