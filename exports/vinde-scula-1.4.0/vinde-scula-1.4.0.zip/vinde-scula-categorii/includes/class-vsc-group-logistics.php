<?php
/** Shared outbound transport for the frozen tools of one shipment. */
if (!defined('ABSPATH')) { exit; }

final class VSC_Group_Logistics {
    private static function problem($message, $status = 409) {
        throw new RuntimeException($message, $status);
    }

    private static function length($value) {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private static function field($name) {
        return isset($_POST[$name]) && is_scalar($_POST[$name])
            ? trim(sanitize_text_field(wp_unslash($_POST[$name]))) : '';
    }

    private static function ids($values) {
        if (!is_array($values)) { self::problem('Lista sculelor din expediție nu este disponibilă.'); }
        $ids = array_values(array_unique(array_map('absint', $values)));
        if (in_array(0, $ids, true)) { self::problem('Expediția conține o solicitare nevalidă.'); }
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    /** Update or insert a transport field inside the active transaction. */
    private static function put($id, $key, $value, $metadata) {
        global $wpdb;
        if (isset($metadata[$key])) {
            $result = $wpdb->update($wpdb->postmeta, array('meta_value' => $value),
                array('post_id' => $id, 'meta_key' => $key), array('%s'), array('%d', '%s'));
        } else {
            $result = $wpdb->insert($wpdb->postmeta,
                array('post_id' => $id, 'meta_key' => $key, 'meta_value' => $value), array('%d', '%s', '%s'));
        }
        if ($result === false) { self::problem('Datele de transport nu au putut fi salvate. Nicio sculă nu a fost modificată.', 500); }
    }

    /**
     * Called only after the main endpoint's staff capability, nonce, request
     * type/status and expected-state checks. Unrelated or single-tool actions
     * return false so the existing independent workflow continues unchanged.
     */
    public static function handle($id, $state, $action) {
        $next = self::field('next_status');
        $shipping = $action === 'shipping' && $state !== 'retur_pregatit';
        $status_change = $action === 'status' && in_array($next, array('ridicare_programata', 'in_transport', 'la_verificare'), true);
        if (!$shipping && !$status_change) { return false; }
        $id = absint($id);
        $initial = VSC_Shipments::logistics_targets($id);
        if (is_wp_error($initial)) {
            wp_send_json_error(array('message' => $initial->get_error_message()), 409);
            return true;
        }
        try { $targets = self::ids($initial); }
        catch (RuntimeException $exception) {
            wp_send_json_error(array('message' => $exception->getMessage()), $exception->getCode());
            return true;
        }
        if (count($targets) <= 1) { return false; }
        $group_id = (int)VSC_Shipments::group_id($id);
        if (!$group_id || !in_array($id, $targets, true)) {
            wp_send_json_error(array('message' => 'Sculele nu mai aparțin aceleiași expediții. Reîncarcă pagina.'), 409);
            return true;
        }
        $lock = VSC_Shipments::acquire_lock($group_id);
        if (is_wp_error($lock)) {
            wp_send_json_error(array('message' => $lock->get_error_message()), 409);
            return true;
        }

        global $wpdb;
        $transaction = false;
        $committed = false;
        $error = null;
        try {
            wp_cache_delete($group_id, 'post_meta');
            foreach ($targets as $target) { wp_cache_delete($target, 'post_meta'); }
            $fresh = VSC_Shipments::logistics_targets($id);
            if (is_wp_error($fresh) || self::ids($fresh) !== $targets || (int)VSC_Shipments::group_id($id) !== $group_id) {
                self::problem('Componența expediției s-a schimbat. Reîncarcă pagina.');
            }
            $engines = $wpdb->get_col($wpdb->prepare(
                'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN (%s,%s)',
                $wpdb->posts, $wpdb->postmeta
            ));
            if (count($engines) !== 2 || count(array_filter($engines, static function($engine) { return strtoupper($engine) === 'INNODB'; })) !== 2) {
                self::problem('Serverul nu permite actualizarea sigură a întregii expediții. Contactează administratorul.', 503);
            }
            if ($wpdb->query('START TRANSACTION') === false) { self::problem('Actualizarea expediției nu a putut începe.', 500); }
            $transaction = true;
            $all_ids = array_values(array_unique(array_merge($targets, array($group_id))));
            $placeholders = implode(',', array_fill(0, count($all_ids), '%d'));
            $posts = $wpdb->get_results($wpdb->prepare(
                "SELECT ID,post_type,post_status,post_author FROM {$wpdb->posts} WHERE ID IN ({$placeholders}) ORDER BY ID FOR UPDATE", $all_ids
            ), ARRAY_A);
            if ($posts === null || $wpdb->last_error || count($posts) !== count($all_ids)) { self::problem('O solicitare din expediție nu mai este disponibilă.'); }
            $by_id = array();
            foreach ($posts as $post) { $by_id[(int)$post['ID']] = $post; }
            $owner = (int)$by_id[$id]['post_author'];
            if (!$owner || $by_id[$group_id]['post_type'] !== 'vsc_expeditie' || $by_id[$group_id]['post_status'] !== 'private'
                || (int)$by_id[$group_id]['post_author'] !== $owner) {
                self::problem('Expediția nu mai este disponibilă pentru transport comun.');
            }
            $item_placeholders = implode(',', array_fill(0, count($targets), '%d'));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$item_placeholders}) ORDER BY meta_id FOR UPDATE", $targets
            ), ARRAY_A);
            if ($rows === null || $wpdb->last_error) { self::problem('Datele expediției nu au putut fi verificate.', 500); }
            $metadata = array_fill_keys($targets, array());
            foreach ($rows as $row) { $metadata[(int)$row['post_id']][$row['meta_key']][] = $row['meta_value']; }
            $required_previous = array('ridicare_programata' => 'acceptata', 'in_transport' => 'ridicare_programata', 'la_verificare' => 'in_transport');
            if ($status_change && $required_previous[$next] !== $state) { self::problem('Această schimbare de stare nu este permisă pentru expediție.'); }
            if ($shipping && !in_array($state, array('acceptata', 'ridicare_programata', 'in_transport', 'la_verificare'), true)) {
                self::problem('Transportul comun nu poate fi actualizat în această etapă.');
            }
            foreach ($targets as $target) {
                $post = $by_id[$target];
                if ($post['post_type'] !== 'vsc_solicitare' || $post['post_status'] !== 'private' || (int)$post['post_author'] !== $owner) {
                    self::problem('Sculele expediției nu mai aparțin aceluiași client.');
                }
                wp_cache_delete($target, 'posts');
                wp_cache_set($target, $metadata[$target], 'post_meta');
                if (!current_user_can('edit_post', $target)) { self::problem('Nu ai permisiunea de a actualiza toate sculele din expediție.', 403); }
                $meta = $metadata[$target];
                if (!isset($meta['_vsc_status']) || count($meta['_vsc_status']) !== 1 || $meta['_vsc_status'][0] !== $state) {
                    self::problem('Sculele expediției au stări diferite. Reîncarcă pagina înainte de a continua.');
                }
                if (empty($meta['_vsc_shipment_id']) || array_filter($meta['_vsc_shipment_id'], static function($value) use ($group_id) { return (string)$value !== (string)$group_id; })) {
                    self::problem('O sculă nu mai aparține acestei expediții.');
                }
                if (empty($meta['_vsc_checkout_completed_at'][0]) || VSC_Categorii_Plugin::checkout_pickup_decrypt($target) === false) {
                    self::problem('Clientul trebuie să finalizeze datele de ridicare pentru toate sculele din expediție.');
                }
                if ($status_change && $next === 'in_transport'
                    && (empty($meta['_vsc_transport_curier'][0]) || trim($meta['_vsc_transport_curier'][0]) === ''
                        || empty($meta['_vsc_transport_awb'][0]) || trim($meta['_vsc_transport_awb'][0]) === '')) {
                    self::problem('Salvează firma de curierat și AWB-ul pentru întreaga expediție înainte de a marca transportul.');
                }
            }
            if ($shipping) {
                $courier = self::field('courier');
                $awb = self::field('awb');
                if (self::length($courier) > 80 || self::length($awb) > 100
                    || ($awb !== '' && !preg_match('/^[\p{L}\p{N} ._\/-]+$/uD', $awb))) {
                    self::problem('Curierul sau numărul AWB conține caractere nepermise ori este prea lung.', 400);
                }
                if (in_array($state, array('in_transport', 'la_verificare'), true) && ($courier === '' || $awb === '')) {
                    self::problem('O expediție aflată în transport trebuie să păstreze curierul și AWB-ul.');
                }
                foreach ($targets as $target) {
                    self::put($target, '_vsc_transport_curier', $courier, $metadata[$target]);
                    self::put($target, '_vsc_transport_awb', $awb, $metadata[$target]);
                }
            } else {
                foreach ($targets as $target) {
                    $changed = $wpdb->update($wpdb->postmeta, array('meta_value' => $next),
                        array('post_id' => $target, 'meta_key' => '_vsc_status', 'meta_value' => $state),
                        array('%s'), array('%d', '%s', '%s'));
                    if ($changed === false) { self::problem('Starea expediției nu a putut fi salvată. Nicio sculă nu a fost modificată.', 500); }
                    if ($changed !== 1) { self::problem('O solicitare s-a schimbat simultan. Expediția nu a fost modificată.'); }
                }
            }
            if ($wpdb->query('COMMIT') === false) { self::problem('Actualizarea expediției nu a putut fi confirmată.', 500); }
            $transaction = false;
            $committed = true;
        } catch (Throwable $exception) {
            if ($transaction) { $wpdb->query('ROLLBACK'); }
            $code = (int)$exception->getCode();
            $known = $exception instanceof RuntimeException && in_array($code, array(400, 403, 409, 500, 503), true);
            $error = new WP_Error('vsc_group_logistics', $known ? $exception->getMessage() : 'Expediția nu a putut fi actualizată. Încearcă din nou.', array('status' => $known ? $code : 500));
        } finally {
            foreach ($targets as $target) { clean_post_cache($target); }
            VSC_Shipments::release_lock($lock);
        }
        if ($error || !$committed) {
            $data = $error ? $error->get_error_data() : array('status' => 500);
            wp_send_json_error(array('message' => $error ? $error->get_error_message() : 'Expediția nu a putut fi actualizată.'), $data['status']);
            return true;
        }
        $labels = array('ridicare_programata' => 'Ridicare programată', 'in_transport' => 'În transport', 'la_verificare' => 'Primită pentru verificare');
        $mailed = true;
        $post_commit_ok = true;
        try {
            foreach ($targets as $target) {
                VSC_Categorii_Plugin::workflow_log($target, $shipping ? 'shipping' : 'status', $shipping
                    ? 'Curierul și AWB-ul au fost actualizate pentru expediția comună.'
                    : 'Starea expediției comune a fost schimbată: ' . $labels[$next] . '.');
            }
            // One parcel has one customer: do not send the same transport email
            // once for every tool in that parcel.
            if ($status_change) { $mailed = VSC_Categorii_Plugin::notify_client_progress($id, $next); }
        } catch (Throwable $exception) { $post_commit_ok = false; }
        $message = $shipping
            ? sprintf('Curierul și AWB-ul au fost salvate pentru toate cele %d scule din expediție. Retururile rămân separate.', count($targets))
            : sprintf('Expediția a fost actualizată pentru toate cele %d scule.', count($targets));
        if (!$mailed || !$post_commit_ok) { $message .= ' Datele sunt salvate, dar verifică notificarea clientului și istoricul.'; }
        $response = array('message' => $message, 'items' => count($targets));
        if ($status_change) { $response['status'] = $labels[$next]; }
        wp_send_json_success($response);
        return true;
    }
}
