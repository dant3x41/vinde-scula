(function () {
  'use strict';

  var config = window.VSC_CATEGORII || {};
  var categoryKeys = [
    'scule-acumulator', 'scule-electrice', 'scule-pneumatice',
    'acumulatori', 'incarcatoare'
  ];
  var cardSelector = categoryKeys.map(function (key) { return '.vsc-cat-' + key; }).join(',');
  var conditionHelp = {
    'Nouă': 'Nouă — nefolosită, în stare impecabilă.',
    'Ca nouă': 'Ca nouă — utilizare minimă, aproape fără urme.',
    'Foarte bună': 'Foarte bună — funcționează perfect, urme ușoare de utilizare.',
    'Bună': 'Bună — funcțională, cu urme normale de utilizare.'
  };

  function init(root) {
    if (root.dataset.vscInitialized === 'yes') { return; }
    root.dataset.vscInitialized = 'yes';

    // Localizăm cardurile Elementor chiar dacă widgetul Shortcode este în
    // același container părinte. Nu ascundem niciodată un element ce cuprinde formularul.
    var categoryCards = Array.from(document.querySelectorAll(cardSelector)).filter(function (node) {
      return !root.contains(node);
    });
    var cardWrapper = document.querySelector('.vsc-categorii-elementor');
    if (cardWrapper && !categoryCards.some(function (node) { return cardWrapper.contains(node); })) {
      cardWrapper = null;
    }
    var cardRegions = [];
    if (cardWrapper && !cardWrapper.contains(root)) {
      cardRegions = [cardWrapper];
    } else {
      categoryCards.forEach(function (card) {
        var region = card;
        // Dacă părintele are și formularul, ascundem doar ramura cu carduri.
        // În Elementor, aceasta este de obicei containerul unui rând de carduri.
        if (cardWrapper) {
          while (region.parentElement && region.parentElement !== cardWrapper &&
                 !region.parentElement.contains(root)) {
            region = region.parentElement;
          }
        }
        if (!region.contains(root) && cardRegions.indexOf(region) === -1) {
          cardRegions.push(region);
        }
      });
    }
    var hasCards = cardRegions.length > 0;
    function setCardsVisible(visible) {
      cardRegions.forEach(function (region) {
        region.hidden = !visible;
        region.classList.toggle('vsc-elementor-cards-hidden', !visible);
      });
    }
    var details = root.querySelector('[data-step="form"]');
    var success = root.querySelector('[data-step="success"]');
    var form = root.querySelector('.vsc-form');
    var categoryInput = form.elements.categoria;
    var categoryField = root.querySelector('[data-category-field]');
    var categorySummary = root.querySelector('[data-selected-summary]');
    var categoryText = root.querySelector('[data-category-label]');
    var brand = form.elements.marca;
    var brandTrigger = root.querySelector('[data-brand-open]');
    var brandDisplay = root.querySelector('[data-brand-name]');
    var brandDialog = root.querySelector('.vsc-brand-dialog');
    var brandSearch = root.querySelector('[data-brand-search]');
    var brandOptions = Array.from(root.querySelectorAll('[data-brand-option]'));
    var brandEmpty = root.querySelector('[data-brand-empty]');
    var platformDetails = form.querySelector('[data-battery-platform]');
    var platformSelect = form.elements.platforma;
    var platformOtherRow = form.querySelector('[data-platform-other]');
    var platformOtherInput = form.elements.platforma_alta;
    var condition = form.elements.stare;
    var conditionTip = form.querySelector('[data-condition-tip]');
    var photoInput = root.querySelector('.vsc-file-input');
    var photoPreview = root.querySelector('.vsc-previews');
    var message = root.querySelector('.vsc-message');
    var submitButton = root.querySelector('button[type="submit"]');
    var termsGate = form.querySelector('[data-vsc-terms-gate]');
    var termsDetails = termsGate && termsGate.querySelector('[data-vsc-terms-details]');
    var termsScroll = termsGate && termsGate.querySelector('[data-vsc-terms-scroll]');
    var termsReadButton = termsGate && termsGate.querySelector('[data-vsc-terms-read]');
    var termsHint = termsGate && termsGate.querySelector('[data-vsc-terms-hint]');
    var termsAck = form.elements.conditii_citite;
    var ownershipBox = form.elements.proprietar;
    var privacyBox = form.elements.acord;
    var termsRead = false;
    var sendingRequest = false;
    var externalBusy = false;
    var shipmentController = null;
    var interactionSnapshot = null;

    function syncInteractionLock() {
      var locked = sendingRequest || externalBusy;
      if (locked && !interactionSnapshot) {
        interactionSnapshot = Array.from(root.querySelectorAll('input,select,textarea,button')).map(function (control) {
          var item = {control: control, disabled: control.disabled};
          control.disabled = true;
          return item;
        });
      } else if (!locked && interactionSnapshot) {
        interactionSnapshot.forEach(function (item) { item.control.disabled = item.disabled; });
        interactionSnapshot = null;
      }
    }

    function isAtEndOfTerms() {
      if (!termsScroll || !termsDetails || !termsDetails.open) { return false; }
      return termsScroll.scrollTop + termsScroll.clientHeight >= termsScroll.scrollHeight - 4;
    }
    function refreshSubmitAvailability() {
      if (submitButton) {
        submitButton.disabled = sendingRequest || externalBusy || !termsRead || !ownershipBox.checked || !privacyBox.checked;
      }
      if (shipmentController) { shipmentController.refresh(); }
    }
    function updateTermsProgress() {
      if (!termsScroll || termsRead) { return; }
      var reachedEnd = isAtEndOfTerms();
      termsReadButton.disabled = !reachedEnd;
      termsHint.textContent = reachedEnd
        ? 'Ai ajuns la final. Apasă „Confirm că am citit” pentru a continua.'
        : 'Parcurge condițiile până la final pentru a continua.';
    }
    function resetTermsGate() {
      termsRead = false;
      if (!termsGate) { return; }
      termsAck.value = '0';
      ownershipBox.checked = false;
      privacyBox.checked = false;
      ownershipBox.disabled = true;
      privacyBox.disabled = true;
      termsReadButton.disabled = true;
      termsReadButton.textContent = 'Confirm că am citit';
      termsHint.textContent = 'Deschide condițiile și parcurge textul până la capăt.';
      termsDetails.open = false;
      termsScroll.scrollTop = 0;
      refreshSubmitAvailability();
    }
    if (termsGate) {
      termsDetails.addEventListener('toggle', function () {
        if (!termsDetails.open || termsRead) { return; }
        // La deschidere cu scroll 0 nu deblocăm bifa: trebuie parcursă secțiunea.
        termsScroll.scrollTop = 0;
        updateTermsProgress();
      });
      termsScroll.addEventListener('scroll', updateTermsProgress, {passive: true});
      termsReadButton.addEventListener('click', function () {
        if (!isAtEndOfTerms()) { updateTermsProgress(); return; }
        termsRead = true;
        termsAck.value = '1';
        ownershipBox.disabled = false;
        privacyBox.disabled = false;
        termsReadButton.disabled = true;
        termsReadButton.textContent = 'Citire confirmată ✓';
        termsHint.textContent = 'Acum poți bifa cele două declarații și trimite cererea.';
        refreshSubmitAvailability();
      });
      ownershipBox.addEventListener('change', refreshSubmitAvailability);
      privacyBox.addEventListener('change', refreshSubmitAvailability);
      resetTermsGate();
    }
    var backButton = root.querySelector('.vsc-button--back');
    var packageField = root.querySelector('[data-package-field]');
    var packageInput = form.elements.pachet;
    var packageCards = Array.from(root.querySelectorAll('[data-package]'));
    var kitDetails = form.querySelector('[data-kit-details]');
    var kitCapacity = form.elements.kit_capacitate;
    var kitVoltage = form.elements.kit_tensiune;
    var kitOtherVoltageArea = form.querySelector('[data-kit-other-voltage]');
    var kitOtherVoltageInput = form.elements.kit_alta_tensiune;
    var kitMixedArea = form.querySelector('[data-kit-mixed]');
    var kitMixedInput = form.elements.kit_capacitati_diferite;
    var kitExtrasCheckbox = form.elements.kit_alte_accesorii;
    var kitExtrasArea = form.querySelector('[data-kit-extras]');
    var kitExtrasInput = form.elements.kit_accesorii_detalii;
    var validPackages = ['kit-complet', 'doar-corp'];
    var wizardPanels = Array.from(form.querySelectorAll('[data-wizard-step]'));
    var currentWizardStep = 1;
    var contactPrefillAttempted = false;
    var contactPrefillFields = {
      nume: form.elements.nume,
      telefon: form.elements.telefon,
      email: form.elements.email,
      judet: form.elements.judet,
      localitate: form.elements.localitate
    };
    var profileNotice = form.querySelector('[data-profile-notice]');
    Object.keys(contactPrefillFields).forEach(function (key) {
      var field = contactPrefillFields[key];
      if (field) {
        field.addEventListener('input', function () { field.dataset.vscEdited = 'true'; });
      }
    });

    async function prefillContactFromAccount() {
      if (contactPrefillAttempted || !config.loggedIn || !config.contactNonce) { return; }
      contactPrefillAttempted = true;
      try {
        var body = new URLSearchParams({
          action: 'vsc_contact_profile', security: config.contactNonce
        });
        var response = await fetch(config.ajax, {
          method: 'POST', credentials: 'same-origin', cache: 'no-store',
          headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
          body: body.toString()
        });
        if (!response.ok) { return; }
        var result = await response.json();
        if (!result || !result.success || !result.data) { return; }
        var filled = false;
        Object.keys(contactPrefillFields).forEach(function (key) {
          var field = contactPrefillFields[key];
          var value = result.data[key];
          // Nu suprascriem valori tastate ori șterse deliberat de client.
          if (field && !field.dataset.vscEdited && !field.value.trim() && typeof value === 'string' && value.trim()) {
            field.value = value;
            filled = true;
          }
        });
        if (filled) { saveDraft(); }
        if (filled && profileNotice) { profileNotice.hidden = false; }
      } catch (ignored) {
        // Dacă WP-Cron, sesiunea ori rețeaua nu răspund, completarea manuală rămâne disponibilă.
      }
    }

    // Progres temporar pentru această filă. Nu folosim localStorage pentru
    // datele personale; acesta ar rămâne după închiderea browserului.
    var draftReady = false;
    var draftMaxAge = 12 * 60 * 60 * 1000;
    var draftPrefix = 'vsc:form-draft:v1:' + window.location.pathname + ':' + (config.draftAccount || 'guest');
    var photoTokenKey = draftPrefix + ':tab';
    var photoStoreKey = '';
    var previousPhotoStoreKey = '';
    var photoQueue = Promise.resolve();
    var restoringPhotos = false;
    var storageAvailable = false;
    try {
      var previousToken = window.sessionStorage.getItem(photoTokenKey);
      var token = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now()) + '-' + String(Math.random()).slice(2);
      // O filă duplicată copiază sessionStorage. Citim ciorna veche, însă
      // toate scrierile acestei pagini folosesc o cheie foto nouă.
      if (previousToken) { previousPhotoStoreKey = draftPrefix + ':' + previousToken; }
      window.sessionStorage.setItem(photoTokenKey, token);
      photoStoreKey = draftPrefix + ':' + token;
      storageAvailable = true;
    } catch (ignored) { /* Modul privat poate bloca stocarea. */ }

    function readDraft() {
      if (!storageAvailable) { return null; }
      try {
        var stored = JSON.parse(window.sessionStorage.getItem(draftPrefix) || 'null');
        if (!stored || !stored.savedAt || Date.now() - stored.savedAt > draftMaxAge ||
            !isValidCategory(stored.category) || !stored.fields || typeof stored.fields !== 'object') {
          window.sessionStorage.removeItem(draftPrefix);
          return null;
        }
        return stored;
      } catch (ignored) { return null; }
    }

    function saveDraft() {
      if (!storageAvailable || !draftReady || !isValidCategory(categoryInput.value) || success.hidden === false) { return; }
      var values = {};
      Array.from(form.querySelectorAll('input[name],select[name],textarea[name]')).forEach(function (field) {
        if (field.disabled || ['action','security','website','fotografii[]','acord','proprietar','conditii_citite'].indexOf(field.name) !== -1) { return; }
        if (field.type === 'radio') {
          if (field.checked) { values[field.name] = field.value; }
        } else if (field.type === 'checkbox') {
          values[field.name] = field.checked;
        } else {
          values[field.name] = field.value;
        }
      });
      try {
        window.sessionStorage.setItem(draftPrefix, JSON.stringify({
          category: categoryInput.value, fields: values,
          step: currentWizardStep, savedAt: Date.now()
        }));
      } catch (ignored) { /* Formularul rămâne complet utilizabil. */ }
    }

    function restoreDraft(draft) {
      if (!draft || draft.category !== categoryInput.value) { return; }
      Object.keys(draft.fields).forEach(function (name) {
        if (['categoria','action','security','website','fotografii[]','acord','proprietar','conditii_citite'].indexOf(name) !== -1) { return; }
        var candidates = Array.from(form.querySelectorAll('[name]')).filter(function (field) {
          return field.name === name;
        });
        candidates.forEach(function (field) {
          if (field.type === 'radio') { field.checked = field.value === draft.fields[name]; }
          else if (field.type === 'checkbox') { field.checked = draft.fields[name] === true; }
          else if (typeof draft.fields[name] === 'string') { field.value = draft.fields[name]; }
          if (['nume','telefon','email','judet','localitate'].indexOf(name) !== -1 && field.value.trim()) {
            field.dataset.vscEdited = 'true'; // Nu suprascriem valorile cu datele contului.
          }
        });
      });
      // Acordul pentru prelucrarea datelor nu este memorat automat.
      if (form.elements.acord) { form.elements.acord.checked = false; }
      if (form.elements.proprietar) { form.elements.proprietar.checked = false; }
      updatePackageUI();
      updateBrandSelection();
      conditionTip.textContent = conditionHelp[condition.value] || 'Indică starea reală a sculei.';
      showWizardStep(Number(draft.step) || 1, false);
    }

    function openPhotoDB() {
      return new Promise(function (resolve, reject) {
        if (!photoStoreKey || !window.indexedDB) { reject(new Error('Stocarea fotografiilor nu este disponibilă.')); return; }
        var request = window.indexedDB.open('vsc-photo-drafts-v1', 1);
        request.onupgradeneeded = function () {
          if (!request.result.objectStoreNames.contains('photos')) {
            request.result.createObjectStore('photos', {keyPath: 'id'});
          }
        };
        request.onsuccess = function () { resolve(request.result); };
        request.onerror = function () { reject(request.error); };
      });
    }

    async function photoDBRequest(mode, value, readKey) {
      var db = await openPhotoDB();
      try {
        return await new Promise(function (resolve, reject) {
          var transaction = db.transaction('photos', mode === 'get' ? 'readonly' : 'readwrite');
          var store = transaction.objectStore('photos');
          var req = mode === 'get' ? store.get(readKey || photoStoreKey) :
            mode === 'put' ? store.put(value) : store.delete(photoStoreKey);
          req.onsuccess = function () { resolve(req.result); };
          req.onerror = function () { reject(req.error); };
          transaction.onerror = function () { reject(transaction.error); };
        });
      } finally { db.close(); }
    }

    function persistPhotos() {
      if (!draftReady || !photoStoreKey) { return; }
      var currentFiles = files.slice();
      photoQueue = photoQueue.catch(function () {}).then(function () {
        return currentFiles.length ? photoDBRequest('put', {
          id: photoStoreKey, savedAt: Date.now(), files: currentFiles.map(function (file) {
            return {name: file.name, type: file.type, lastModified: file.lastModified, blob: file};
          })
        }) : photoDBRequest('delete');
      }).catch(function () { /* Stocarea fișierelor este best-effort. */ });
    }

    // IndexedDB supraviețuiește închiderii filei; ștergem automat proiectele
    // foto mai vechi de 12 ore la următoarea vizită, ca să nu se acumuleze.
    async function purgeExpiredPhotoDrafts() {
      if (!photoStoreKey) { return; }
      var db;
      try {
        db = await openPhotoDB();
        await new Promise(function (resolve, reject) {
          var transaction = db.transaction('photos', 'readwrite');
          var request = transaction.objectStore('photos').openCursor();
          request.onsuccess = function () {
            var cursor = request.result;
            if (!cursor) { return; }
            if (!cursor.value.savedAt || Date.now() - cursor.value.savedAt > draftMaxAge) {
              cursor.delete();
            }
            cursor.continue();
          };
          transaction.oncomplete = resolve;
          transaction.onerror = function () { reject(transaction.error); };
        });
      } catch (ignored) {
        // Lipsa IndexedDB nu blochează formularul.
      } finally { if (db) { db.close(); } }
    }

    function clearDraft() {
      try { window.sessionStorage.removeItem(draftPrefix); } catch (ignored) {}
      if (photoStoreKey) {
        photoQueue = photoQueue.catch(function () {}).then(function () {
          return photoDBRequest('delete');
        }).catch(function () {});
      }
    }

    async function restorePhotos(draft) {
      if (!draft || !photoStoreKey) { return; }
      restoringPhotos = true;
      try {
        var item = await photoDBRequest('get', null, previousPhotoStoreKey || photoStoreKey);
        if (!item || !item.savedAt || Date.now() - item.savedAt > draftMaxAge) {
          return;
        }
        if (files.length || !Array.isArray(item.files) || categoryInput.value !== draft.category) { return; }
        files = item.files.slice(0, 5).map(function (data) {
          return data instanceof File ? data : new File([data.blob || data], data.name || 'fotografie.jpg', {
            type: data.type || 'image/jpeg', lastModified: data.lastModified || Date.now()
          });
        }).filter(function (file) {
          return ['image/jpeg','image/png','image/webp'].indexOf(file.type) !== -1 && file.size <= 5 * 1024 * 1024;
        });
        // Copiem înainte de orice scriere nouă; nu modificăm cheia filei sursă.
        await photoDBRequest('put', {
          id: photoStoreKey, savedAt: item.savedAt, files: files.map(function (file) {
            return {name: file.name, type: file.type, lastModified: file.lastModified, blob: file};
          })
        });
        updateNativeFileList();
        renderPhotos();
      } catch (ignored) {
        // IndexedDB poate fi indisponibil în anumite browsere private.
      } finally {
        restoringPhotos = false;
        // Dacă pozele nu au fost recuperate, revenim la pasul 2.
        if (files.length === 0 && currentWizardStep >= 2 && categoryInput.value === draft.category) {
          showWizardStep(2, false);
        } else if (files.length > 0 && currentWizardStep === 3) {
          renderReview();
        }
      }
    }

    form.addEventListener('input', function (event) {
      if (event.target && event.target.name !== 'fotografii[]') { saveDraft(); }
    });
    form.addEventListener('change', function (event) {
      if (event.target && event.target.name !== 'fotografii[]') { saveDraft(); }
    });

    function showWizardStep(step, shouldScroll) {
      currentWizardStep = Math.max(1, Math.min(3, step));
      wizardPanels.forEach(function (panel) {
        panel.hidden = Number(panel.dataset.wizardStep) !== currentWizardStep;
      });
      if (currentWizardStep === 3) { renderReview(); }
      clearError();
      saveDraft();
      if (shouldScroll) { root.scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'start'}); }
    }

    function validateProductStep() {
      if (!isValidCategory(categoryInput.value)) {
        showError('Alege o categorie de produs.');
        if (hasCards) { goBackToCategories(); }
        else { categoryInput.focus(); }
        return false;
      }
      if (!brand.value) {
        showError('Alege marca sculei pentru a continua.');
        openBrandDialog();
        return false;
      }
      var checks = [brand, form.elements.model, condition];
      if (platformOtherInput && platformOtherInput.required) { checks.push(platformOtherInput); }
      for (var i = 0; i < checks.length; i++) {
        var field = checks[i];
        if (!field || !field.willValidate || field.checkValidity()) { continue; }
        showError('Completează toate câmpurile obligatorii din detaliile sculei.');
        if (field === platformOtherInput) { platformDetails.open = true; }
        field.focus({preventScroll:false});
        field.reportValidity();
        return false;
      }
      if (categoryInput.value === 'scule-acumulator' && !isValidPackage(packageInput.value)) {
        showError('Alege Kit complet sau Doar corp.');
        if (packageCards.length) { packageCards[0].focus({preventScroll: true}); }
        return false;
      }
      if (!kitDetails.disabled) {
        var kitRequired = Array.from(kitDetails.querySelectorAll('[required]'));
        for (var k = 0; k < kitRequired.length; k++) {
          if (!kitRequired[k].checkValidity()) {
            showError('Completează detaliile obligatorii din Kit complet.');
            kitRequired[k].focus({preventScroll:false});
            kitRequired[k].reportValidity();
            return false;
          }
        }
      }
      return true;
    }

    function validatePhotoStep() {
      if (restoringPhotos) { showError('Se restaurează fotografiile, încearcă din nou peste o clipă.'); return false; }
      if (files.length < 1) {
        showError('Adaugă cel puțin o fotografie a produsului pentru a continua.');
        return false;
      }
      return true;
    }

    // Rezumat actualizat numai din câmpurile formularului deja validate.
    // Inserăm toate valorile cu textContent, nu cu HTML provenit de la utilizator.
    function renderReview() {
      var review = form.querySelector('[data-wizard-step="3"]');
      if (!review) { return; }
      function setValue(key, value) {
        var element = review.querySelector('[data-vsc-review="' + key + '"]');
        if (element) { element.textContent = String(value || '—'); }
      }
      function rowVisible(selector, visible) {
        var row = review.querySelector(selector);
        if (row) { row.hidden = !visible; }
      }
      function inputValue(name) { return form.elements[name] ? form.elements[name].value.trim() : ''; }
      setValue('category', chosenCategoryTitle());
      setValue('product', [brand.value, inputValue('model')].filter(Boolean).join(' '));
      setValue('condition', inputValue('stare'));
      setValue('year', inputValue('an_fabricatie') || 'Nu este precizat');
      var isCordless = categoryInput.value === 'scule-acumulator';
      rowVisible('[data-review-package-row]', isCordless);
      setValue('package', packageInput.value === 'kit-complet' ? 'Kit complet' : 'Doar corp');
      var platformValue = inputValue('platforma');
      if (platformValue === 'Altă platformă') { platformValue = inputValue('platforma_alta') || 'Altă platformă'; }
      rowVisible('[data-review-platform-row]', isCordless && !!platformValue);
      setValue('platform', platformValue);
      var isKit = isCordless && packageInput.value === 'kit-complet';
      rowVisible('[data-review-kit-row]', isKit);
      if (isKit) {
        var kitParts = [];
        var capacity = inputValue('kit_capacitate');
        if (capacity === 'Capacități diferite') { capacity = inputValue('kit_capacitati_diferite') || capacity; }
        var voltage = inputValue('kit_tensiune');
        if (voltage === 'Altă tensiune') { voltage = inputValue('kit_alta_tensiune') || voltage; }
        if (inputValue('kit_numar')) { kitParts.push(inputValue('kit_numar') + ' acumulator(i)'); }
        if (capacity) { kitParts.push(capacity); }
        if (voltage) { kitParts.push(voltage); }
        if (inputValue('kit_incarcator')) { kitParts.push('Încărcător ' + inputValue('kit_incarcator').toLowerCase()); }
        if (form.elements.kit_valiza && form.elements.kit_valiza.checked) { kitParts.push('Valiză / cutie'); }
        if (form.elements.kit_alte_accesorii && form.elements.kit_alte_accesorii.checked && inputValue('kit_accesorii_detalii')) {
          kitParts.push(inputValue('kit_accesorii_detalii'));
        }
        setValue('kit', kitParts.join(' · '));
      }
      var description = inputValue('descriere');
      rowVisible('[data-review-description-row]', !!description);
      setValue('description', description);
      var photoCount = review.querySelector('[data-review-photo-count]');
      if (photoCount) { photoCount.textContent = files.length + (files.length === 1 ? ' fotografie' : ' fotografii'); }
      var gallery = review.querySelector('[data-review-photos]');
      if (gallery) {
        gallery.replaceChildren();
        files.forEach(function (file, index) {
          var figure = document.createElement('figure');
          var image = document.createElement('img');
          var caption = document.createElement('figcaption');
          image.alt = 'Fotografia ' + (index + 1);
          var url = URL.createObjectURL(file);
          image.src = url;
          image.addEventListener('load', function () { URL.revokeObjectURL(url); }, {once:true});
          image.addEventListener('error', function () { URL.revokeObjectURL(url); }, {once:true});
          caption.textContent = 'Foto ' + (index + 1);
          figure.append(image, caption);
          gallery.appendChild(figure);
        });
      }
    }

    function advanceWizard() {
      clearError();
      if (currentWizardStep === 1) {
        if (!validateProductStep()) { return; }
        showWizardStep(2, true);
      } else if (currentWizardStep === 2) {
        if (!validatePhotoStep()) { return; }
        showWizardStep(3, true);
      }
    }
    root.querySelectorAll('[data-next-step]').forEach(function (button) {
      button.addEventListener('click', advanceWizard);
    });
    root.querySelectorAll('[data-prev-step]').forEach(function (button) {
      button.addEventListener('click', function () {
        showWizardStep(currentWizardStep - 1, true);
      });
    });

    var packageStorageKey = 'vsc:selected-package:' + window.location.pathname;

    function isValidPackage(value) { return validPackages.indexOf(value) !== -1; }
    function rememberPackage(value) {
      try {
        if (isValidPackage(value)) { window.localStorage.setItem(packageStorageKey, value); }
        else { window.localStorage.removeItem(packageStorageKey); }
      } catch (ignored) { /* Salvarea opţiunii este facultativă. */ }
    }
    function savedPackage() {
      try {
        var value = window.localStorage.getItem(packageStorageKey) || '';
        return isValidPackage(value) ? value : '';
      } catch (ignored) { return ''; }
    }
    function updateKitVisibility() {
      var isKit = categoryInput.value === 'scule-acumulator' && packageInput.value === 'kit-complet';
      kitDetails.hidden = !isKit;
      kitDetails.disabled = !isKit;
      var mixed = isKit && kitCapacity.value === 'Capacități diferite';
      kitMixedArea.hidden = !mixed;
      kitMixedInput.disabled = !mixed;
      kitMixedInput.required = mixed;
      var otherVoltage = isKit && kitVoltage.value === 'Altă tensiune';
      kitOtherVoltageArea.hidden = !otherVoltage;
      kitOtherVoltageInput.disabled = !otherVoltage;
      kitOtherVoltageInput.required = otherVoltage;
      var extras = isKit && kitExtrasCheckbox.checked;
      kitExtrasArea.hidden = !extras;
      kitExtrasInput.disabled = !extras;
      kitExtrasInput.required = extras;
    }
    kitCapacity.addEventListener('change', updateKitVisibility);
    kitVoltage.addEventListener('change', updateKitVisibility);
    kitExtrasCheckbox.addEventListener('change', updateKitVisibility);

    function updatePackageUI() {
      var active = categoryInput.value === 'scule-acumulator';
      packageField.hidden = !active;
      if (!active && packageInput.value) { packageInput.value = ''; rememberPackage(''); }
      packageCards.forEach(function (card) {
        var chosen = active && card.dataset.package === packageInput.value;
        card.setAttribute('aria-checked', chosen ? 'true' : 'false');
        card.classList.toggle('vsc-package-option--selected', chosen);
      });
      updateKitVisibility();
    }
    function choosePackage(value) {
      if (categoryInput.value !== 'scule-acumulator' || !isValidPackage(value)) { return; }
      packageInput.value = value;
      rememberPackage(value);
      updatePackageUI();
      saveDraft();
      clearError();
    }

    packageCards.forEach(function (card, i) {
      card.addEventListener('click', function (event) {
        // Şabloanele cardurilor nu trebuie să includă linkuri sau butoane proprii.
        if (event.target.closest('a')) { event.preventDefault(); }
        choosePackage(card.dataset.package);
      });
      card.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault(); choosePackage(card.dataset.package);
        } else if (['ArrowLeft', 'ArrowUp', 'ArrowRight', 'ArrowDown'].indexOf(event.key) !== -1) {
          event.preventDefault();
          var next = packageCards[(i + (event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : packageCards.length - 1)) % packageCards.length];
          next.focus(); choosePackage(next.dataset.package);
        }
      });
    });
    var files = [];
    var reducedMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    function isValidCategory(key) {
      return categoryKeys.indexOf(key) !== -1;
    }

    function chosenCategoryTitle() {
      var chosen = categoryInput.options[categoryInput.selectedIndex];
      return chosen ? chosen.textContent : '';
    }

    function updatePlatformOther() {
      if (!platformOtherRow || !platformOtherInput) { return; }
      var needsOther = !platformDetails.hidden && platformSelect.value === 'Altă platformă';
      platformOtherRow.hidden = !needsOther;
      platformOtherInput.disabled = !needsOther;
      platformOtherInput.required = needsOther;
      if (!needsOther) { platformOtherInput.value = ''; }
    }

    function updatePlatformOptions() {
      if (!platformDetails || !platformSelect) { return; }
      var active = categoryInput.value === 'scule-acumulator';
      platformDetails.hidden = !active;
      platformSelect.disabled = !active;
      Array.from(platformSelect.options).forEach(function (option) {
        var brandName = option.getAttribute('data-platform-brand');
        if (brandName) { option.hidden = !active || brandName !== brand.value; option.disabled = !active || brandName !== brand.value; }
      });
      var option = platformSelect.options[platformSelect.selectedIndex];
      if (!active || (option && option.disabled)) { platformSelect.value = ''; }
      if (active && (platformSelect.value || platformOtherInput.value)) { platformDetails.open = true; }
      updatePlatformOther();
    }

    function updateCategoryUI() {
      var selected = isValidCategory(categoryInput.value);
      categorySummary.hidden = !selected;
      categoryField.hidden = selected;
      categoryText.textContent = selected ? chosenCategoryTitle() : '';
      backButton.hidden = !selected || !hasCards;
      updatePackageUI();
      updatePlatformOptions();
    }

    function showForm(shouldScroll) {
      setCardsVisible(false);
      root.hidden = false;
      success.hidden = true;
      details.hidden = false;
      updateCategoryUI();
      if (shouldScroll) {
        root.scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'start'});
      }
    }

    // Categoria este memorată în continuare între vizite. Celelalte câmpuri
    // sunt păstrate numai temporar în sesiunea filei curente.
    var categoryStorageKey = 'vsc:selected-category:' + window.location.pathname;

    function savedCategory() {
      try {
        var key = window.localStorage.getItem(categoryStorageKey) || '';
        return isValidCategory(key) ? key : '';
      } catch (ignored) { return ''; } // Stocarea poate fi interzisă de browser.
    }

    function rememberCategory(key) {
      try {
        if (isValidCategory(key)) { window.localStorage.setItem(categoryStorageKey, key); }
        else { window.localStorage.removeItem(categoryStorageKey); }
      } catch (ignored) { /* Linkurile cu ?categoria=... continuă să funcționeze. */ }
    }

    function updateAddressBar(key) {
      if (!window.history || !window.history.replaceState || !window.URL) { return; }
      try {
        var url = new URL(window.location.href);
        if (key) { url.searchParams.set('categoria', key); }
        else { url.searchParams.delete('categoria'); }
        window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
      } catch (ignored) { /* Alte pluginuri pot modifica adresa. */ }
    }

    function selectCategory(key, shouldScroll) {
      if (sendingRequest || externalBusy) { return false; }
      if (!isValidCategory(key)) { return false; }
      var changedCategory = categoryInput.value !== key;
      categoryInput.value = key;
      if (changedCategory) { showWizardStep(1, false); }
      saveDraft();
      rememberCategory(key);
      clearError();
      showForm(shouldScroll);
      updateAddressBar(key);
      return true;
    }

    function goBackToCategories() {
      if (sendingRequest || externalBusy) { return; }
      draftReady = false;
      clearDraft();
      form.reset();
      files = []; updateNativeFileList(); renderPhotos();
      resetTermsGate();
      Object.keys(contactPrefillFields).forEach(function (key) {
        if (contactPrefillFields[key]) { delete contactPrefillFields[key].dataset.vscEdited; }
      });
      contactPrefillAttempted = false;
      if (profileNotice) { profileNotice.hidden = true; }
      updateBrandSelection();
      conditionTip.textContent = 'Indică starea reală a sculei.';
      showWizardStep(1, false);
      clearError();
      categoryInput.value = '';
      rememberCategory('');
      packageInput.value = '';
      rememberPackage('');
      document.documentElement.classList.remove('vsc-category-restored');
      updateAddressBar('');
      updateCategoryUI();
      if (hasCards) {
        details.hidden = true;
        success.hidden = true;
        root.hidden = true;
        setCardsVisible(true);
        cardRegions[0].scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'start'});
      } else {
        showForm(false);
        categoryInput.focus();
      }
      draftReady = true;
    }

    document.addEventListener('click', function (event) {
      var node = event.target instanceof Element ? event.target.closest(cardSelector) : null;
      if (!node || categoryCards.indexOf(node) === -1) { return; }
      var match = categoryKeys.find(function (key) { return node.classList.contains('vsc-cat-' + key); });
      if (match && selectCategory(match, true)) { event.preventDefault(); }
    }, true);

    // Cardurile Elementor pot fi containere div, nu butoane. Le facem accesibile tastaturii.
    categoryCards.forEach(function (node) {
      if (!node.matches('a, button, input, [role="button"]')) {
        node.setAttribute('role', 'button');
        if (!node.hasAttribute('tabindex')) { node.setAttribute('tabindex', '0'); }
      }
      node.addEventListener('keydown', function (event) {
        if (event.target !== node || (event.key !== 'Enter' && event.key !== ' ')) { return; }
        var key = categoryKeys.find(function (item) { return node.classList.contains('vsc-cat-' + item); });
        if (key && selectCategory(key, true)) { event.preventDefault(); }
      });
    });

    root.querySelectorAll('[data-change-category]').forEach(function (button) {
      button.addEventListener('click', function () {
        // Butonul din bara de sus: săgeata circulară face o rotație scurtă
        // înainte de a ascunde formularul. Butonul „Înapoi” rămâne imediat.
        if (!button.classList.contains('vsc-change-category') || reducedMotion) {
          goBackToCategories();
          return;
        }
        if (button.classList.contains('vsc-change-category--spinning')) { return; }
        button.classList.add('vsc-change-category--spinning');
        window.setTimeout(function () {
          button.classList.remove('vsc-change-category--spinning');
          goBackToCategories();
        }, 450);
      });
    });
    categoryInput.addEventListener('change', function () {
      if (isValidCategory(categoryInput.value)) { selectCategory(categoryInput.value, false); }
      else { rememberCategory(''); updateCategoryUI(); updateAddressBar(''); }
    });
    function updateBrandSelection() {
      updatePlatformOptions();
      if (brandDisplay) { brandDisplay.textContent = brand.value || 'Alege marca sculei'; }
      if (brandTrigger) { brandTrigger.classList.toggle('vsc-brand-trigger--selected', !!brand.value); }
      if (brandDialog) { brandDialog.classList.toggle('vsc-brand-dialog--has-selection', !!brand.value); }
      brandOptions.forEach(function (option) {
        var active = option.dataset.brandOption === brand.value;
        option.setAttribute('aria-pressed', active ? 'true' : 'false');
        option.classList.toggle('vsc-brand-option--active', active);
      });
    }
    function normalizeBrandSearch(text) {
      return String(text || '').toLocaleLowerCase('ro-RO').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[șş]/g, 's').replace(/[țţ]/g, 't');
    }
    function filterBrands() {
      var query = normalizeBrandSearch(brandSearch.value.trim());
      // Căutarea nu schimbă valoarea aleasă până când clientul apasă pe card.
      var count = 0;
      brandOptions.forEach(function (option) {
        var matches = normalizeBrandSearch(option.dataset.brandOption).indexOf(query) !== -1;
        option.hidden = !matches;
        if (matches) { count++; }
      });
      brandEmpty.hidden = count > 0;
    }
    function openBrandDialog() {
      if (!brandDialog || typeof brandDialog.showModal !== 'function') {
        brand.focus();
        return;
      }
      brandSearch.value = '';
      filterBrands();
      brandDialog.showModal();
      window.requestAnimationFrame(function () { brandSearch.focus(); });
    }
    if (brandTrigger && brandDialog && typeof brandDialog.showModal === 'function') {
      brandTrigger.hidden = false;
      brand.classList.add('vsc-brand-native-select--replaced');
      brandTrigger.addEventListener('click', openBrandDialog);
      root.querySelectorAll('[data-brand-close]').forEach(function (button) {
        button.addEventListener('click', function () { brandDialog.close(); });
      });
      brandDialog.addEventListener('close', function () { brandTrigger.focus({preventScroll:true}); });
      brandSearch.addEventListener('input', filterBrands);
      brandOptions.forEach(function (option) {
        option.addEventListener('click', function () {
          brand.value = option.dataset.brandOption;
          brand.dispatchEvent(new Event('change', {bubbles:true}));
          brandDialog.close();
          clearError();
          saveDraft();
        });
      });
    }
    updateBrandSelection();
    brand.addEventListener('change', updateBrandSelection);
    if (platformSelect) {
      platformSelect.addEventListener('change', function () { updatePlatformOther(); saveDraft(); });
    }
    condition.addEventListener('change', function () {
      conditionTip.textContent = conditionHelp[condition.value] || 'Indică starea reală a sculei.';
    });

    function showError(messageText) {
      message.textContent = messageText;
      message.hidden = false;
      message.scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'center'});
    }
    function clearError() { message.textContent = ''; message.hidden = true; }

    function updateNativeFileList() {
      if (typeof DataTransfer === 'undefined') { return; }
      var transfer = new DataTransfer();
      files.forEach(function (file) { transfer.items.add(file); });
      photoInput.files = transfer.files;
    }
    function renderPhotos() {
      photoPreview.replaceChildren();
      files.forEach(function (file, index) {
        var outer = document.createElement('div'); outer.className = 'vsc-preview';
        var img = document.createElement('img'); img.alt = 'Fotografia ' + (index + 1);
        var url = URL.createObjectURL(file); img.src = url;
        img.addEventListener('load', function () { URL.revokeObjectURL(url); }, {once:true});
        var name = document.createElement('small'); name.textContent = (index + 1) + ' / ' + files.length;
        var remove = document.createElement('button'); remove.type = 'button'; remove.className = 'vsc-preview-remove';
        remove.textContent = '×'; remove.setAttribute('aria-label', 'Elimină fotografia ' + (index + 1));
        remove.addEventListener('click', function () { files.splice(index, 1); updateNativeFileList(); renderPhotos(); persistPhotos(); });
        outer.append(img, name, remove); photoPreview.appendChild(outer);
      });
    }
    // Redimensionăm fotografiile în browser, înainte de transfer: nu încărcăm
    // originalul mare doar pentru a-l comprima ulterior pe server.
    async function optimizeUpload(file) {
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 150 * 1024) { return file; }
      var bitmap = null;
      var image = null;
      var imageUrl = '';
      var canvas = null;
      try {
        if (typeof createImageBitmap === 'function') {
          bitmap = await createImageBitmap(file);
        } else {
          imageUrl = URL.createObjectURL(file);
          image = new Image();
          await new Promise(function (resolve, reject) {
            image.onload = resolve;
            image.onerror = reject;
            image.src = imageUrl;
          });
        }
        var width = bitmap ? bitmap.width : image.naturalWidth;
        var height = bitmap ? bitmap.height : image.naturalHeight;
        if (!width || !height) { return file; }
        var ratio = Math.min(1, 2048 / Math.max(width, height));
        canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(width * ratio));
        canvas.height = Math.max(1, Math.round(height * ratio));
        var ctx = canvas.getContext('2d');
        if (!ctx) { return file; }
        ctx.drawImage(bitmap || image, 0, 0, canvas.width, canvas.height);
        var blob = await new Promise(function (resolve) {
          canvas.toBlob(resolve, 'image/webp', 0.84);
        });
        // În unele browsere WebP nu este disponibil: păstrăm originalul.
        if (!blob || blob.type !== 'image/webp' || blob.size >= file.size * 0.95) { return file; }
        var basename = file.name.replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 90) || 'fotografie';
        return new File([blob], basename + '.webp', {type: 'image/webp', lastModified: file.lastModified});
      } catch (ignored) {
        return file;
      } finally {
        if (bitmap && typeof bitmap.close === 'function') { bitmap.close(); }
        if (imageUrl) { URL.revokeObjectURL(imageUrl); }
        if (canvas) { canvas.width = 0; canvas.height = 0; }
      }
    }

    photoInput.addEventListener('change', function () {
      var newFiles = Array.from(photoInput.files || []);
      if (newFiles.length + files.length > 5) {
        showError(config.filesLimit || 'Poți încărca maximum 5 fotografii.');
        updateNativeFileList(); return;
      }
      for (var i = 0; i < newFiles.length; i++) {
        if (newFiles[i].size > 5 * 1024 * 1024) {
          showError(config.fileSize || 'Maxim 5 MB per imagine.'); updateNativeFileList(); return;
        }
        if (['image/jpeg', 'image/png', 'image/webp'].indexOf(newFiles[i].type) < 0) {
          showError('Sunt acceptate doar imagini JPG, PNG sau WebP.'); updateNativeFileList(); return;
        }
      }
      files = files.concat(newFiles);
      clearError(); updateNativeFileList(); renderPhotos(); persistPhotos();
    });

    function showSubmissionSuccess(data, shipment) {
      draftReady = false;
      clearDraft();
      rememberCategory('');
      rememberPackage('');
      packageInput.value = '';
      document.documentElement.classList.remove('vsc-category-restored');
      updateAddressBar('');
      setCardsVisible(false);
      root.hidden = false;
      details.hidden = true;
      success.hidden = false;
      var referenceLabel = success.querySelector('[data-vsc-reference]');
      if (referenceLabel) {
        var ref = shipment ? shipment.reference : (data && data.referinta);
        referenceLabel.textContent = ref ? (shipment ? 'Expediere: ' : 'Nr. comenzii: ') + ref : '';
        referenceLabel.hidden = !ref;
      }
      if (shipment) {
        success.querySelector('h3').textContent = 'Expedierea a fost trimisă!';
        var introduction = success.querySelector('p:not([data-vsc-reference])');
        if (introduction) {
          introduction.textContent = 'Am înregistrat ' + shipment.items.length + ' scule. Fiecare primește o ofertă separată, iar sculele acceptate vor avea o singură ridicare.';
        }
      }
      root.scrollIntoView({behavior: reducedMotion ? 'auto' : 'smooth', block: 'start'});
      form.reset(); files = []; updateNativeFileList(); renderPhotos();
      resetTermsGate();
      Object.keys(contactPrefillFields).forEach(function (key) {
        if (contactPrefillFields[key]) { contactPrefillFields[key].dataset.vscEdited = 'true'; }
      });
      if (profileNotice) { profileNotice.hidden = true; }
      showWizardStep(1, false);
      updateBrandSelection();
      conditionTip.textContent = 'Indică starea reală a sculei.';
      updateCategoryUI();
    }

    async function submitCurrentItem(options) {
      options = options || {};
      if (sendingRequest || externalBusy) { return null; }
      clearError();
      // Enter într-un câmp nu trebuie să trimită cererea înaintea ultimului pas.
      if (currentWizardStep < 3) { advanceWizard(); return null; }
      if (!validateProductStep()) { showWizardStep(1, false); return null; }
      if (files.length < 1) {
        showWizardStep(2, false);
        validatePhotoStep();
        return null;
      }
      if (!termsRead || termsAck.value !== '1') {
        showError('Parcurge condițiile până la final și apasă „Confirm că am citit”.');
        if (termsDetails) { termsDetails.open = true; }
        return null;
      }
      if (!ownershipBox.checked || !privacyBox.checked) {
        showError('Bifează declarația de proprietate și acordul pentru prelucrarea datelor.');
        return null;
      }
      if (!form.reportValidity() || submitButton.disabled) { return null; }
      // Capturăm toate datele înainte de blocarea controalelor și așteptări.
      var payload = new FormData(form);
      var uploadFiles = files.slice();
      if (options.shipmentId) {
        payload.set('vsc_shipment_id', String(options.shipmentId));
        payload.set('vsc_item_token', options.itemToken);
      }
      sendingRequest = true;
      syncInteractionLock();
      refreshSubmitAvailability();
      var previousLabel = submitButton.innerHTML;
      // Un singur indicator de progres pe întreaga durată a trimiterii.
      submitButton.classList.add('vsc-button--processing');
      submitButton.setAttribute('aria-busy', 'true');
      submitButton.innerHTML = '<span class="vsc-submit-spinner" aria-hidden="true"></span><span>Se procesează...</span>';
      try {
        payload.delete('fotografii[]');
        for (var fileIndex = 0; fileIndex < uploadFiles.length; fileIndex++) {
          var optimized = await optimizeUpload(uploadFiles[fileIndex]);
          payload.append('fotografii[]', optimized, optimized.name);
        }
        // XMLHttpRequest oferă progres real pentru upload, spre deosebire de fetch.
        // Este util dacă cele 5 fotografii sunt mari şi conexiunea este lentă.
        var response = await new Promise(function (resolve, reject) {
          var xhr = new XMLHttpRequest();
          xhr.open('POST', config.ajax, true);
          xhr.withCredentials = true;
          xhr.timeout = 120000;
          xhr.ontimeout = function () { reject(new Error('Trimiterea durează prea mult. Datele au fost păstrate; verifică expedierea și reîncearcă.')); };
          xhr.onabort = function () { reject(new Error('Trimiterea a fost întreruptă. Datele formularului au fost păstrate.')); };
          xhr.onerror = function () { reject(new Error('Eroare de reţea la trimiterea solicitării.')); };
          xhr.onload = function () {
            try { resolve({ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, data: JSON.parse(xhr.responseText)}); }
            catch (ignored) { reject(new Error('Serverul nu a returnat un răspuns valid.')); }
          };
          xhr.send(payload);
        });
        var data = response.data;
        if (!response.ok || !data.success) {
          var submissionError = new Error(data && data.data && data.data.message ? data.data.message : (config.error || 'A apărut o eroare la trimitere.'));
          submissionError.status = response.status;
          throw submissionError;
        }
        if (options.shipmentId && (!data.data || !data.data.staged || !data.data.shipment)) {
          throw new Error('Serverul nu a confirmat adăugarea în expediere. Datele formularului au fost păstrate.');
        }
        sendingRequest = false;
        syncInteractionLock();
        if (options.shipmentId) {
          // Formularul curent se golește numai după confirmarea salvării pe server.
          goBackToCategories();
        } else {
          showSubmissionSuccess(data.data, null);
        }
        return data.data;
      } catch (error) {
        showError(error.message || config.error || 'Eroare de conexiune.');
        throw error;
      } finally {
        sendingRequest = false;
        syncInteractionLock();
        submitButton.classList.remove('vsc-button--processing');
        submitButton.removeAttribute('aria-busy');
        submitButton.innerHTML = previousLabel;
        refreshSubmitAvailability();
      }
    }

    form.addEventListener('submit', async function (event) {
      event.preventDefault();
      if (shipmentController && shipmentController.isActive()) {
        await shipmentController.submitCurrent();
        return;
      }
      try { await submitCurrentItem({}); }
      catch (ignored) { /* Mesajul este deja afișat; păstrăm datele pentru reîncercare. */ }
    });

    // Parametrul ?categoria=... permite și carduri Elementor configurate ca linkuri.
    var initialCategory = '';
    try { initialCategory = new URLSearchParams(window.location.search).get('categoria') || ''; }
    catch (ignored) { /* Fallback la lista din formular. */ }
    // Parametrul din URL are prioritate; dacă lipsește, reluăm ultima
    // categorie selectată chiar și când utilizatorul revine pe /vinde/.
    var restoredFromBrowser = false;
    if (!isValidCategory(initialCategory)) {
      initialCategory = savedCategory();
      restoredFromBrowser = isValidCategory(initialCategory);
    }
    var oldDraft = readDraft();
    if (isValidCategory(initialCategory)) {
      if (oldDraft && oldDraft.category !== initialCategory) { clearDraft(); oldDraft = null; }
      selectCategory(initialCategory, false);
      if (initialCategory === 'scule-acumulator') {
        var previousPackage = savedPackage();
        if (previousPackage) { choosePackage(previousPackage); }
      }
      if (oldDraft) { restoreDraft(oldDraft); }
      // La revenirea pe pagină, deschidem direct zona formularului.
      if (restoredFromBrowser || window.location.hash === '#formular-vinde-scula') {
        window.requestAnimationFrame(function () { root.scrollIntoView({behavior:'auto', block:'start'}); });
      }
    } else if (hasCards) {
      root.hidden = true;
      setCardsVisible(true);
    } else {
      showForm(false);
    }
    draftReady = true;
    purgeExpiredPhotoDrafts();
    if (oldDraft && isValidCategory(initialCategory)) {
      // Orice persistPhotos ulterior așteaptă copierea ciornei în cheia nouă.
      photoQueue = restorePhotos(oldDraft);
    }
    root.vscFormBridge = {
      attach: function (controller) { shipmentController = controller; refreshSubmitAvailability(); },
      submitItem: submitCurrentItem,
      finishShipment: function (shipment) { showSubmissionSuccess(null, shipment); },
      hasCurrentDraft: function () {
        return files.length > 0 || ['marca','model','stare','an_fabricatie','descriere','pachet'].some(function (name) {
          return form.elements[name] && String(form.elements[name].value || '').trim() !== '';
        });
      },
      isBusy: function () { return sendingRequest || externalBusy; },
      canSubmitCurrent: function () { return currentWizardStep === 3 && !submitButton.disabled; },
      setExternalBusy: function (busy) {
        externalBusy = !!busy;
        syncInteractionLock();
        refreshSubmitAvailability();
      }
    };
    root.dispatchEvent(new CustomEvent('vsc:form-ready', {bubbles: true, detail: root.vscFormBridge}));
  }

  function boot() {
    // Mai întâi mutăm vizibilitatea pe regiuni (carduri/formular), apoi
    // eliminăm ascunderea temporară din <head>; astfel nu există un cadru cu carduri vizibile.
    try {
      document.querySelectorAll('.vsc-widget').forEach(init);
    } finally {
      document.documentElement.classList.remove('vsc-category-prefill');
    }
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
  else { boot(); }
})();
