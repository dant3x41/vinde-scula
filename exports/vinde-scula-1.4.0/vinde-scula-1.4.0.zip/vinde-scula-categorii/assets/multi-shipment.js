(function () {
  'use strict';
  var config = window.VSC_CATEGORII || {};

  function uuid() {
    if (window.crypto && window.crypto.randomUUID) { return window.crypto.randomUUID(); }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (letter) {
      var value = Math.floor(Math.random() * 16);
      return (letter === 'x' ? value : (value & 3) | 8).toString(16);
    });
  }

  function init(root, bridge) {
    config = window.VSC_CATEGORII || config;
    if (!bridge || !config.shipmentNonce || root.dataset.vscShipmentInitialized === 'yes') { return; }
    root.dataset.vscShipmentInitialized = 'yes';
    var shipment = null;
    var busy = false;
    var maximum = Math.max(1, Number(config.shipmentMaxItems) || 3);
    var shipmentId = 0;
    var clientToken = uuid();
    var itemToken = uuid();
    var normalSubmit = root.querySelector('.vsc-form button[type="submit"]');
    var normalLabel = normalSubmit.innerHTML;
    var pageKey = new URLSearchParams(window.location.search).get('page_id') || '';
    var storageKey = 'vsc:shipment:v1:' + (config.draftAccount || 'guest') + ':' + window.location.pathname + ':' + pageKey;

    function saveRecovery() {
      try {
        // sessionStorage se copiază la duplicarea filei. Identitatea sculei
        // rămâne numai în pagina curentă; o pagină nouă poate avea alt formular.
        window.sessionStorage.setItem(storageKey, JSON.stringify({id: shipmentId, clientToken: clientToken}));
      } catch (ignored) { /* Serverul păstrează sculele deja confirmate. */ }
    }
    try {
      var saved = JSON.parse(window.sessionStorage.getItem(storageKey) || 'null');
      if (saved && typeof saved.clientToken === 'string') {
        shipmentId = Math.max(0, Number(saved.id) || 0);
        clientToken = saved.clientToken;
      }
    } catch (ignored) { /* O ciornă locală invalidă nu blochează formularul. */ }

    var basket = document.createElement('section');
    basket.className = 'vsc-shipment-cart';
    basket.hidden = true;
    basket.setAttribute('aria-label', 'Sculele din expedierea ta');
    var heading = document.createElement('h2');
    heading.textContent = 'Expedierea ta';
    heading.tabIndex = -1;
    var count = document.createElement('p');
    count.className = 'vsc-shipment-cart__count';
    var explanation = document.createElement('p');
    explanation.className = 'vsc-shipment-cart__intro';
    explanation.textContent = 'Fiecare sculă are fotografiile și oferta ei. Sculele acceptate vor avea o singură ridicare.';
    var list = document.createElement('ul');
    list.className = 'vsc-shipment-cart__items';
    var savedNotice = document.createElement('p');
    savedNotice.className = 'vsc-shipment-cart__saved';
    savedNotice.textContent = 'Sculele adăugate sunt păstrate în pregătire. Expedierea se trimite numai după confirmarea ta.';
    var feedback = document.createElement('p');
    feedback.className = 'vsc-shipment-cart__feedback';
    feedback.setAttribute('aria-live', 'polite');
    feedback.hidden = true;
    var sendAll = document.createElement('button');
    sendAll.type = 'button';
    sendAll.className = 'vsc-shipment-cart__send';
    basket.append(heading, count, explanation, list, savedNotice, feedback, sendAll);
    // Widgetul poate fi ascuns când clientul revine la cardurile de categorii.
    root.parentNode.insertBefore(basket, root);

    var addAnother = document.createElement('button');
    addAnother.type = 'button';
    addAnother.className = 'vsc-shipment-add';
    addAnother.textContent = 'Adaugă încă o sculă';
    addAnother.disabled = true;
    normalSubmit.parentNode.insertBefore(addAnother, normalSubmit);

    function message(text, error) {
      feedback.textContent = text;
      feedback.hidden = !text;
      feedback.classList.toggle('is-error', !!error);
      feedback.setAttribute('role', error ? 'alert' : 'status');
    }
    function itemCount() { return shipment && Array.isArray(shipment.items) ? shipment.items.length : 0; }
    function isActive() { return shipmentId > 0 && (!shipment || shipment.state === 'draft'); }
    function refresh() {
      var blocked = busy || bridge.isBusy();
      addAnother.disabled = blocked || !bridge.canSubmitCurrent() || itemCount() >= maximum;
      sendAll.disabled = blocked || !shipment || shipment.state !== 'draft' || itemCount() === 0;
      sendAll.textContent = busy ? 'Se salvează…' : 'Trimite ' + itemCount() + (itemCount() === 1 ? ' sculă' : ' scule');
      basket.querySelectorAll('[data-vsc-remove-item]').forEach(function (button) { button.disabled = blocked; });
      basket.setAttribute('aria-busy', blocked ? 'true' : 'false');
      if (!bridge.isBusy()) {
        if (isActive()) { normalSubmit.textContent = 'Adaugă și trimite expedierea'; }
        else { normalSubmit.innerHTML = normalLabel; }
      }
    }
    function render() {
      basket.hidden = (!shipment || shipment.state !== 'draft') && feedback.hidden;
      list.replaceChildren();
      if (shipment) {
        maximum = Math.max(1, Number(shipment.max_items) || maximum);
        count.textContent = (shipment.reference ? shipment.reference + ' · ' : '') + itemCount() + ' din ' + maximum + ' scule';
        shipment.items.forEach(function (item) {
          var row = document.createElement('li');
          var description = document.createElement('div');
          var name = document.createElement('strong');
          name.textContent = item.name || 'Sculă';
          var details = document.createElement('span');
          var photos = Array.isArray(item.photos) ? item.photos.length : (Number(item.photos) || 0);
          details.textContent = (item.reference ? item.reference + ' · ' : '') + photos + (photos === 1 ? ' fotografie' : ' fotografii');
          description.append(name, details);
          var remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'vsc-shipment-cart__remove';
          remove.dataset.vscRemoveItem = String(item.id);
          remove.textContent = 'Elimină';
          remove.setAttribute('aria-label', 'Elimină ' + (item.name || 'scula') + ' din expediere');
          remove.addEventListener('click', function () { removeItem(item); });
          row.append(description, remove);
          list.appendChild(row);
        });
      }
      refresh();
    }
    function setBusy(value) {
      busy = value;
      bridge.setExternalBusy(value);
      refresh();
    }
    async function request(operation, fields) {
      var payload = new URLSearchParams({action: 'vsc_shipment', security: config.shipmentNonce, operation: operation});
      Object.keys(fields || {}).forEach(function (key) { payload.set(key, String(fields[key])); });
      var abort = typeof AbortController === 'function' ? new AbortController() : null;
      var timer = abort ? window.setTimeout(function () { abort.abort(); }, 30000) : null;
      try {
        var response = await fetch(config.ajax, {
          method: 'POST', credentials: 'same-origin', cache: 'no-store',
          headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json'},
          body: payload.toString(), signal: abort ? abort.signal : undefined
        });
        var result = await response.json();
        if (!response.ok || !result || !result.success || !result.data || !result.data.shipment) {
          var error = new Error(result && result.data && result.data.message ? result.data.message : 'Nu am putut actualiza expedierea.');
          error.status = response.status;
          throw error;
        }
        return result.data.shipment;
      } catch (error) {
        if (error.name === 'AbortError') { throw new Error('Serverul răspunde greu. Sculele salvate sunt păstrate; reîncearcă pentru a verifica expedierea.'); }
        throw error;
      } finally { if (timer) { window.clearTimeout(timer); } }
    }
    function acceptShipment(value) {
      if (!value || !Number(value.id) || !Array.isArray(value.items)) { throw new Error('Datele expedierii nu sunt complete. Reîncarcă pagina pentru a le verifica.'); }
      shipment = value;
      shipmentId = Number(value.id);
      saveRecovery();
      render();
    }
    function restartRecovery() {
      shipment = null;
      shipmentId = 0;
      clientToken = uuid();
      itemToken = uuid();
      try { window.sessionStorage.removeItem(storageKey); } catch (ignored) {}
    }
    function unavailable(error) {
      if (error.status === 403) {
        message((error.message || 'Sesiunea nu permite actualizarea expedierii.') + ' Reîncarcă pagina pentru a verifica sesiunea. Sculele salvate și formularul curent au fost păstrate.', true);
        return true;
      }
      if ([404, 410].indexOf(error.status) === -1) { return false; }
      restartRecovery();
      message((error.message || 'Expedierea nu mai este disponibilă.') + ' Formularul curent a fost păstrat. Adaugă scula din nou pentru a începe o expediere nouă.', true);
      return true;
    }
    function completed(value) {
      message('', false);
      restartRecovery();
      render();
      bridge.finishShipment(value);
    }
    async function ensureShipment() {
      if (!shipmentId) {
        saveRecovery();
        acceptShipment(await request('create', {client_token: clientToken}));
      }
      if (shipment && shipment.state !== 'draft') {
        // Altă filă poate să fi trimis expedierea. Formularul acestei pagini
        // aparține unei scule încă nesalvate și nu trebuie golit la recuperare.
        restartRecovery();
        saveRecovery();
        acceptShipment(await request('create', {client_token: clientToken}));
      }
      return true;
    }
    async function stageCurrent() {
      if (itemCount() >= maximum) { throw new Error('Poți adăuga maximum ' + maximum + ' scule. Trimite expedierea sau elimină o sculă.'); }
      if (!await ensureShipment()) { return null; }
      // submitItem capturează și blochează sincron formularul înainte de upload.
      bridge.setExternalBusy(false);
      var result;
      try { result = await bridge.submitItem({shipmentId: shipmentId, itemToken: itemToken}); }
      finally { bridge.setExternalBusy(true); }
      if (!result) { return null; }
      acceptShipment(result.shipment);
      itemToken = uuid();
      saveRecovery();
      return result;
    }
    async function runCurrent(finalize) {
      if (busy || bridge.isBusy()) { return; }
      setBusy(true);
      message('', false);
      try {
        if (!await stageCurrent()) { return; }
        if (finalize) {
          var value = await request('finalize', {shipment_id: shipmentId});
          bridge.setExternalBusy(false);
          completed(value);
        } else {
          message('Scula a fost adăugată. Alege următoarea sculă sau trimite expedierea de mai sus.', false);
          heading.focus({preventScroll: true});
          basket.scrollIntoView({behavior: 'auto', block: 'start'});
        }
      } catch (error) {
        basket.hidden = false;
        if (!unavailable(error)) { message(error.message || 'Conexiunea a eșuat. Datele au fost păstrate; reîncearcă fără să modifici scula pentru a relua aceeași adăugare.', true); }
      } finally { setBusy(false); render(); }
    }
    async function removeItem(item) {
      if (busy || bridge.isBusy()) { return; }
      if (!window.confirm('Elimini această sculă din expediere? Va trebui să o adaugi din nou dacă te răzgândești.')) { return; }
      setBusy(true);
      try {
        acceptShipment(await request('remove', {shipment_id: shipmentId, item_id: item.id}));
        message('Scula a fost eliminată din expediere.', false);
      } catch (error) { if (!unavailable(error)) { message(error.message || 'Nu am putut elimina scula. Reîncearcă.', true); } }
      finally { setBusy(false); render(); }
    }
    async function sendBasket() {
      if (busy || bridge.isBusy() || !itemCount()) { return; }
      if (bridge.hasCurrentDraft() && !window.confirm('Scula începută în formular nu este încă adăugată. Trimiți doar cele ' + itemCount() + ' scule deja salvate? Datele sculei începute vor fi șterse după confirmare.')) { return; }
      setBusy(true);
      try {
        var value = await request('finalize', {shipment_id: shipmentId});
        bridge.setExternalBusy(false);
        completed(value);
      } catch (error) { if (!unavailable(error)) { message(error.message || 'Nu am putut trimite expedierea. Sculele sunt păstrate; reîncearcă.', true); } }
      finally { setBusy(false); render(); }
    }
    async function recover() {
      if (!shipmentId) { return; }
      setBusy(true);
      try {
        var value = await request('list', {shipment_id: shipmentId});
        if (value.state === 'draft') {
          acceptShipment(value);
          message('Am reluat expedierea în pregătire. Poți continua să adaugi scule.', false);
        } else {
          restartRecovery();
          message('Expedierea anterioară a fost deja trimisă. Formularul curent a fost păstrat pentru o expediere nouă.', false);
        }
      } catch (error) {
        basket.hidden = false;
        if (!unavailable(error)) { message(error.message || 'Nu am putut relua expedierea. Datele formularului sunt păstrate.', true); }
      } finally { setBusy(false); render(); }
    }
    addAnother.addEventListener('click', function () { runCurrent(false); });
    sendAll.addEventListener('click', sendBasket);
    bridge.attach({isActive: isActive, submitCurrent: function () { return runCurrent(true); }, refresh: refresh});
    recover();
  }
  function boot() {
    document.querySelectorAll('.vsc-widget').forEach(function (root) { init(root, root.vscFormBridge); });
  }
  document.addEventListener('vsc:form-ready', function (event) { init(event.target, event.detail); });
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
  else { boot(); }
})();
