=== 00. Vinde Scula – Formular cu Categorii ===
Stable tag: 1.4.0
Requires at least: 6.0
Requires PHP: 7.4

Solicitări de vânzare pentru cinci categorii, cu maximum 3 scule într-o
expediție, oferte individuale, ridicare comună și statistici administrative.

== Utilizare ==

Folosește shortcode-ul [vinde_scula]. Parametrul URL
categoria=scule-electrice poate preselecta o categorie. Vizitatorii pot alege
categoria și apoi se autentifică sau își creează cont pentru a continua.

WooCommerce este necesar pentru fluxul complet Contul meu → Vânzări.
Elementor, tema Bigxon și integrarea siglelor sunt opționale.

1. Completează datele și confirmările pentru fiecare sculă și adaugă între
   1 și 5 fotografii valide pentru aceasta.
2. Adaugă scula în expediție. Poți elimina scule înainte de trimitere și poți
   adăuga cel mult 3 scule, inclusiv din categorii diferite.
3. Trimite întreaga expediție pentru evaluare. Salvarea sculelor în ciornă
   nu trimite solicitarea. O expediție trimisă consumă o singură unitate din
   limita de trimiteri, indiferent de numărul sculelor.
4. Consultă și acceptă sau refuză separat oferta fiecărei scule din Vânzări.
   Ridicarea poate fi confirmată după soluționarea tuturor ofertelor; include
   numai sculele acceptate. Sculele respinse sau retrase sunt excluse.
5. Confirmă o singură adresă de ridicare și același cont bancar pentru
   sculele acceptate. Datele sunt criptate separat pentru fiecare sculă,
   cu un conținut criptat nou asociat identificatorului acelei solicitări.

Ciornele expedițiilor sunt păstrate 48 de ore de la creare. Un cont poate
avea cel mult 3 expediții netrimise. Curățarea programată elimină ciornele
expirate și fotografiile lor private. Lista sculelor adăugate este păstrată
pe server și poate fi recuperată în aceeași sesiune de browser.

Separat, formularul încă neadăugat în expediție și fotografiile lui se pot
restaura local timp de 12 ore, dacă browserul permite stocarea sesiunii și
IndexedDB. Fiecare pagină folosește o copie proprie a fotografiilor temporare.
Această ciornă locală nu înlocuiește adăugarea sculei în expediția de pe server.

== Administrarea vânzărilor ==

Fiecare sculă păstrează solicitarea, oferta, decizia clientului, verificarea
și plata proprie. După confirmarea ridicării comune, salvarea curierului și
a AWB-ului și etapele Ridicare programată → În transport → Primită pentru
verificare se aplică împreună sculelor incluse în acea ridicare.
Returul, revizuirea ofertei și plata se gestionează separat pentru fiecare
sculă. Pluginul nu execută transferuri bancare și nu generează automat AWB-uri.

== Statistici ==

Solicitări → Statistici este disponibilă administratorilor cu permisiunea
manage_options. Perioada selectează inclusiv datele de creare ale
solicitărilor, în fusul orar al site-ului; rezultatele acestora sunt cele
înregistrate până în prezent, indiferent de data răspunsului sau a plății.
Ciornele și elementele din coș sunt excluse.

Sunt afișate sculele primite, expedițiile, ofertele trimise, acceptările
explicite și sculele achiziționate, plus rezultate pe categorii. Rata de
acceptare raportează acceptările cu ofertă la sculele cu ofertă; rata de
achiziție raportează sculele plătite la cele primite. Durata medie până la
prima ofertă folosește numai date valide, ulterioare sau egale creării.
O expediție cu mai multe scule este o expediție, dar fiecare sculă intră
separat în indicatorii pentru scule. „—” indică lipsa unei baze de calcul.

== Cerințe pentru fotografii și date private ==

- WordPress minimum 6.0, PHP minimum 7.4 și WooCommerce pentru contul clientului.
- GD sau Imagick cu suport WebP; maximum 5 fotografii per sculă, fiecare de
  maximum 5 MiB. upload_max_filesize trebuie să fie minimum 5M și
  post_max_size peste 25M; găzduirea trebuie să permită procesarea imaginilor.
- Director privat, inscriptibil, în afara rădăcinii publice; poate fi stabilit
  prin constanta VSC_PRIVATE_UPLOAD_DIR.
- OpenSSL cu AES-256-GCM pentru date bancare și datele de ridicare.
- Păstrează salturile WordPress: schimbarea lor afectează datele deja criptate.
- Fotografiile istorice păstrate în Media Library nu devin automat private.
- Tabelele WordPress posts, postmeta și options trebuie să folosească InnoDB pentru
  tranzacțiile care confirmă integral expediția, ridicarea și transportul.
- WP-Cron funcțional pentru notificări și curățarea ciornelor expirate.

Versiunile minime sunt cerințe declarate; mediul local de verificare folosește
WordPress 7.1.3, PHP 8.3.36 și WooCommerce 11.2.1.

== Actualizare și copii de siguranță ==

Înainte de actualizare, salvează baza de date și directorul fotografiilor
private. Păstrează configurația WordPress, inclusiv cheile și salturile:
schimbarea acestora poate împiedica decriptarea datelor deja salvate. O copie
doar a directorului public uploads nu include fotografiile private noi.

== Notificări și operațiuni ==

Notificările folosesc wp_mail și o coadă WP-Cron. Configurarea SMTP aparține
instalării WordPress. Administratorul destinat notificărilor este info@sculebune.ro.
Pluginul nu execută transferuri bancare și nu generează automat AWB-uri.

Istoricul original este păstrat în docs/HISTORY.txt; schimbările funcționale
din această versiune sunt descrise în CHANGELOG.md. CLEANUP.md documentează
numai pregătirea bazei istorice 1.3.89.
