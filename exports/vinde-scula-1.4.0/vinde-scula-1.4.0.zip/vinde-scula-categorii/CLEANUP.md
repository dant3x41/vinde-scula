# Curățarea bazei istorice 1.3.89

Acest document descrie numai pregătirea bazei 1.3.89 din care a fost
dezvoltată versiunea 1.4.0:

- Indentare consecventă a corpului `try` din `process_background`.
- README al bazei actualizat pentru versiunea și shortcode-ul de atunci.
- Istoricul original păstrat integral în `docs/HISTORY.txt`.
- În acea etapă nu s-au schimbat versiunea, logica, activele sau structura datelor.

Afirmațiile de mai sus se referă exclusiv la curățarea istorică. Versiunea
1.4.0 include schimbări funcționale în PHP, JavaScript, CSS și datele
solicitărilor: expediții cu mai multe scule, ridicare comună, statistici și
corecțiile aferente. Vezi [CHANGELOG.md](CHANGELOG.md) și [README.txt](README.txt).

Arhiva originală și raportul de audit al bazei sunt păstrate separat de
această versiune. Istoricul original nu reprezintă lista schimbărilor 1.4.0.
